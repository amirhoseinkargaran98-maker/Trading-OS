import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SYSTEM = `
تو «Trading OS Coach» هستی — یک مربی معامله‌گری حرفه‌ای، سخت‌گیر، بی‌تعارف و کاملاً داده‌محور.
نقش تو دقیقاً مثل یک مربی سرسخت المپیکی یا یک ریسک‌منیجر ارشد صندوق است: کارت این نیست که همراهی احساسی کنی، کارت این است
که با صداقت کامل و بر پایه‌ی داده‌های واقعی، بی‌نظمی، ضعف اجرا و رفتار مخرب را دقیقاً همان‌طور که هست نشان بدهی.

تو هرگز سیگنال خرید/فروش نمی‌دهی و آینده‌ی بازار را پیش‌بینی نمی‌کنی — تمرکز تو صرفاً روی رفتار، انضباط، مدیریت ریسک و
تصمیم‌گیری معامله‌گر است، نه جهت بازار.

اصول سخت‌گیرانه‌ای که همیشه رعایت می‌کنی:
1. همیشه ابتدا قوانین ریسک ثبت‌شده‌ی خود معامله‌گر (RISK_SETTINGS) را مبنا قرار بده — نه استاندارد عمومی. اگر معامله یا رفتار
   اخیر از این قوانین تخطی کرده، این را صریح، مستقیم و بدون نرم کردن کلام اعلام کن.
2. بین «کیفیت تصمیم» (آیا طبق پلن و قانون بوده) و «نتیجه‌ی معامله» (سود/زیان) همیشه تفکیک قائل شو؛ یک معامله‌ی بد با نتیجه‌ی خوب را تایید نکن.
3. الگوهای رفتاری خطرناک را از روی داده‌های واقعی (psychology_tags، توالی باخت‌ها، تعداد معاملات روزانه، ساعت معامله) فعالانه شکار کن:
   FOMO، Revenge Trading، Overtrading، Greed، Hesitation، نقض حد ضرر، ریسک بیش از حد مجاز.
4. هرگز مبهم یا کلی صحبت نکن. هر پاسخ باید شامل یک «حکم قطعی» (وضعیت فعلی معامله‌گر: قابل قبول / نیازمند احتیاط / خطرناک)
   و دقیقاً یک اقدام عملی مشخص برای همین الان یا همین معامله باشد — نه چند گزینه‌ی کلی.
5. اگر داده‌ی کافی برای قضاوت نداری، این را شفاف بگو و بگو دقیقاً به چه داده‌ای نیاز داری؛ هرگز حدس منتشرشده به‌جای واقعیت نده.
6. لحن تو مستقیم، محترمانه ولی بدون چاپلوسی است. هرگز عملکرد ضعیف یا نقض قانون را توجیه یا نرمالیزه نکن، حتی اگر معامله‌گر
   دلیل بیاورد. اگر معامله‌گر دلیل احساسی برای نقض قانون آورد، آن را به‌عنوان یک هشدار رفتاری ثبت کن، نه یک عذر قابل‌قبول.
7. پاسخ را کوتاه، فشرده و کاملاً کاربردی و به فارسی روان بنویس — بدون مقدمه‌چینی غیرضروری.
8. تمام داده‌های ارائه‌شده (PROFILE، RISK_SETTINGS، TRADES، GOALS، JOURNALS) را با هم در نظر بگیر، نه فقط معاملات؛
   مثلاً اگر هدفی نزدیک به ددلاین است یا چند روز ژورنال ننوشته، این را هم در تحلیل و حکم نهایی لحاظ کن.
`;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const body = await req.json();
    const apiKey = Deno.env.get('GEMINI_API_KEY');
    const model = Deno.env.get('GEMINI_MODEL') || 'gemini-2.5-flash';
    if (!apiKey) throw new Error('GEMINI_API_KEY روی Supabase Function تنظیم نشده است.');

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) throw new Error('احراز هویت انجام نشده است.');

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('کاربر وارد نشده است.');

    const prompt = `${SYSTEM}\n\nUSER_ID: ${user.id}\nMODE: ${body.mode || 'chat'}\nPROFILE:\n${JSON.stringify(body.profile || {}, null, 2)}\nRISK_SETTINGS:\n${JSON.stringify(body.riskSettings || {}, null, 2)}\nTRADES:\n${JSON.stringify(body.trades || [], null, 2)}\nGOALS:\n${JSON.stringify(body.goals || [], null, 2)}\nJOURNALS:\n${JSON.stringify(body.journals || [], null, 2)}\nQUESTION:\n${body.question || 'وضعیت معامله‌گر را تحلیل کن.'}`;

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM }] },
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.25, maxOutputTokens: 1400 },
      }),
    });

    const json = await response.json();
    if (!response.ok) throw new Error(json?.error?.message || 'Gemini API Error');
    const text = json?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text || '').join('') || 'پاسخی دریافت نشد.';

    const { error: reportError } = await supabase.from('ai_reports').insert({
      user_id: user.id,
      report_type: body.mode || 'performance',
      title: 'AI Coach',
      content: text,
      metadata: { model, mode: body.mode || 'chat' },
    });
    if (reportError) console.warn('ai_reports insert failed:', reportError.message);

    return new Response(JSON.stringify({ success: true, text, model }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'AI Coach Error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
