# AI Coach function

Set these secrets in Supabase:

- GEMINI_API_KEY = your Gemini API key
- GEMINI_MODEL = gemini-2.5-flash (optional)

Deploy:

supabase functions deploy ai-coach
supabase secrets set GEMINI_API_KEY=YOUR_KEY
supabase secrets set GEMINI_MODEL=gemini-2.5-flash

The frontend never receives the Gemini key. It calls this Edge Function through Supabase.
