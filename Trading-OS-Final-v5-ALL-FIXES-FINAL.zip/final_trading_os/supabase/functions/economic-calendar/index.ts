const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

type Impact = 'high' | 'medium' | 'low' | 'unknown';
type Bias = 'bullish' | 'bearish' | 'mixed' | 'neutral';
type Event = {
  date: string;
  time: string;
  timestamp: number;
  currency: string;
  impact: Impact;
  title: string;
  actual: string | null;
  forecast: string | null;
  previous: string | null;
  bias: Bias;
  minutes: number | null;
  source: string;
};
type SourceResult = { source: string; events: Event[]; error?: string };

const SOURCES = [
  { kind: 'json', url: 'https://nfs.faireconomy.media/ff_calendar_thisweek.json', name: 'FairEconomy / Forex Factory mirror' },
  { kind: 'json', url: 'https://cdn-nfs.faireconomy.media/ff_calendar_thisweek.json', name: 'FairEconomy CDN mirror' },
  { kind: 'csv', url: 'https://www.forexfactory.com/calendar?export=csv&week=this', name: 'Forex Factory CSV' },
  { kind: 'html', url: 'https://ilisavsky.de/?lang=en', name: 'ClawFX calendar' },
  { kind: 'html', url: 'https://www.landgrafenstadt.de/?lang=en', name: 'ClawFX mirror calendar' },
  { kind: 'json', url: 'https://api.tradingeconomics.com/calendar?c=guest%3Aguest&f=json&importance=2', name: 'Trading Economics Guest' },
] as const;

function normalizeImpact(v: unknown): Impact {
  const x = String(v ?? '').trim().toLowerCase();
  if (x === '3' || x.includes('high') || x.includes('hoch') || x.includes('red')) return 'high';
  if (x === '2' || x.includes('medium') || x.includes('mittel') || x.includes('orange') || x.includes('moderate')) return 'medium';
  if (x === '1' || x.includes('low') || x.includes('niedrig') || x.includes('yellow')) return 'low';
  return 'unknown';
}

function parseNumber(v: unknown): number | null {
  if (v == null || v === '') return null;
  const m = String(v).replace(/,/g, '').match(/-?\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : null;
}

function inferBias(title: string, actual: unknown, forecast: unknown): Bias {
  const a = parseNumber(actual);
  const f = parseNumber(forecast);
  if (a == null || f == null || a === f) return 'neutral';
  const inverse = ['cpi', 'inflation', 'ppi', 'unemployment', 'jobless', 'claims'];
  return inverse.some(k => title.toLowerCase().includes(k)) ? (a < f ? 'bullish' : 'bearish') : (a > f ? 'bullish' : 'bearish');
}

function dateKeyTehran(ts: number): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tehran', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(ts));
}

function todayTehran(): string {
  return dateKeyTehran(Date.now());
}

function formatTehran(ts: number) {
  const d = new Date(ts);
  return {
    date: d.toLocaleDateString('fa-IR', { timeZone: 'Asia/Tehran' }),
    time: d.toLocaleTimeString('fa-IR', { timeZone: 'Asia/Tehran', hour: '2-digit', minute: '2-digit', hour12: false }),
  };
}

function parseTimestamp(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value < 1e12 ? value * 1000 : value;
  const raw = String(value ?? '').trim();
  if (!raw) return null;
  const parsed = Date.parse(raw);
  return Number.isFinite(parsed) ? parsed : null;
}

function currencyFromRow(row: Record<string, unknown>): string {
  const direct = String(row.currency ?? row.Currency ?? row.ccy ?? row.CCY ?? '').trim().toUpperCase();
  if (direct === 'USD' || direct === 'EUR') return direct;
  const country = String(row.country ?? row.Country ?? row.countryName ?? '').toLowerCase();
  if (country.includes('united states') || country.includes('usa') || country.includes('america')) return 'USD';
  if (country.includes('euro area') || country.includes('eurozone') || country.includes('germany') || country.includes('france') || country.includes('italy') || country.includes('spain') || country.includes('netherlands')) return 'EUR';
  return '';
}

function mapRow(row: Record<string, unknown>, source: string, now: number): Event | null {
  const ts = parseTimestamp(row.timestamp ?? row.Timestamp ?? row.dateTime ?? row.Date ?? row.date ?? row.datetime ?? row.time);
  const title = String(row.title ?? row.Title ?? row.event ?? row.Event ?? row.name ?? row.Name ?? row.detail ?? row.Detail ?? row.category ?? row.Category ?? '').trim();
  const currency = currencyFromRow(row);
  if (!ts || !title || !currency) return null;
  const impact = normalizeImpact(row.impact ?? row.Impact ?? row.importance ?? row.Importance ?? row.impactLevel ?? row.impact_label);
  const parts = formatTehran(ts);
  return {
    date: parts.date,
    time: parts.time,
    timestamp: ts,
    currency,
    impact,
    title,
    actual: row.actual ?? row.Actual ?? null,
    forecast: row.forecast ?? row.Forecast ?? null,
    previous: row.previous ?? row.Previous ?? row.prev ?? null,
    bias: inferBias(title, row.actual ?? row.Actual, row.forecast ?? row.Forecast),
    minutes: Math.round((ts - now) / 60000),
    source,
  };
}

function parseJsonRows(payload: unknown, source: string, now: number): Event[] {
  const rows = Array.isArray(payload) ? payload : (payload && typeof payload === 'object' ? ((payload as any).events || (payload as any).data || (payload as any).results || []) : []);
  return (Array.isArray(rows) ? rows : []).map((r: any) => mapRow(r, source, now)).filter(Boolean) as Event[];
}

function parseCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = '';
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (quoted && line[i + 1] === '"') { cur += '"'; i++; }
      else quoted = !quoted;
    } else if (c === ',' && !quoted) { out.push(cur.trim()); cur = ''; }
    else cur += c;
  }
  out.push(cur.trim());
  return out;
}

function parseCsv(csv: string, source: string, now: number): Event[] {
  const lines = csv.split(/\r?\n/).filter(Boolean);
  if (!lines.length) return [];
  const headers = parseCsvLine(lines[0]).map(x => x.toLowerCase());
  const idx = (names: string[]) => headers.findIndex(h => names.includes(h));
  const di = idx(['date']), ti = idx(['time']), ci = idx(['currency']), ii = idx(['impact']);
  const ni = idx(['event', 'detail', 'title']), ai = idx(['actual']), fi = idx(['forecast']), pi = idx(['previous']);
  return lines.slice(1).flatMap(line => {
    const c = parseCsvLine(line);
    const rawDate = di >= 0 ? c[di] : '';
    const rawTime = ti >= 0 ? c[ti] : '';
    const ts = parseTimestamp(`${rawDate} ${rawTime}`);
    if (!ts) return [];
    const row = {
      timestamp: ts,
      currency: ci >= 0 ? c[ci] : '',
      impact: ii >= 0 ? c[ii] : '',
      title: ni >= 0 ? c[ni] : '',
      actual: ai >= 0 ? c[ai] || null : null,
      forecast: fi >= 0 ? c[fi] || null : null,
      previous: pi >= 0 ? c[pi] || null : null,
    };
    const mapped = mapRow(row, source, now);
    return mapped ? [mapped] : [];
  });
}

function decodeEntities(value: string): string {
  return value.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/&quot;/g, '"');
}

function parseCalendarHtml(html: string, source: string, now: number): Event[] {
  const plain = decodeEntities(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<(br|\/p|\/div|\/li|\/tr|\/td|\/h\d)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  );

  const lines = plain.split(/\n+/).map(x => x.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const currentYear = new Date().getFullYear();
  let activeDate: string | null = null;
  const events: Event[] = [];

  for (const line of lines) {
    const heading = line.match(/(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)[,\s]+(\d{1,2})[./-](\d{1,2})[./-](\d{4})/i) || line.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
    if (heading) {
      const a = heading[1], b = heading[2], y = heading[3];
      activeDate = `${y}-${a.padStart(2,'0')}-${b.padStart(2,'0')}`;
      // If the first interpretation is impossible, flip day/month.
      const month = Number(a), day = Number(b);
      if (month > 12 && day <= 12) activeDate = `${y}-${b.padStart(2,'0')}-${a.padStart(2,'0')}`;
      continue;
    }

    const m = line.match(/^(\d{1,2}:\d{2})\s+.*?\b(USD|EUR)\b\s+(.+?)\s+(Hoch|Mittel|High|Medium|Low|Niedrig)\b(?:\s+(.+))?$/i);
    if (!m || !activeDate) continue;
    const ts = Date.parse(`${activeDate}T${m[1]}:00+03:30`);
    if (!Number.isFinite(ts)) continue;
    const impact = normalizeImpact(m[4]);
    const title = m[3].trim();
    if (impact !== 'high' && impact !== 'medium') continue;
    const value = m[5]?.trim() || null;
    const parts = formatTehran(ts);
    events.push({
      date: parts.date,
      time: parts.time,
      timestamp: ts,
      currency: m[2].toUpperCase(),
      impact,
      title,
      actual: null,
      forecast: value,
      previous: null,
      bias: 'neutral',
      minutes: Math.round((ts - now) / 60000),
      source,
    });
  }

  return events;
}

async function fetchSource(source: typeof SOURCES[number]): Promise<SourceResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3000);
  try {
    const response = await fetch(source.url, {
      signal: controller.signal,
      headers: { Accept: source.kind === 'json' ? 'application/json, text/plain;q=0.8, */*;q=0.5' : 'text/plain, text/html;q=0.9, */*;q=0.5', 'User-Agent': 'TradingOS-News/3.0' },
    });
    if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
    const text = await response.text();
    if (!text.trim()) throw new Error('Empty response');
    const now = Date.now();
    let events: Event[] = [];
    if (source.kind === 'json') {
      try { events = parseJsonRows(JSON.parse(text), source.name, now); }
      catch { events = parseCsv(text, source.name, now); }
    } else if (source.kind === 'csv') {
      events = parseCsv(text, source.name, now);
    } else {
      events = parseCalendarHtml(text, source.name, now);
    }
    return { source: source.name, events };
  } catch (error) {
    return { source: source.name, events: [], error: error instanceof Error ? error.message : 'Source unavailable' };
  } finally {
    clearTimeout(timer);
  }
}

function relevant(events: Event[], currencies: Set<string>): Event[] {
  const now = Date.now();
  const today = todayTehran();
  return events
    .filter(e => currencies.has(e.currency))
    .filter(e => e.impact === 'high' || e.impact === 'medium')
    .filter(e => dateKeyTehran(e.timestamp) === today)
    .filter(e => e.timestamp >= now - 24 * 60 * 60 * 1000)
    .sort((a, b) => a.timestamp - b.timestamp);
}

function dedupe(events: Event[]): Event[] {
  const seen = new Set<string>();
  const out: Event[] = [];
  for (const event of events) {
    const key = `${event.currency}|${Math.round(event.timestamp / 60000)}|${event.title.toLowerCase().replace(/\s+/g, ' ').trim()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(event);
  }
  return out;
}

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const body = await req.json().catch(() => ({}));
    const wanted = Array.isArray(body?.symbols) ? body.symbols as string[] : ['XAUUSD', 'EURUSD', 'DJI'];
    const currencies = new Set<string>();
    for (const symbol of wanted) {
      const x = String(symbol).toUpperCase();
      if (x.includes('EUR')) currencies.add('EUR');
      if (x.includes('USD') || x.includes('XAU') || x.includes('DJI') || x.includes('US30') || x.includes('DOW')) currencies.add('USD');
    }
    if (!currencies.size) { currencies.add('USD'); currencies.add('EUR'); }
    const limit = Math.min(50, Math.max(1, Number(body?.limit) || 30));

    const tried: SourceResult[] = [];
    for (const source of SOURCES) {
      const result = await fetchSource(source);
      tried.push(result);
      const usable = dedupe(relevant(result.events, currencies));
      if (usable.length) {
        return new Response(JSON.stringify({
          events: usable.slice(0, limit),
          source: result.source,
          timezone: 'Asia/Tehran',
          sourcesTried: tried.map(x => x.source),
          sourceErrors: tried.filter(x => x.error).map(x => ({ source: x.source, error: x.error })),
          error: null,
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=60, s-maxage=120' } });
      }
    }

    return new Response(JSON.stringify({
      events: [],
      source: null,
      timezone: 'Asia/Tehran',
      sourcesTried: tried.map(x => x.source),
      sourceErrors: tried.map(x => ({ source: x.source, error: x.error || 'No relevant USD/EUR high or medium impact events returned' })),
      error: 'هیچ‌کدام از منابع خبری در حال حاضر داده معتبر امروز را برنگرداندند.',
    }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (error) {
    return new Response(JSON.stringify({ events: [], source: null, error: error instanceof Error ? error.message : 'News service unavailable' }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
