/*
# Prop Account Fields

## Overview
Adds the two prop-firm-specific numbers that don't fit `risk_settings`
(which is daily-scoped): the overall max drawdown allowed for the whole
evaluation/funded account, and the overall profit target to pass it.
Daily loss limit and daily profit target already exist per-account in
`risk_settings` and are reused as-is by the new Prop Mode page.
*/

ALTER TABLE accounts ADD COLUMN IF NOT EXISTS prop_max_drawdown_percent numeric(5,2);
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS prop_profit_target_percent numeric(5,2);
