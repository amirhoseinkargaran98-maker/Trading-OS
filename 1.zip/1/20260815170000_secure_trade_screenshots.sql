-- Phase 21 security hardening: trade screenshots must not be publicly readable.
UPDATE storage.buckets SET public = false WHERE id = 'trade-screenshots';
DROP POLICY IF EXISTS "public_read_trade_screenshots" ON storage.objects;
DROP POLICY IF EXISTS "owner_read_trade_screenshots" ON storage.objects;
CREATE POLICY "owner_read_trade_screenshots" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'trade-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);

ALTER TABLE public.trade_screenshots ADD COLUMN IF NOT EXISTS storage_path text;
UPDATE public.trade_screenshots
SET storage_path = regexp_replace(url, '^.*/storage/v1/object/public/trade-screenshots/', '')
WHERE COALESCE(storage_path, '') = '' AND url IS NOT NULL AND url <> '';
CREATE INDEX IF NOT EXISTS trade_screenshots_path_idx ON public.trade_screenshots(storage_path);
