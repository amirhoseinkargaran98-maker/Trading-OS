import { useCallback, useEffect, useMemo, useState } from 'react';
import { Brain, Gauge, ShieldCheck, Target, TrendingDown, TrendingUp, Trophy, AlertTriangle, RefreshCw, CalendarDays, Layers3 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { toGregorianDateInput, addDateInputDays, formatCurrency } from '@/lib/utils';

type Trade = any;
const n=(v:any)=>Number.isFinite(Number(v))?Number(v):0;
const arr=(v:any)=>Array.isArray(v)?v:(typeof v==='string'?v.split(',').map(x=>x.trim()).filter(Boolean):[]);
const closed=(t:Trade)=>t.result!=='open';

function score(trades:Trade[]){
 const c=trades.filter(closed); if(!c.length)return {score:0, risk:0, process:0, review:0, rule:0, execution:0, outcome:0};
 const scored=c.filter(t=>Number.isFinite(Number(t.process_score)));
 const process=scored.length?scored.reduce((a,t)=>a+n(t.process_score),0)/scored.length:0;
 const review=c.filter(t=>t.review_completed===true||String(t.review_completed)==='true').length/c.length*100;
 const risk=c.filter(t=>n(t.risk_percent)<=1.0001).length/c.length*100;
 const execution=c.reduce((a,t)=>a+(t.entry_price&&t.stop_loss&&t.take_profit?100:50),0)/c.length;
 const violations=c.filter(t=>n(t.process_score)<70||n(t.risk_percent)>1.1||arr(t.psychology_tags).some(x=>['fomo','revenge','overtrading','fear','greed','anger'].includes(x))).length;
 const rule=100-violations/c.length*100;
 const wins=c.filter(t=>n(t.pnl_amount)>0).length/c.length*100;
 const outcome=Math.max(0,Math.min(100,wins*0.7+(c.reduce((a,t)=>a+n(t.r_multiple),0)/c.length>0?30:0)));
 const total=process*.25+review*.15+risk*.2+execution*.15+Math.max(0,rule)*.15+outcome*.10;
 return {score:Math.round(total),risk:Math.round(risk),process:Math.round(process),review:Math.round(review),rule:Math.round(Math.max(0,rule)),execution:Math.round(execution),outcome:Math.round(outcome)};
}
function bucket(trades:Trade[], days:number){const today=toGregorianDateInput(new Date()); const cutoff=addDateInputDays(today,-days); return trades.filter(t=>t.trade_date>=cutoff&&t.trade_date<=today);}

export default function TradingIntelligence(){
 const {user}=useAuth(); const [trades,setTrades]=useState<Trade[]>([]); const [loading,setLoading]=useState(true); const load=useCallback(async()=>{if(!user)return;setLoading(true);const {data}=await supabase.from('trades').select('*, strategies(name)').eq('user_id',user.id).eq('account_id', getActiveAccountId()).not('result','eq','open').order('trade_date',{ascending:true}).order('entry_time',{ascending:true});setTrades(data||[]);setLoading(false)},[user]);useEffect(()=>{load()},[load]);
 const periods=useMemo(()=>({today:bucket(trades,1),week:bucket(trades,7),month:bucket(trades,30),all:trades}),[trades]);
 const s=useMemo(()=>({today:score(periods.today),week:score(periods.week),month:score(periods.month),all:score(periods.all)}),[periods]);
 const insights=useMemo(()=>{const out:string[]=[];const week=periods.week;const bad=week.filter(t=>n(t.process_score)<70);const risk=week.filter(t=>n(t.risk_percent)>1.1);const pnl=week.reduce((a,t)=>a+n(t.pnl_amount),0);if(!week.length)return ['برای ساخت Intelligence هنوز معامله بسته‌شده کافی نیست.'];if(bad.length)out.push(`این هفته ${bad.length} معامله با Process Score زیر 70 ثبت شده؛ کیفیت اجرا را قبل از افزایش حجم بررسی کن.`);if(risk.length)out.push(`${risk.length} معامله بالاتر از سقف باند 1٪ (1.1٪) ریسک ثبت شده؛ Risk Guard باید بدون Override رعایت شود.`);if(pnl<0)out.push(`هفته جاری ${formatCurrency(pnl)} منفی است؛ نتیجه را از کیفیت فرآیند جدا کن و به دنبال الگوی تکرارشونده باش.`);else out.push(`هفته جاری ${formatCurrency(pnl)} مثبت است؛ بررسی کن این سود از اجرای منظم قوانین آمده یا از چند معامله استثنایی.`);if(s.week.review<80)out.push(`نرخ Review کامل این هفته ${s.week.review}٪ است؛ داده ناقص یعنی مربی آینده تصویر ناقصی خواهد داشت.`);return out.slice(0,4)},[periods,s]);
 if(loading)return <div className="page-container flex items-center justify-center py-24"><RefreshCw className="w-7 h-7 animate-spin text-gold-400"/></div>;
 return <div className="page-container space-y-5" dir="rtl">
  <div className="section-header"><div><p className="text-xs text-gold-400 mb-1">PHASE 11 · UNIFIED TRADING INTELLIGENCE</p><h1 className="text-2xl font-bold text-white">مرکز هوش معاملاتی</h1><p className="text-sm text-dark-400 mt-1">یک امتیاز واحد از ریسک، قوانین، اجرا، روانشناسی و نتیجه — کاملاً بدون AI</p></div><button onClick={load} className="glass-card p-2 text-dark-300 hover:text-white"><RefreshCw className="w-4 h-4"/></button></div>
  <section className="glass-card p-5 bg-gradient-to-l from-gold-500/10 via-transparent"><div className="flex items-center gap-4"><div className="w-20 h-20 rounded-2xl border border-gold-500/30 bg-dark-900 flex items-center justify-center"><span className="text-2xl font-black text-gold-300">{s.week.score}</span></div><div><p className="text-xs text-gold-300">امتیاز یکپارچه این هفته</p><h2 className="text-xl font-bold text-white mt-1">{s.week.score>=85?'اجرای ممتاز':s.week.score>=70?'قابل قبول':'نیازمند اصلاح'}</h2><p className="text-xs text-dark-400 mt-1">این امتیاز برای هدایت فرآیند است، نه پیش‌بینی سود آینده.</p></div></div></section>
  <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">{[['امروز',s.today],['هفته',s.week],['۳۰ روز',s.month],['کل سابقه',s.all]].map(([label,x]:any)=><div className="glass-card p-4" key={label}><div className="flex justify-between"><p className="text-xs text-dark-400">{label}</p><Gauge className="w-4 h-4 text-gold-400"/></div><p className="text-2xl font-bold text-white mt-2">{x.score}</p><p className="text-[11px] text-dark-500 mt-1">Risk {x.risk}% · Process {x.process}</p></div>)}</div>
  <div className="grid xl:grid-cols-2 gap-4"><section className="glass-card p-5"><h2 className="font-semibold text-white flex items-center gap-2"><Layers3 className="w-4 h-4 text-gold-400"/> اجزای امتیاز این هفته</h2><div className="mt-4 grid grid-cols-2 gap-3">{[['Process',s.week.process,TrendingUp],['Risk Discipline',s.week.risk,ShieldCheck],['Review',s.week.review,CalendarDays],['Execution',s.week.execution,Target],['Rule Compliance',s.week.rule,ShieldCheck],['Outcome',s.week.outcome,Trophy]].map(([a,v,I]:any)=><div key={a} className="rounded-xl bg-dark-800/60 p-3"><div className="flex justify-between text-xs text-dark-400"><span>{a}</span><I className="w-3.5 h-3.5 text-gold-400"/></div><p className="text-lg font-bold text-white mt-1">{v}/100</p><div className="h-1.5 bg-dark-700 rounded-full mt-2 overflow-hidden"><div className="h-full bg-gold-500" style={{width:`${Math.max(0,Math.min(100,v))}%`}}/></div></div>)}</div></section>
  <section className="glass-card p-5"><h2 className="font-semibold text-white flex items-center gap-2"><Brain className="w-4 h-4 text-gold-400"/> تصمیم‌های قابل اقدام</h2><div className="mt-4 space-y-3">{insights.map((x,i)=><div key={i} className="rounded-xl border border-white/5 bg-dark-800/50 p-4 flex gap-3"><AlertTriangle className="w-4 h-4 text-gold-400 shrink-0 mt-0.5"/><p className="text-sm text-dark-200 leading-6">{x}</p></div>)}</div></section></div>
  <section className="glass-card p-5"><h2 className="font-semibold text-white flex items-center gap-2"><Trophy className="w-4 h-4 text-gold-400"/> قانون مهم Trading OS</h2><p className="text-sm text-dark-300 mt-3 leading-7">نتیجه خوب، اجرای بد را تأیید نمی‌کند؛ نتیجه بد، اجرای خوب را باطل نمی‌کند. امتیاز یکپارچه برای پیدا کردن کیفیت فرآیند طراحی شده تا سود و ضرر کوتاه‌مدت، قضاوتت درباره سیستم را منحرف نکند.</p></section>
 </div>
}