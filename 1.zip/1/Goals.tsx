import { Fragment, useState, useEffect, useCallback } from 'react';
import { Target, Plus, Pencil, Trash2, CheckCircle2, Clock, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency, toPersianDate, toGregorianDateInput, parseDateOnly } from '@/lib/utils';
import { calculateEquityCurve } from '@/lib/tradingEngine';

type Goal = {
  id: string;
  title: string;
  goal_type: string;
  target_value: number | null;
  current_value: number;
  period: string;
  start_date: string | null;
  end_date: string | null;
  is_achieved: boolean;
  notes: string | null;
};

const GOAL_TYPES: Record<string, string> = {
  profit: 'سود', win_rate: 'وین‌ریت', drawdown: 'حداکثر افت سرمایه',
  trades: 'تعداد معامله', rr: 'میانگین R:R', capital: 'سرمایه',
};

const PERIODS: Record<string, string> = { daily: 'روزانه', weekly: 'هفتگی', monthly: 'ماهانه', yearly: 'سالانه' };

const AUTO_COMPUTE_TYPES = new Set(['profit', 'trades', 'win_rate', 'drawdown', 'rr', 'capital']);

const emptyForm = {
  title: '', goal_type: 'profit', target_value: '', period: 'monthly',
  start_date: toGregorianDateInput(new Date()), end_date: '', notes: '',
};

export default function Goals() {
  const { user } = useAuth();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const loadGoals = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    const { data: goalsData } = await supabase
      .from('goals').select('*').eq('user_id', user.id).order('created_at', { ascending: false });

    const list = goalsData || [];

    // 'capital' needs the account's starting point; the others are purely
    // derived from trades in the goal's own date range.
    const { data: profileRow } = await supabase.from('profiles').select('initial_capital').eq('id', user.id).maybeSingle();
    const initialCapital = Number(profileRow?.initial_capital) || 0;

    // Auto-compute current_value for computable goal types based on trades in the goal's date range
    const updates: Promise<void>[] = [];
    for (const g of list) {
      if (!AUTO_COMPUTE_TYPES.has(g.goal_type) || !g.start_date) continue;
      const fields = g.goal_type === 'drawdown' || g.goal_type === 'capital'
        ? 'pnl_amount, result, rr_ratio, trade_date, entry_time, created_at'
        : 'pnl_amount, result, rr_ratio';
      let query = supabase.from('trades').select(fields).eq('user_id', user.id).eq('account_id', getActiveAccountId()).not('result', 'eq', 'open');
      // 'capital' is a running milestone (total account balance), not a
      // period-bound sum, so it looks at every trade up to end_date rather
      // than only trades after start_date.
      if (g.goal_type !== 'capital') query = query.gte('trade_date', g.start_date);
      if (g.end_date) query = query.lte('trade_date', g.end_date);
      updates.push(
        (async () => {
          const { data: trades } = await query;
          const t = (trades || []) as Array<{ pnl_amount: number | null; result: string | null; rr_ratio: number | null; trade_date?: string; entry_time?: string | null; created_at?: string | null }>;
          let value = 0;
          if (g.goal_type === 'profit') value = t.reduce((sum, x) => sum + (Number(x.pnl_amount) || 0), 0);
          if (g.goal_type === 'trades') value = t.length;
          if (g.goal_type === 'win_rate') {
            const closed = t.filter((x) => x.result === 'win' || x.result === 'loss');
            const wins = closed.filter((x) => x.result === 'win').length;
            value = closed.length > 0 ? (wins / closed.length) * 100 : 0;
          }
          if (g.goal_type === 'rr') {
            const withRR = t.filter((x) => x.rr_ratio != null);
            value = withRR.length > 0 ? withRR.reduce((sum, x) => sum + (Number(x.rr_ratio) || 0), 0) / withRR.length : 0;
          }
          if (g.goal_type === 'drawdown') {
            const curve = calculateEquityCurve(t as any, initialCapital);
            value = curve.maxDrawdownPercent;
          }
          if (g.goal_type === 'capital') {
            value = initialCapital + t.reduce((sum, x) => sum + (Number(x.pnl_amount) || 0), 0);
          }
          g.current_value = value;
          // For 'drawdown' the goal is to stay UNDER the target, not reach it.
          const achieved = g.target_value != null && (g.goal_type === 'drawdown' ? value <= g.target_value : value >= g.target_value);
          g.is_achieved = achieved;
          await supabase.from('goals').update({ current_value: value, is_achieved: achieved }).eq('id', g.id).eq('user_id', user.id);
        })()
      );
    }
    if (updates.length) await Promise.all(updates);

    setGoals(list);
    setLoading(false);
  }, [user]);

  useEffect(() => { loadGoals(); }, [loadGoals]);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (g: Goal) => {
    setEditingId(g.id);
    setForm({
      title: g.title, goal_type: g.goal_type, target_value: String(g.target_value ?? ''),
      period: g.period, start_date: g.start_date || '', end_date: g.end_date || '', notes: g.notes || '',
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!user || !form.title.trim()) return;
    setSaving(true);
    const payload = {
      title: form.title.trim(),
      goal_type: form.goal_type,
      target_value: form.target_value ? Number(form.target_value) : null,
      period: form.period,
      start_date: form.start_date || null,
      end_date: form.end_date || null,
      notes: form.notes.trim() || null,
    };
    if (editingId) {
      await supabase.from('goals').update(payload).eq('id', editingId).eq('user_id', user.id);
    } else {
      await supabase.from('goals').insert({ ...payload, user_id: user.id, current_value: 0 });
    }
    setSaving(false);
    setShowForm(false);
    loadGoals();
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    await supabase.from('goals').delete().eq('id', id).eq('user_id', user.id);
    setDeleteId(null);
    loadGoals();
  };

  const formatValue = (type: string, val: number) => {
    if (type === 'profit' || type === 'capital') return formatCurrency(val);
    if (type === 'win_rate' || type === 'drawdown') return `${val.toFixed(1)}%`;
    if (type === 'rr') return `${val.toFixed(2)}R`;
    return val.toFixed(0);
  };

  const activeGoals = goals.filter(g => !g.is_achieved);
  const achievedGoals = goals.filter(g => g.is_achieved);

  if (loading) {
    return (
      <div className="page-container flex items-center justify-center min-h-[60vh]" dir="rtl">
        <div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-bold text-white">اهداف</h1>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-1.5 text-sm">
          <Plus className="w-4 h-4" /> هدف جدید
        </button>
      </div>

      {goals.length === 0 ? (
        <div className="glass-card p-10 text-center">
          <Target className="w-10 h-10 text-dark-500 mx-auto mb-3" />
          <p className="text-dark-400 text-sm mb-4">هنوز هدفی تعریف نکرده‌اید.</p>
          <button onClick={openCreate} className="btn-primary mx-auto text-sm">تعریف اولین هدف</button>
        </div>
      ) : (
        <>
          <div>
            <h2 className="section-title"><TrendingUp className="w-4 h-4 text-gold-400" /> در حال انجام ({activeGoals.length})</h2>
            {activeGoals.length === 0 ? (
              <p className="text-sm text-dark-500">هدف فعالی وجود ندارد.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {activeGoals.map(g => (
                  <Fragment key={g.id}><GoalCard g={g} formatValue={formatValue} onEdit={() => openEdit(g)} onDelete={() => setDeleteId(g.id)} /></Fragment>
                ))}
              </div>
            )}
          </div>

          {achievedGoals.length > 0 && (
            <div>
              <h2 className="section-title"><CheckCircle2 className="w-4 h-4 text-success-400" /> محقق‌شده ({achievedGoals.length})</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {achievedGoals.map(g => (
                  <Fragment key={g.id}><GoalCard g={g} formatValue={formatValue} onEdit={() => openEdit(g)} onDelete={() => setDeleteId(g.id)} /></Fragment>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-lg space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-semibold text-white">{editingId ? 'ویرایش هدف' : 'هدف جدید'}</h3>
            <div>
              <label className="label-text">عنوان هدف</label>
              <input type="text" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className="input-field" placeholder="مثلاً: سود ۱۰٪ در این ماه" autoFocus />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label-text">نوع هدف</label>
                <select value={form.goal_type} onChange={e => setForm(f => ({ ...f, goal_type: e.target.value }))} className="select-field">
                  {Object.entries(GOAL_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="label-text">دوره</label>
                <select value={form.period} onChange={e => setForm(f => ({ ...f, period: e.target.value }))} className="select-field">
                  {Object.entries(PERIODS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="label-text">مقدار هدف</label>
              <input type="number" step="0.01" value={form.target_value} onChange={e => setForm(f => ({ ...f, target_value: e.target.value }))} className="input-field number-ltr" placeholder="مثلاً: 1000" />
              {AUTO_COMPUTE_TYPES.has(form.goal_type) && (
                <p className="text-[11px] text-dark-500 mt-1">پیشرفت این نوع هدف به‌صورت خودکار از روی معاملات ثبت‌شده در بازه‌ی زمانی محاسبه می‌شود.</p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label-text">تاریخ شروع</label>
                <input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} className="input-field number-ltr" />
              </div>
              <div>
                <label className="label-text">تاریخ پایان</label>
                <input type="date" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} className="input-field number-ltr" />
              </div>
            </div>
            <div>
              <label className="label-text">یادداشت (اختیاری)</label>
              <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} className="input-field min-h-[70px] resize-y" />
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowForm(false)} className="btn-secondary">انصراف</button>
              <button onClick={handleSave} disabled={!form.title.trim() || saving} className="btn-primary">{saving ? 'در حال ذخیره...' : 'ذخیره'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete confirm */}
      {deleteId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف هدف</h3>
            <p className="text-sm text-dark-400 mb-4">آیا مطمئن هستید؟ این عمل قابل بازگشت نیست.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => handleDelete(deleteId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function GoalCard({
  g, formatValue, onEdit, onDelete,
}: { g: Goal; formatValue: (t: string, v: number) => string; onEdit: () => void; onDelete: () => void }) {
  const target = g.target_value || 0;
  const percent = target > 0 ? Math.min(100, Math.max(0, (g.current_value / target) * 100)) : 0;
  const isPastDeadline = g.end_date ? !!parseDateOnly(g.end_date) && parseDateOnly(g.end_date)!.getTime() < new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), 12).getTime() : false;

  return (
    <div className={`glass-card p-4 space-y-3 ${g.is_achieved ? 'border-success-500/20' : ''}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-sm font-semibold text-white">{g.title}</h3>
            {g.is_achieved && <CheckCircle2 className="w-4 h-4 text-success-400 flex-shrink-0" />}
          </div>
          <p className="text-[11px] text-dark-500 mt-0.5">{GOAL_TYPES[g.goal_type] || g.goal_type} · {PERIODS[g.period] || g.period}</p>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          <button onClick={onEdit} className="p-1.5 rounded-lg text-dark-400 hover:text-gold-400 hover:bg-white/5">
            <Pencil className="w-3.5 h-3.5" />
          </button>
          <button onClick={onDelete} className="p-1.5 rounded-lg text-dark-400 hover:text-danger-400 hover:bg-white/5">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="text-dark-400 number-ltr">{formatValue(g.goal_type, g.current_value)}</span>
          <span className="text-dark-500 number-ltr">هدف: {g.target_value != null ? formatValue(g.goal_type, g.target_value) : '—'}</span>
        </div>
        <div className="h-2 rounded-full bg-dark-700 overflow-hidden">
          <div
            className={`h-full transition-all duration-500 ${g.is_achieved ? 'bg-success-500' : isPastDeadline ? 'bg-danger-500' : 'bg-gold-500'}`}
            style={{ width: `${percent}%` }}
          />
        </div>
      </div>

      <div className="flex items-center justify-between text-[11px] text-dark-500">
        <span className="flex items-center gap-1">
          <Clock className="w-3 h-3" />
          {g.start_date ? toPersianDate(g.start_date) : '—'} تا {g.end_date ? toPersianDate(g.end_date) : '—'}
        </span>
        {isPastDeadline && !g.is_achieved && <span className="text-danger-400">مهلت گذشته</span>}
      </div>

      {g.notes && <p className="text-xs text-dark-400 border-t border-white/5 pt-2">{g.notes}</p>}
    </div>
  );
}
