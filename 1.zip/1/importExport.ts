import * as XLSX from 'xlsx';

export type ImportRow = Record<string, unknown>;

export const TRADE_IMPORT_FIELDS = [
  'trade_date','entry_time','exit_time','symbol','direction','timeframe','session','strategy','setup',
  'entry_price','stop_loss','take_profit','exit_price','lot_size','risk_percent','risk_amount',
  'pnl_amount','r_multiple','rr_ratio','result','notes','mistakes','lessons',
] as const;

export function downloadBlob(content: BlobPart, filename: string, type = 'text/plain;charset=utf-8') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function escapeCsv(value: unknown): string {
  const text = value === null || value === undefined ? '' : String(value);
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export function rowsToCsv(rows: ImportRow[], fields = TRADE_IMPORT_FIELDS as readonly string[]) {
  return [fields.join(','), ...rows.map(row => fields.map(field => escapeCsv(row[field])).join(','))].join('\r\n');
}

function parseCsv(text: string): ImportRow[] {
  const rows: string[][] = [];
  let row: string[] = [], cell = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i], n = text[i + 1];
    if (quoted) {
      if (c === '"' && n === '"') { cell += '"'; i++; }
      else if (c === '"') quoted = false;
      else cell += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell.length || row.length) { row.push(cell); rows.push(row); }
  const [headers, ...data] = rows.filter(r => r.some(Boolean));
  return data.map(values => Object.fromEntries(headers.map((h, i) => [h.trim(), values[i] ?? ''])));
}

export async function parseImportFile(file: File): Promise<ImportRow[]> {
  const ext = file.name.toLowerCase().split('.').pop();
  if (ext === 'csv') return parseCsv(await file.text());
  if (ext === 'json') {
    const parsed = JSON.parse(await file.text());
    if (!Array.isArray(parsed)) throw new Error('JSON باید شامل یک آرایه از معاملات باشد.');
    return parsed as ImportRow[];
  }
  if (ext === 'xlsx' || ext === 'xls') {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: 'array', cellDates: false });
    const first = workbook.Sheets[workbook.SheetNames[0]];
    if (!first) throw new Error('هیچ Sheet معتبری پیدا نشد.');
    return XLSX.utils.sheet_to_json(first, { defval: '' }) as ImportRow[];
  }
  throw new Error('فرمت پشتیبانی نمی‌شود. CSV، Excel یا JSON انتخاب کنید.');
}

export function normalizeImportValue(value: unknown): unknown {
  if (typeof value !== 'string') return value;
  const v = value.trim();
  if (!v) return null;
  if (/^-?\d+(\.\d+)?$/.test(v)) return Number(v);
  return v;
}

export function normalizeRows(rows: ImportRow[]) {
  return rows.map(row => Object.fromEntries(Object.entries(row).map(([k, v]) => [k.trim(), normalizeImportValue(v)])));
}

export function exportRowsJson(rows: ImportRow[]) {
  return JSON.stringify(rows, null, 2);
}
