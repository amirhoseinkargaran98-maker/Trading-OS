/*
# Real Trading Costs (Commission + Swap)

## Overview
Adds `commission`, `swap`, and `gross_pnl_amount` to trades. Previously
`pnl_amount` was purely a price-movement calculation with no broker costs
factored in, meaning Profit Factor, Expectancy, and every other statistic
built on top of it were systematically too optimistic for any account that
pays commission or swap.

From this migration forward, `pnl_amount` is the NET result (what actually
happened to the account), and `gross_pnl_amount` keeps the pre-cost figure
for a transparent breakdown in Trade Detail. Every other page already reads
`pnl_amount`, so this is the single place real costs flow through the whole
app without touching Dashboard/Analytics/equity-curve code.

## Backfill
Existing trades get commission/swap = 0 and gross_pnl_amount = pnl_amount
(i.e. treated as cost-free, since we have no historical cost data) — this
is a safe, non-destructive default; it changes nothing about old numbers.
*/

ALTER TABLE trades ADD COLUMN IF NOT EXISTS commission numeric(12,2) DEFAULT 0;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS swap numeric(12,2) DEFAULT 0;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS gross_pnl_amount numeric(14,2);

UPDATE trades SET gross_pnl_amount = pnl_amount WHERE gross_pnl_amount IS NULL AND pnl_amount IS NOT NULL;
