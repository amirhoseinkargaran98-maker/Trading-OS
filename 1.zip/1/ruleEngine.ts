export type StrategyRuleConfig = {
  allowedSessions?: string[];
  allowedDirections?: ('buy'|'sell')[];
  allowedTimeframes?: string[];
  allowedSymbols?: string[];
  allowedMarketConditions?: string[];
  minRR?: number;
  maxRiskPercent?: number;
  requireStopLoss?: boolean;
  requireTakeProfit?: boolean;
  requireEntryReason?: boolean;
  requirePsychology?: boolean;
  blockPsychologyTags?: string[];
};

export type RuleTradeInput = {
  session?: string | null;
  direction?: string | null;
  timeframe?: string | null;
  symbol?: string | null;
  market_condition?: string | null;
  rr_ratio?: number | null;
  risk_percent?: number | null;
  stop_loss?: number | null;
  take_profit?: number | null;
  entry_reason?: string | null;
  psychology_tags?: string[] | null;
};

export type RuleViolation = {
  id: string;
  severity: 'block' | 'warn';
  title: string;
  message: string;
};

const hasValue = (v: unknown) => v !== null && v !== undefined && String(v).trim() !== '';

export function evaluateStrategyRules(config: StrategyRuleConfig | null | undefined, trade: RuleTradeInput): RuleViolation[] {
  if (!config) return [];
  const violations: RuleViolation[] = [];
  const checkAllowed = (id: string, value: string | null | undefined, allowed: string[] | undefined, title: string) => {
    if (allowed?.length && value && !allowed.includes(value)) {
      violations.push({ id, severity: 'block', title, message: `مقدار «${value}» در قوانین این استراتژی مجاز نیست.` });
    }
  };
  checkAllowed('session', trade.session, config.allowedSessions, 'سشن خارج از پلن');
  checkAllowed('direction', trade.direction, config.allowedDirections, 'جهت خارج از پلن');
  checkAllowed('timeframe', trade.timeframe, config.allowedTimeframes, 'تایم‌فریم خارج از پلن');
  checkAllowed('symbol', trade.symbol, config.allowedSymbols, 'نماد خارج از پلن');
  checkAllowed('market_condition', trade.market_condition, config.allowedMarketConditions, 'شرایط بازار خارج از پلن');

  if (config.minRR && Number(trade.rr_ratio || 0) < config.minRR) {
    violations.push({ id: 'min_rr', severity: 'block', title: 'R:R ناکافی', message: `حداقل R:R این استراتژی 1:${config.minRR} است.` });
  }
  if (config.maxRiskPercent && Number(trade.risk_percent || 0) > config.maxRiskPercent + 0.0001) {
    violations.push({ id: 'max_risk', severity: 'block', title: 'ریسک بالاتر از سقف استراتژی', message: `ریسک واقعی ${Number(trade.risk_percent).toFixed(2)}٪ و سقف این استراتژی ${config.maxRiskPercent}٪ است.` });
  }
  if (config.requireStopLoss && !hasValue(trade.stop_loss)) {
    violations.push({ id: 'stop_loss', severity: 'block', title: 'حد ضرر الزامی است', message: 'این استراتژی بدون Stop Loss اجازه اجرا ندارد.' });
  }
  if (config.requireTakeProfit && !hasValue(trade.take_profit)) {
    violations.push({ id: 'take_profit', severity: 'block', title: 'تارگت الزامی است', message: 'این استراتژی بدون Take Profit اجازه اجرا ندارد.' });
  }
  if (config.requireEntryReason && !hasValue(trade.entry_reason)) {
    violations.push({ id: 'entry_reason', severity: 'warn', title: 'منطق ورود ثبت نشده', message: 'قبل از اجرا دلیل ورود را ثبت کن.' });
  }
  if (config.requirePsychology && !(trade.psychology_tags || []).length) {
    violations.push({ id: 'psychology', severity: 'warn', title: 'وضعیت روانی ثبت نشده', message: 'حداقل یک برچسب روانشناسی انتخاب کن.' });
  }
  const blocked = new Set(config.blockPsychologyTags || []);
  const activeBlocked = (trade.psychology_tags || []).filter(t => blocked.has(t));
  if (activeBlocked.length) {
    violations.push({ id: 'blocked_psychology', severity: 'block', title: 'هشدار روانشناسی', message: `این حالت روانی در استراتژی مسدود شده است: ${activeBlocked.join('، ')}` });
  }
  return violations;
}

export function parseLegacyRules(text: string | null | undefined): StrategyRuleConfig {
  const raw = (text || '').toLowerCase();
  const config: StrategyRuleConfig = {};
  const rr = raw.match(/(?:rr|r:r|risk.?reward)\s*(?:>=|minimum|min)?\s*(\d+(?:\.\d+)?)/i);
  if (rr) config.minRR = Number(rr[1]);
  const risk = raw.match(/(?:max(?:imum)?\s*risk|سقف ریسک)\s*[:=]?\s*(\d+(?:\.\d+)?)\s*%?/i);
  if (risk) config.maxRiskPercent = Number(risk[1]);
  return config;
}
