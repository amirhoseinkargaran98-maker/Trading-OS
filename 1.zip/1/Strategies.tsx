import { useState, useEffect, useCallback } from 'react';
import {
  Layers, Plus, Pencil, Trash2, ChevronDown, ChevronUp,
  Target, TrendingUp, TrendingDown, Percent, ListChecks, ShieldCheck
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency, formatRR } from '@/lib/utils';

type Strategy = {
  id: string;
  name: string;
  description: string | null;
  rules: string | null;
  is_active: boolean;
  created_at: string;
  rule_config?: any;
};

type Setup = {
  id: string;
  strategy_id: string | null;
  name: string;
  description: string | null;
};

type StrategyStats = {
  totalTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  totalPnl: number;
  avgRR: number;
};

const emptyForm = { name: '', description: '', rules: '', is_active: true, minRR: '2', maxRiskPercent: '1', requireStopLoss: true, requireTakeProfit: true, requireEntryReason: true, requirePsychology: false, allowedSessions: [] as string[], allowedDirections: [] as string[], blockedPsychologyTags: [] as string[] };
const SESSION_OPTIONS = [{v:'london',l:'لندن'},{v:'new_york',l:'نیویورک'},{v:'asian',l:'آسیا'}];
const PSYCH_BLOCKS = [{v:'fomo',l:'🏃 FOMO'},{v:'revenge',l:'😡 انتقام'},{v:'greed',l:'🤑 طمع'},{v:'overtrading',l:'🔄 اورترید'}];

export default function Strategies() {
  const { user } = useAuth();
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [setups, setSetups] = useState<Setup[]>([]);
  const [stats, setStats] = useState<Record<string, StrategyStats>>({});
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<string | null>(null);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [setupForm, setSetupForm] = useState<{ strategyId: string; name: string; description: string } | null>(null);
  const [deleteSetupId, setDeleteSetupId] = useState<string | null>(null);

  const loadAll = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    const [{ data: strategiesData }, { data: setupsData }, { data: tradesData }] = await Promise.all([
      supabase.from('strategies').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('setups').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('trades').select('strategy_id, result, pnl_amount, rr_ratio').eq('user_id', user.id).eq('account_id', getActiveAccountId()).not('result', 'eq', 'open'),
    ]);

    setStrategies(strategiesData || []);
    setSetups(setupsData || []);

    const statsMap: Record<string, StrategyStats> = {};
    (tradesData || []).forEach((t: any) => {
      if (!t.strategy_id) return;
      if (!statsMap[t.strategy_id]) {
        statsMap[t.strategy_id] = { totalTrades: 0, wins: 0, losses: 0, winRate: 0, totalPnl: 0, avgRR: 0 };
      }
      const s = statsMap[t.strategy_id];
      s.totalTrades += 1;
      if (t.result === 'win') s.wins += 1;
      if (t.result === 'loss') s.losses += 1;
      s.totalPnl += Number(t.pnl_amount) || 0;
      if (t.rr_ratio) s.avgRR += Number(t.rr_ratio);
    });
    Object.values(statsMap).forEach(s => {
      s.winRate = s.totalTrades > 0 ? (s.wins / s.totalTrades) * 100 : 0;
      s.avgRR = s.totalTrades > 0 ? s.avgRR / s.totalTrades : 0;
    });
    setStats(statsMap);
    setLoading(false);
  }, [user]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (s: Strategy) => {
    setEditingId(s.id);
    setForm({ ...emptyForm, name: s.name, description: s.description || '', rules: s.rules || '', is_active: s.is_active, minRR: String(s.rule_config?.minRR ?? 2), maxRiskPercent: String(s.rule_config?.maxRiskPercent ?? 1), requireStopLoss: s.rule_config?.requireStopLoss ?? true, requireTakeProfit: s.rule_config?.requireTakeProfit ?? true, requireEntryReason: s.rule_config?.requireEntryReason ?? true, requirePsychology: s.rule_config?.requirePsychology ?? false, allowedSessions: s.rule_config?.allowedSessions ?? [], allowedDirections: s.rule_config?.allowedDirections ?? [], blockedPsychologyTags: s.rule_config?.blockPsychologyTags ?? [] });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!user || !form.name.trim()) return;
    setSaving(true);
    if (editingId) {
      await supabase.from('strategies').update({
        name: form.name.trim(),
        description: form.description.trim() || null,
        rules: form.rules.trim() || null,
        is_active: form.is_active,
        rule_config: { minRR: Number(form.minRR) || undefined, maxRiskPercent: Number(form.maxRiskPercent) || undefined, requireStopLoss: form.requireStopLoss, requireTakeProfit: form.requireTakeProfit, requireEntryReason: form.requireEntryReason, requirePsychology: form.requirePsychology, allowedSessions: form.allowedSessions, allowedDirections: form.allowedDirections, blockPsychologyTags: form.blockedPsychologyTags },
      }).eq('id', editingId).eq('user_id', user.id);
    } else {
      await supabase.from('strategies').insert({
        user_id: user.id,
        name: form.name.trim(),
        description: form.description.trim() || null,
        rules: form.rules.trim() || null,
        is_active: form.is_active,
        rule_config: { minRR: Number(form.minRR) || undefined, maxRiskPercent: Number(form.maxRiskPercent) || undefined, requireStopLoss: form.requireStopLoss, requireTakeProfit: form.requireTakeProfit, requireEntryReason: form.requireEntryReason, requirePsychology: form.requirePsychology, allowedSessions: form.allowedSessions, allowedDirections: form.allowedDirections, blockPsychologyTags: form.blockedPsychologyTags },
      });
    }
    setSaving(false);
    setShowForm(false);
    loadAll();
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    await supabase.from('strategies').delete().eq('id', id).eq('user_id', user.id);
    setDeleteId(null);
    loadAll();
  };

  const handleToggleActive = async (s: Strategy) => {
    if (!user) return;
    await supabase.from('strategies').update({ is_active: !s.is_active }).eq('id', s.id).eq('user_id', user.id);
    loadAll();
  };

  const handleSaveSetup = async () => {
    if (!user || !setupForm || !setupForm.name.trim()) return;
    await supabase.from('setups').insert({
      user_id: user.id,
      strategy_id: setupForm.strategyId,
      name: setupForm.name.trim(),
      description: setupForm.description.trim() || null,
    });
    setSetupForm(null);
    loadAll();
  };

  const handleDeleteSetup = async (id: string) => {
    if (!user) return;
    await supabase.from('setups').delete().eq('id', id).eq('user_id', user.id);
    setDeleteSetupId(null);
    loadAll();
  };

  if (loading) {
    return (
      <div className="page-container flex items-center justify-center min-h-[60vh]" dir="rtl">
        <div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-bold text-white">استراتژی‌ها</h1>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-1.5 text-sm">
          <Plus className="w-4 h-4" /> استراتژی جدید
        </button>
      </div>

      {strategies.length === 0 ? (
        <div className="glass-card p-10 text-center">
          <Layers className="w-10 h-10 text-dark-500 mx-auto mb-3" />
          <p className="text-dark-400 text-sm mb-4">هنوز استراتژی‌ای ثبت نکرده‌اید.</p>
          <button onClick={openCreate} className="btn-primary mx-auto text-sm">تعریف اولین استراتژی</button>
        </div>
      ) : (
        <div className="space-y-3">
          {strategies.map(s => {
            const st = stats[s.id];
            const strategySetups = setups.filter(su => su.strategy_id === s.id);
            const isOpen = expanded === s.id;
            return (
              <div key={s.id} className="glass-card overflow-hidden">
                <div className="p-4 flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-base font-semibold text-white">{s.name}</h3>
                      <button
                        onClick={() => handleToggleActive(s)}
                        className={`text-[11px] px-2 py-0.5 rounded-full border transition-colors ${
                          s.is_active
                            ? 'bg-success-500/15 text-success-400 border-success-500/20'
                            : 'bg-dark-500/20 text-dark-400 border-white/10'
                        }`}
                      >
                        {s.is_active ? 'فعال' : 'غیرفعال'}
                      </button>
                    </div>
                    {s.description && <p className="text-sm text-dark-400 mt-1.5">{s.description}</p>}
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <button onClick={() => openEdit(s)} className="p-2 rounded-lg text-dark-400 hover:text-gold-400 hover:bg-white/5">
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button onClick={() => setDeleteId(s.id)} className="p-2 rounded-lg text-dark-400 hover:text-danger-400 hover:bg-white/5">
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setExpanded(isOpen ? null : s.id)}
                      className="p-2 rounded-lg text-dark-400 hover:text-white hover:bg-white/5"
                    >
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Stats strip */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 px-4 pb-4">
                  <div className="rounded-lg bg-dark-900/60 p-2.5 flex items-center gap-2">
                    <ListChecks className="w-3.5 h-3.5 text-dark-400" />
                    <div>
                      <p className="text-[11px] text-dark-400">معاملات</p>
                      <p className="text-sm font-semibold text-white number-ltr">{st?.totalTrades ?? 0}</p>
                    </div>
                  </div>
                  <div className="rounded-lg bg-dark-900/60 p-2.5 flex items-center gap-2">
                    <Percent className="w-3.5 h-3.5 text-dark-400" />
                    <div>
                      <p className="text-[11px] text-dark-400">وین‌ریت</p>
                      <p className="text-sm font-semibold text-white number-ltr">{st ? st.winRate.toFixed(0) : 0}%</p>
                    </div>
                  </div>
                  <div className="rounded-lg bg-dark-900/60 p-2.5 flex items-center gap-2">
                    {st && st.totalPnl >= 0 ? <TrendingUp className="w-3.5 h-3.5 text-success-400" /> : <TrendingDown className="w-3.5 h-3.5 text-danger-400" />}
                    <div>
                      <p className="text-[11px] text-dark-400">سود/زیان</p>
                      <p className={`text-sm font-semibold number-ltr ${st && st.totalPnl >= 0 ? 'profit-text' : 'loss-text'}`}>
                        {formatCurrency(st?.totalPnl ?? 0)}
                      </p>
                    </div>
                  </div>
                  <div className="rounded-lg bg-dark-900/60 p-2.5 flex items-center gap-2">
                    <Target className="w-3.5 h-3.5 text-dark-400" />
                    <div>
                      <p className="text-[11px] text-dark-400">میانگین R</p>
                      <p className="text-sm font-semibold text-white number-ltr">{formatRR(st?.avgRR ?? 0)}</p>
                    </div>
                  </div>
                </div>

                {isOpen && (
                  <div className="border-t border-white/5 p-4 space-y-4">
                    {s.rules && (
                      <div>
                        <p className="label-text">قوانین استراتژی</p>
                        <p className="text-sm text-dark-300 leading-7 whitespace-pre-wrap">{s.rules}</p>
                      </div>
                    )}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <p className="label-text mb-0">ست‌آپ‌های این استراتژی</p>
                        <button
                          onClick={() => setSetupForm({ strategyId: s.id, name: '', description: '' })}
                          className="text-xs text-gold-400 hover:text-gold-300 flex items-center gap-1"
                        >
                          <Plus className="w-3.5 h-3.5" /> افزودن ست‌آپ
                        </button>
                      </div>
                      {strategySetups.length === 0 ? (
                        <p className="text-xs text-dark-500">ست‌آپی تعریف نشده است.</p>
                      ) : (
                        <div className="space-y-2">
                          {strategySetups.map(su => (
                            <div key={su.id} className="flex items-start justify-between gap-2 rounded-lg bg-dark-900/60 p-2.5">
                              <div>
                                <p className="text-sm text-white">{su.name}</p>
                                {su.description && <p className="text-xs text-dark-400 mt-0.5">{su.description}</p>}
                              </div>
                              <button onClick={() => setDeleteSetupId(su.id)} className="p-1 text-dark-400 hover:text-danger-400 flex-shrink-0">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Strategy form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-lg space-y-4">
            <h3 className="text-lg font-semibold text-white">{editingId ? 'ویرایش استراتژی' : 'استراتژی جدید'}</h3>
            <div>
              <label className="label-text">نام استراتژی</label>
              <input
                type="text"
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                className="input-field"
                placeholder="مثلاً: شکست ساختار + پولبک"
                autoFocus
              />
            </div>
            <div>
              <label className="label-text">توضیح کوتاه</label>
              <input
                type="text"
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                className="input-field"
                placeholder="یک خط درباره‌ی ایده‌ی این استراتژی"
              />
            </div>
            <div>
              <label className="label-text">قوانین ورود / خروج</label>
              <textarea
                value={form.rules}
                onChange={e => setForm(f => ({ ...f, rules: e.target.value }))}
                className="input-field min-h-[120px] resize-y"
                placeholder="شرایط دقیق تایید ورود، حد ضرر، حد سود و مدیریت معامله را بنویسید..."
              />
            </div>
            <div className="rounded-xl border border-gold-500/15 bg-gold-500/[0.035] p-3 space-y-3">
              <div className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-gold-400" /><div><p className="text-sm font-semibold text-white">🛡️ قوانین اجرایی استراتژی</p><p className="text-[10px] text-dark-500">Trading OS این قوانین را قبل از ثبت معامله بررسی می‌کند.</p></div></div>
              <div className="grid grid-cols-2 gap-2">
                <div><label className="label-text">حداقل R:R</label><input type="number" step="0.1" min="0" value={form.minRR} onChange={e => setForm(f => ({...f,minRR:e.target.value}))} className="input-field number-ltr" /></div>
                <div><label className="label-text">سقف ریسک %</label><input type="number" step="0.1" min="0" value={form.maxRiskPercent} onChange={e => setForm(f => ({...f,maxRiskPercent:e.target.value}))} className="input-field number-ltr" /></div>
              </div>
              <div className="flex flex-wrap gap-2">{SESSION_OPTIONS.map(o => <button type="button" key={o.v} onClick={() => setForm(f => ({...f,allowedSessions:f.allowedSessions.includes(o.v)?f.allowedSessions.filter(x=>x!==o.v):[...f.allowedSessions,o.v]}))} className={`px-2.5 py-1 rounded-lg text-[11px] border ${form.allowedSessions.includes(o.v)?'bg-gold-500/15 border-gold-500/40 text-gold-300':'border-white/10 text-dark-400'}`}>سشن: {o.l}</button>)}</div>
              <div className="flex flex-wrap gap-2">{PSYCH_BLOCKS.map(o => <button type="button" key={o.v} onClick={() => setForm(f => ({...f,blockedPsychologyTags:f.blockedPsychologyTags.includes(o.v)?f.blockedPsychologyTags.filter(x=>x!==o.v):[...f.blockedPsychologyTags,o.v]}))} className={`px-2.5 py-1 rounded-lg text-[11px] border ${form.blockedPsychologyTags.includes(o.v)?'bg-danger-500/15 border-danger-500/30 text-danger-300':'border-white/10 text-dark-400'}`}>{o.l}</button>)}</div>
              <div className="grid grid-cols-2 gap-2 text-[11px] text-dark-300">
                {[['requireStopLoss','حد ضرر الزامی'],['requireTakeProfit','تارگت الزامی'],['requireEntryReason','دلیل ورود الزامی'],['requirePsychology','روانشناسی الزامی']].map(([k,l]) => <label key={k} className="flex items-center gap-2"><input type="checkbox" checked={(form as any)[k]} onChange={e => setForm(f => ({...f,[k]:e.target.checked}))} className="w-3.5 h-3.5 accent-gold-500" />{l}</label>)}
              </div>
            </div>

            <label className="flex items-center gap-2 cursor-pointer w-fit">
              <input
                type="checkbox"
                checked={form.is_active}
                onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))}
                className="w-4 h-4 accent-gold-500"
              />
              <span className="text-sm text-dark-300">استراتژی فعال است</span>
            </label>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowForm(false)} className="btn-secondary">انصراف</button>
              <button onClick={handleSave} disabled={!form.name.trim() || saving} className="btn-primary">
                {saving ? 'در حال ذخیره...' : 'ذخیره'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Setup form modal */}
      {setupForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-semibold text-white">ست‌آپ جدید</h3>
            <div>
              <label className="label-text">نام ست‌آپ</label>
              <input
                type="text"
                value={setupForm.name}
                onChange={e => setSetupForm(f => f && ({ ...f, name: e.target.value }))}
                className="input-field"
                placeholder="مثلاً: واگرایی RSI روی H4"
                autoFocus
              />
            </div>
            <div>
              <label className="label-text">توضیح</label>
              <textarea
                value={setupForm.description}
                onChange={e => setSetupForm(f => f && ({ ...f, description: e.target.value }))}
                className="input-field min-h-[80px] resize-y"
              />
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setSetupForm(null)} className="btn-secondary">انصراف</button>
              <button onClick={handleSaveSetup} disabled={!setupForm.name.trim()} className="btn-primary">ذخیره</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete strategy confirm */}
      {deleteId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف استراتژی</h3>
            <p className="text-sm text-dark-400 mb-4">
              معاملات ثبت‌شده با این استراتژی حذف نمی‌شوند، فقط ارتباطشان با آن قطع می‌شود. ادامه می‌دهید؟
            </p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => handleDelete(deleteId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete setup confirm */}
      {deleteSetupId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف ست‌آپ</h3>
            <p className="text-sm text-dark-400 mb-4">آیا مطمئن هستید؟ این عمل قابل بازگشت نیست.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteSetupId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => handleDeleteSetup(deleteSetupId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}