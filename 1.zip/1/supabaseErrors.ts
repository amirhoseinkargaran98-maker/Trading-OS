export function explainSupabaseError(error: { message?: string; code?: string } | null | undefined): string {
  if (!error) return '';
  const message = error.message || 'خطای نامشخص از Supabase';
  const code = error.code || '';
  const normalized = message.toLowerCase();

  if (
    code === 'PGRST205' ||
    normalized.includes('could not find the table') ||
    normalized.includes('schema cache')
  ) {
    return 'دیتابیس Trading OS روی پروژه Supabase کامل راه‌اندازی نشده است. فایل supabase/COMPLETE_DATABASE_SETUP.sql را در Supabase → SQL Editor اجرا کنید و بعد صفحه را بازخوانی کنید.';
  }

  if (code === '42501' || normalized.includes('row-level security')) {
    return 'مجوز دسترسی Supabase (RLS) برای این عملیات تنظیم نشده است. بخش Policyهای فایل COMPLETE_DATABASE_SETUP.sql را اجرا کنید.';
  }

  if (normalized.includes('invalid api key') || normalized.includes('jwt')) {
    return 'کلید یا آدرس Supabase در فایل .env درست تنظیم نشده است.';
  }

  return `${message}${code ? ` · کد ${code}` : ''}`;
}
