-- Process/review persistence integrity
-- These fields are consumed by analytics and must exist on every deployment.
ALTER TABLE public.trades
  ADD COLUMN IF NOT EXISTS process_score numeric(5,2),
  ADD COLUMN IF NOT EXISTS review_completed boolean NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS trades_process_score_idx ON public.trades(process_score);
CREATE INDEX IF NOT EXISTS trades_review_completed_idx ON public.trades(review_completed);


-- Deterministic backfill for existing rows only. No synthetic/random values are created.
-- Formula intentionally mirrors estimateProcessScore() in src/lib/tradingEngine.ts.
UPDATE public.trades
SET process_score = GREATEST(0, LEAST(100,
  100
  - 15 * COALESCE(array_length(ARRAY(
      SELECT x FROM unnest(COALESCE(psychology_tags, ARRAY[]::text[])) AS x
      WHERE x IN ('fomo','revenge','overtrading','greed','hesitation')
    ), 1), 0)
  - CASE WHEN COALESCE(risk_percent, 0) > 1 THEN 25 ELSE 0 END
  - CASE WHEN COALESCE(trim(mistakes), '') <> '' THEN 15 ELSE 0 END
))
WHERE process_score IS NULL;

UPDATE public.trades
SET review_completed = (
  COALESCE(is_open, false) = false
  AND (
    COALESCE(trim(lessons), '') <> ''
    OR COALESCE(trim(mistakes), '') <> ''
    OR COALESCE(trim(exit_reason), '') <> ''
  )
  AND COALESCE(trim(feeling_after), '') <> ''
)
WHERE review_completed IS DISTINCT FROM true;


ALTER TABLE public.trades
  DROP CONSTRAINT IF EXISTS trades_process_score_range_chk;
ALTER TABLE public.trades
  ADD CONSTRAINT trades_process_score_range_chk
  CHECK (process_score IS NULL OR (process_score >= 0 AND process_score <= 100));
