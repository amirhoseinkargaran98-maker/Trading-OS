import { useState } from 'react';
import { AlertTriangle, BrainCircuit, CheckCircle2, ShieldAlert } from 'lucide-react';
import { askTradingCoach } from '@/lib/aiCoach';

export default function PreTradeCoach({ trade, maxRiskPercent = 1 }: { trade: Record<string, unknown>; maxRiskPercent?: number }) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [blocked, setBlocked] = useState(false);

  async function check() {
    setLoading(true);
    setResult('');
    setBlocked(false);
    try {
      const calculated = (trade.calculated || {}) as Record<string, unknown>;
      const risk = Number(calculated.risk_percent || 0);
      const rr = Number(calculated.rr_ratio || 0);
      if (risk > maxRiskPercent) {
        setBlocked(true);
        setResult(`ریسک این معامله (${risk.toFixed(2)}٪) بیشتر از سقف مجاز خودت (${maxRiskPercent}٪) است. قبل از ثبت، حجم یا حد ضرر را اصلاح کن.`);
        return;
      }
      if (rr > 0 && rr < 2) {
        setResult('معامله از نظر سیستم نیاز به احتیاط دارد: R:R کمتر از 2 است. اگر دلیل موجهی در پلن نداری، صبر کن.');
      } else {
        const response = await askTradingCoach({ mode: 'pre_trade', trades: [trade], question: 'این معامله را قبل از ثبت از نظر ریسک، کیفیت ستاپ، روانشناسی و سازگاری با پلن بررسی کن. فقط نقاط ضعف و یک اقدام مشخص را بگو.' });
        setResult(response.text || 'معامله از نظر داده‌های فعلی قابل بررسی است؛ قبل از ثبت، چک‌لیست پلن را کامل کن.');
      }
    } catch (error) {
      setResult(error instanceof Error ? error.message : 'AI Coach در دسترس نیست.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="glass-card p-4 border-gold-500/15 bg-gold-500/[0.03]">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-gold-500/10 flex items-center justify-center"><BrainCircuit className="w-4 h-4 text-gold-400" /></div><div><p className="text-xs text-gold-400 font-semibold">PRE-TRADE CHECK</p><p className="text-sm font-semibold text-white mt-0.5">قبل از ثبت، مربی را درگیر کن</p></div></div>
        <button type="button" onClick={check} disabled={loading} className="btn-secondary inline-flex items-center gap-2">{loading ? 'تحلیل...' : 'بررسی معامله'}</button>
      </div>
      {result && <div className={`mt-4 rounded-xl border p-3 text-sm leading-7 ${blocked ? 'border-danger-500/20 bg-danger-500/10 text-danger-300' : 'border-white/5 bg-black/20 text-dark-200'}`}><div className="flex gap-2 items-start">{blocked ? <ShieldAlert className="w-4 h-4 mt-1 text-danger-400" /> : result.includes('احتیاط') ? <AlertTriangle className="w-4 h-4 mt-1 text-gold-400" /> : <CheckCircle2 className="w-4 h-4 mt-1 text-success-400" />}<span>{result}</span></div></div>}
    </div>
  );
}
