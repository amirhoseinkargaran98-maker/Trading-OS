/*
# Trading Constitution

## Overview
A single place for a trader's own written rules — Risk, Entry, Exit, Session,
Psychology, No-Trade, and Recovery rules — split into HARD (never break) and
SOFT (guideline, use judgment). Previously these rules were scattered across
Risk Management and Strategies with no unified place to read/commit to them.

## Security
RLS enabled; each user only sees and manages their own rules.
*/

CREATE TABLE IF NOT EXISTS trading_constitution_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category text NOT NULL CHECK (category IN ('risk','entry','exit','session','psychology','no_trade','recovery')),
  rule_type text NOT NULL DEFAULT 'hard' CHECK (rule_type IN ('hard','soft')),
  rule_text text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trading_constitution_rules ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "own_constitution_rules_select" ON trading_constitution_rules;
CREATE POLICY "own_constitution_rules_select" ON trading_constitution_rules FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_constitution_rules_insert" ON trading_constitution_rules;
CREATE POLICY "own_constitution_rules_insert" ON trading_constitution_rules FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_constitution_rules_update" ON trading_constitution_rules;
CREATE POLICY "own_constitution_rules_update" ON trading_constitution_rules FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_constitution_rules_delete" ON trading_constitution_rules;
CREATE POLICY "own_constitution_rules_delete" ON trading_constitution_rules FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS trading_constitution_rules_user_idx ON trading_constitution_rules(user_id, category);
