-- PHASE 9: structured strategy rule engine
alter table strategies add column if not exists rule_config jsonb not null default '{}'::jsonb;
create index if not exists strategies_rule_config_gin on strategies using gin (rule_config);
