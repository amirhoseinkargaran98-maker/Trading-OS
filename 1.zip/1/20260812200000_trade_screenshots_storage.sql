/*
# Trade Screenshots Storage

## Overview
Creates a public storage bucket for trade screenshots (before/entry/after images)
and locks down write access so each user can only manage files inside their own
folder, named by their user id: `{user_id}/{trade_id}/{filename}`.

Reads are public (needed to render images via public URL without signed URLs),
writes (insert/update/delete) are restricted to the authenticated owner.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('trade-screenshots', 'trade-screenshots', false)
ON CONFLICT (id) DO UPDATE SET public = false;

DROP POLICY IF EXISTS "public_read_trade_screenshots" ON storage.objects;
DROP POLICY IF EXISTS "owner_read_trade_screenshots" ON storage.objects;
CREATE POLICY "owner_read_trade_screenshots"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'trade-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "owner_insert_trade_screenshots" ON storage.objects;
CREATE POLICY "owner_insert_trade_screenshots"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'trade-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "owner_update_trade_screenshots" ON storage.objects;
CREATE POLICY "owner_update_trade_screenshots"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'trade-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'trade-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "owner_delete_trade_screenshots" ON storage.objects;
CREATE POLICY "owner_delete_trade_screenshots"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'trade-screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);
