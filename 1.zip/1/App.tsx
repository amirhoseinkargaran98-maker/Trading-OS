import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { lazy, Suspense, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/AppLayout';
import AuthPage from '@/pages/AuthPage';
const Dashboard = lazy(() => import('@/pages/Dashboard'));
const TradeForm = lazy(() => import('@/pages/TradeForm'));
const TradeHistory = lazy(() => import('@/pages/TradeHistory'));
const TradeDetail = lazy(() => import('@/pages/TradeDetail'));
const Analytics = lazy(() => import('@/pages/Analytics'));
const Strategies = lazy(() => import('@/pages/Strategies'));
const RiskManagement = lazy(() => import('@/pages/RiskManagement'));
const Goals = lazy(() => import('@/pages/Goals'));
const Journal = lazy(() => import('@/pages/Journal'));
const TradingCalendar = lazy(() => import('@/pages/TradingCalendar'));
const Settings = lazy(() => import('@/pages/Settings'));
const AICoach = lazy(() => import('@/pages/AICoach'));
const ProcessIntelligence = lazy(() => import('@/pages/ProcessIntelligence'));
const TradingIntelligence = lazy(() => import('@/pages/TradingIntelligence'));
const ImprovementCenter = lazy(() => import('@/pages/ImprovementCenter'));
const EdgeLab = lazy(() => import('@/pages/EdgeLab'));
const ContextIntelligence = lazy(() => import('@/pages/ContextIntelligence'));
const PropMode = lazy(() => import('@/pages/PropMode'));
const TradingConstitution = lazy(() => import('@/pages/TradingConstitution'));
const Psychology = lazy(() => import('@/pages/Psychology'));
const Reports = lazy(() => import('@/pages/Reports'));
const DataCenter = lazy(() => import('@/pages/DataCenter'));
const NewsGuard = lazy(() => import('@/pages/NewsGuard'));

// Preload route chunks during browser idle time so navigation is effectively
// instant after the first screen is ready. This avoids waiting for a lazy
// chunk download on every first click.
const preloadRoutes = [
  () => import('@/pages/Dashboard'), () => import('@/pages/TradeForm'),
  () => import('@/pages/TradeHistory'), () => import('@/pages/TradeDetail'),
  () => import('@/pages/Analytics'), () => import('@/pages/Strategies'),
  () => import('@/pages/RiskManagement'), () => import('@/pages/Goals'),
  () => import('@/pages/Journal'), () => import('@/pages/TradingCalendar'),
  () => import('@/pages/Settings'), () => import('@/pages/AICoach'),
  () => import('@/pages/ProcessIntelligence'), () => import('@/pages/TradingIntelligence'),
  () => import('@/pages/ImprovementCenter'), () => import('@/pages/EdgeLab'),
  () => import('@/pages/ContextIntelligence'), () => import('@/pages/PropMode'),
  () => import('@/pages/TradingConstitution'), () => import('@/pages/Psychology'),
  () => import('@/pages/Reports'), () => import('@/pages/DataCenter'),
  () => import('@/pages/NewsGuard'),
];

function RoutePreloader() {
  useEffect(() => {
    const run = () => { void Promise.allSettled(preloadRoutes.map(load => load())); };
    if ('requestIdleCallback' in window) {
      const id = (window as any).requestIdleCallback(run, { timeout: 2500 });
      return () => (window as any).cancelIdleCallback?.(id);
    }
    const id = window.setTimeout(run, 1200);
    return () => window.clearTimeout(id);
  }, []);
  return null;
}

function ProtectedRoutes() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="w-10 h-10 border-2 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-sm text-dark-400">در حال آماده‌سازی Trading OS...</p>
        </div>
      </div>
    );
  }

  if (!user) return <AuthPage />;

  return (
    <AppLayout>
      <RoutePreloader />
      <Suspense fallback={<div className="min-h-full flex items-center justify-center p-8" dir="rtl"><div className="text-center"><div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" /><p className="text-xs text-dark-400">در حال بارگذاری بخش...</p></div></div>}>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/trade/new" element={<TradeForm />} />
        <Route path="/trade/:id/edit" element={<TradeForm />} />
        <Route path="/trade/:id" element={<TradeDetail />} />
        <Route path="/history" element={<TradeHistory />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/calendar" element={<TradingCalendar />} />
        <Route path="/psychology" element={<Psychology />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/data" element={<DataCenter />} />
        <Route path="/news" element={<NewsGuard />} />
        <Route path="/strategies" element={<Strategies />} />
        <Route path="/risk" element={<RiskManagement />} />
        <Route path="/goals" element={<Goals />} />
        <Route path="/journal" element={<Journal />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/ai-coach" element={<AICoach />} />
        <Route path="/process-intelligence" element={<ProcessIntelligence />} />
        <Route path="/trading-intelligence" element={<TradingIntelligence />} />
        <Route path="/improvement" element={<ImprovementCenter />} />
        <Route path="/edge-lab" element={<EdgeLab />} />
        <Route path="/context-intelligence" element={<ContextIntelligence />} />
        <Route path="/prop-mode" element={<PropMode />} />
        <Route path="/constitution" element={<TradingConstitution />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </Suspense>
    </AppLayout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ProtectedRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
