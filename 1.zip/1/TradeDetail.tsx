import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Edit, ArrowRight, TrendingUp, TrendingDown, LockKeyhole } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import {
  formatCurrency, toPersianDate, toPersianDateTime, getSessionLabel,
  getDirectionLabel, getResultLabel, getResultBadgeClass,
  getTimeframeLabel, getConditionLabel, getFeelingLabel, getPsychologyLabel, formatLotSize
} from '@/lib/utils';
import TradeScreenshots from '@/components/TradeScreenshots';
import TradeShareCard from '@/components/TradeShareCard';
import TradeReplay from '@/components/TradeReplay';
import { calculateTradeDataQuality } from '@/lib/tradingEngine';
import PostTradeCoach from '@/components/ai/PostTradeCoach';

export default function TradeDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [trade, setTrade] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id || !user) return;
    supabase
      .from('trades')
      .select('*, strategies(name), setups(name)')
      .eq('id', id)
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        setTrade(data);
        setLoading(false);
      });
  }, [id, user]);

  if (loading) return (
    <div className="page-container flex items-center justify-center py-20">
      <div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (!trade) return (
    <div className="page-container text-center py-20 text-dark-400">معامله یافت نشد</div>
  );

  const isWin = trade.result === 'win';
  const isLoss = trade.result === 'loss';
  const dataQuality = calculateTradeDataQuality(trade);

  const closeTradeNow = () => {
    if (!id || trade.result !== 'open') return;
    navigate(`/trade/${id}/edit?focus=exit`);
  };

  return (
    <div className="page-container" dir="rtl">
      {/* Header */}
      <div className="section-header">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="btn-secondary p-1.5 !px-1.5">
            <ArrowRight className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold font-mono text-gold-400">{trade.symbol}</span>
              <span className={`text-sm font-semibold ${trade.direction === 'buy' ? 'text-success-400' : 'text-danger-400'}`}>
                {trade.direction === 'buy' ? '▲' : '▼'} {getDirectionLabel(trade.direction)}
              </span>
              <span className={getResultBadgeClass(trade.result)}>{getResultLabel(trade.result)}</span>
            </div>
            <p className="text-sm text-dark-400 mt-0.5">{toPersianDate(trade.trade_date)} — معامله #{trade.trade_number}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <TradeShareCard trade={trade} />
          {trade.is_open && (
            <button onClick={closeTradeNow} className="btn-secondary flex items-center gap-1.5 text-sm">
              <LockKeyhole className="w-4 h-4" />
              بستن معامله
            </button>
          )}
          <button onClick={() => navigate(`/trade/${id}/edit`)} className="btn-primary flex items-center gap-1.5 text-sm">
            <Edit className="w-4 h-4" />
            ویرایش
          </button>
        </div>
      </div>

      {/* P&L Banner */}
      <div className={`glass-card p-4 border ${isWin ? 'border-success-500/30' : isLoss ? 'border-danger-500/30' : 'border-white/10'}`}>
        <div className="flex flex-wrap items-center gap-6">
          <div>
            <p className="text-xs text-dark-400 mb-1">P&L</p>
            <p className={`text-3xl font-bold number-ltr ${isWin ? 'text-success-400' : isLoss ? 'text-danger-400' : 'text-white'}`}>
              {formatCurrency(trade.pnl_amount)}
            </p>
          </div>
          {trade.pnl_percent && (
            <div>
              <p className="text-xs text-dark-400 mb-1">درصد</p>
              <p className={`text-xl font-bold number-ltr ${isWin ? 'text-success-400' : 'text-danger-400'}`}>
                {trade.pnl_percent > 0 ? '+' : ''}{trade.pnl_percent?.toFixed(2)}%
              </p>
            </div>
          )}
          {trade.rr_ratio && (
            <div>
              <p className="text-xs text-dark-400 mb-1">R:R</p>
              <p className="text-xl font-bold text-white number-ltr">{trade.rr_ratio.toFixed(2)}R</p>
            </div>
          )}
          {trade.r_multiple && (
            <div>
              <p className="text-xs text-dark-400 mb-1">R Multiple</p>
              <p className={`text-xl font-bold number-ltr ${trade.r_multiple > 0 ? 'text-success-400' : 'text-danger-400'}`}>
                {trade.r_multiple > 0 ? '+' : ''}{trade.r_multiple.toFixed(2)}R
              </p>
            </div>
          )}
          {trade.risk_amount && (
            <div>
              <p className="text-xs text-dark-400 mb-1">ریسک</p>
              <p className="text-xl font-bold text-danger-400 number-ltr">{formatCurrency(trade.risk_amount)}</p>
            </div>
          )}
        </div>
        {((trade.commission || 0) > 0 || (trade.swap || 0) > 0) && (
          <div className="flex items-center gap-4 mt-3 pt-3 border-t border-white/5 text-xs">
            <span className="text-dark-400">سود ناخالص: <span className="text-white number-ltr">{formatCurrency(trade.gross_pnl_amount ?? trade.pnl_amount)}</span></span>
            <span className="text-dark-400">کمیسیون: <span className="text-danger-400 number-ltr">{formatCurrency(trade.commission || 0)}</span></span>
            <span className="text-dark-400">سواپ: <span className="text-danger-400 number-ltr">{formatCurrency(trade.swap || 0)}</span></span>
            <span className="text-dark-300 font-semibold">خالص: <span className="number-ltr">{formatCurrency(trade.pnl_amount)}</span></span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Trade Info */}
        <div className="glass-card p-4">
          <h2 className="section-title"><TrendingUp className="w-4 h-4 text-gold-400" /> اطلاعات معامله</h2>
          <div className="space-y-2">
            <InfoRow label="تاریخ" value={toPersianDate(trade.trade_date)} />
            <InfoRow label="تایم‌فریم" value={getTimeframeLabel(trade.timeframe)} />
            <InfoRow label="سشن" value={getSessionLabel(trade.session)} />
            <InfoRow label="شرایط بازار" value={getConditionLabel(trade.market_condition)} />
            <InfoRow label="زمان ورود" value={toPersianDateTime(trade.entry_time)} />
            <InfoRow label="زمان خروج" value={toPersianDateTime(trade.exit_time)} />
            {trade.duration_minutes && (
              <InfoRow label="مدت" value={`${trade.duration_minutes} دقیقه`} />
            )}
            <InfoRow label="استراتژی" value={trade.strategies?.name || '—'} />
            <InfoRow label="ستاپ" value={trade.setups?.name || '—'} />
          </div>
        </div>

        {/* Prices */}
        <div className="glass-card p-4">
          <h2 className="section-title"><TrendingDown className="w-4 h-4 text-gold-400" /> قیمت‌ها</h2>
          <div className="space-y-2">
            <InfoRow label="قیمت ورود" value={trade.entry_price?.toFixed(5) || '—'} ltr />
            <InfoRow label="قیمت خروج" value={trade.exit_price?.toFixed(5) || '—'} ltr />
            <InfoRow label="Stop Loss" value={trade.stop_loss?.toFixed(5) || '—'} ltr />
            <InfoRow label="Take Profit" value={trade.take_profit?.toFixed(5) || '—'} ltr />
            <InfoRow label="Lot Size" value={formatLotSize(trade.lot_size)} ltr />
            <InfoRow label="Contract Size" value={trade.contract_size?.toString() || '—'} ltr />
            <InfoRow label="ریسک $" value={formatCurrency(trade.risk_amount)} ltr />
            <InfoRow label="ریسک %" value={trade.risk_percent ? `${trade.risk_percent.toFixed(2)}%` : '—'} ltr />
            <InfoRow label="سرمایه قبل" value={`$${trade.capital_before?.toLocaleString() || '—'}`} ltr />
            <InfoRow label="سرمایه بعد" value={`$${trade.capital_after?.toLocaleString() || '—'}`} ltr />
          </div>
        </div>
      </div>

      {/* Psychology */}
      {(trade.feeling_before || trade.feeling_during || trade.feeling_after || trade.psychology_tags?.length) && (
        <div className="glass-card p-4">
          <h2 className="section-title">روانشناسی</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {trade.feeling_before && <InfoRow label="حس قبل" value={getFeelingLabel(trade.feeling_before)} />}
            {trade.feeling_during && <InfoRow label="حس حین" value={getFeelingLabel(trade.feeling_during)} />}
            {trade.feeling_after && <InfoRow label="حس بعد" value={getFeelingLabel(trade.feeling_after)} />}
          </div>
          {trade.psychology_tags?.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {trade.psychology_tags.map((tag: string) => (
                <span key={tag} className="px-2.5 py-1 bg-gold-500/10 border border-gold-500/20 text-gold-400 text-xs rounded-lg">
                  {getPsychologyLabel(tag)}
                </span>
              ))}
            </div>
          )}
        </div>
      )}


      {/* Data integrity / process evidence */}
      <div className="glass-card p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="section-title mb-1">کیفیت داده و فرآیند</h2>
            <p className="text-xs text-dark-400">این امتیاز فقط کامل بودن ژورنال را می‌سنجد و با Process Score یا نتیجه معامله یکی نیست.</p>
          </div>
          <div className="text-center min-w-[90px]">
            <div className="text-2xl font-black text-gold-400">{dataQuality.score}%</div>
            <div className="text-[10px] text-dark-500">Data Quality</div>
          </div>
        </div>
        <div className="mt-3 h-2 rounded-full bg-dark-800 overflow-hidden"><div className="h-full bg-gold-500 transition-all" style={{ width: `${dataQuality.score}%` }} /></div>
        {dataQuality.missing.length > 0 ? (
          <p className="text-xs text-warning-400 mt-3">موارد ناقص: {dataQuality.missing.join(' · ')}</p>
        ) : (
          <p className="text-xs text-success-400 mt-3">اطلاعات ضروری این معامله کامل است.</p>
        )}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-4">
          <InfoRow label="Process Score" value={trade.process_score === null || trade.process_score === undefined ? 'محاسبه نشده' : `${Number(trade.process_score).toFixed(0)}/100`} ltr />
          <InfoRow label="Review" value={trade.review_completed === true ? 'تکمیل' : 'ناقص'} />
          <InfoRow label="نتیجه" value={getResultLabel(trade.result)} />
        </div>
      </div>

      {/* Execution Replay */}
      <TradeReplay trade={trade} />

      {/* Screenshots */}
      <TradeScreenshots tradeId={trade.id} />

      {/* AI Post-Trade Review (closed trades only) */}
      {trade.result !== 'open' && <PostTradeCoach trade={trade} />}

      {/* Notes, Reasons, Mistakes, Lessons */}
      {(trade.entry_reason || trade.exit_reason || trade.mistakes || trade.lessons || trade.notes) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {trade.entry_reason && <NoteBlock title="دلیل ورود" content={trade.entry_reason} />}
          {trade.exit_reason && <NoteBlock title="دلیل خروج" content={trade.exit_reason} />}
          {trade.mistakes && <NoteBlock title="اشتباهات" content={trade.mistakes} color="danger" />}
          {trade.lessons && <NoteBlock title="درس‌ها" content={trade.lessons} color="success" />}
          {trade.notes && <NoteBlock title="یادداشت‌ها" content={trade.notes} />}
        </div>
      )}
    </div>
  );
}

function InfoRow({ label, value, ltr }: { label: string; value: string; ltr?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-white/5 last:border-0">
      <span className="text-xs text-dark-400">{label}</span>
      <span className={`text-sm text-white font-medium ${ltr ? 'number-ltr' : ''}`}>{value}</span>
    </div>
  );
}

function NoteBlock({ title, content, color }: { title: string; content: string; color?: 'danger' | 'success' }) {
  const borderColor = color === 'danger' ? 'border-r-danger-500' : color === 'success' ? 'border-r-success-500' : 'border-r-gold-500';
  return (
    <div className={`glass-card p-4 border-r-2 ${borderColor}`}>
      <h3 className="text-xs font-semibold text-dark-400 mb-2">{title}</h3>
      <p className="text-sm text-white leading-relaxed">{content}</p>
    </div>
  );
}