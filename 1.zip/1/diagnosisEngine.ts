import { sampleConfidence } from '@/lib/tradingEngine';

export type DiagnosisTrade = {
  trade_date: string;
  pnl_amount?: number | null;
  r_multiple?: number | null;
  process_score?: number | null;
  psychology_tags?: string[] | null;
  mistakes?: string | null;
  session?: string | null;
  strategy_id?: string | null;
  setup_id?: string | null;
  risk_percent?: number | null;
};

export type ProblemKey = 'revenge'|'fomo'|'overtrading'|'premature_exit'|'move_sl'|'risk_violation'|'rule_violation'|'fear'|'greed'|'hesitation'|'process_drop';
export type ProblemStat = { key: ProblemKey; label: string; trades: number; r: number; pnl: number; avgR: number; confidence: 'low'|'medium'|'high'; recentCount: number; previousCount: number; trend: 'improving'|'worsening'|'stable'; severity: 'critical'|'high'|'medium'|'low'; lastDate: string | null };
export type Diagnosis = { strategy: number|null; execution: number|null; psychology: number|null; primary: ProblemStat|null; problems: ProblemStat[]; explanation: string };

const definitions: Record<ProblemKey,{label:string; keywords:string[]}> = {
  revenge:{label:'انتقام از بازار',keywords:['revenge','انتقام']},
  fomo:{label:'FOMO / تعقیب بازار',keywords:['fomo','تعقیب','جا ماندن']},
  overtrading:{label:'اورترید',keywords:['overtrading','اورترید','زیاده‌روی']},
  premature_exit:{label:'خروج زودهنگام',keywords:['premature','زودهنگام','زود خارج']},
  move_sl:{label:'جابجایی استاپ',keywords:['move sl','جابجایی استاپ','استاپ را جابجا']},
  risk_violation:{label:'نقض ریسک',keywords:['risk violation','نقض ریسک','ریسک بیش از']},
  rule_violation:{label:'نقض قانون',keywords:['rule violation','نقض قانون','خلاف قانون']},
  fear:{label:'ترس',keywords:['fear','ترس']},
  greed:{label:'طمع',keywords:['greed','طمع']},
  hesitation:{label:'تردید',keywords:['hesitation','تردید']},
  process_drop:{label:'افت کیفیت فرآیند',keywords:[]},
};

const norm=(s:string)=>s.toLowerCase().trim();
function matches(t:DiagnosisTrade, def:{keywords:string[]}): boolean {
  const tags=(t.psychology_tags||[]).map(norm);
  const mistakes=norm(t.mistakes||'');
  return def.keywords.some(k=>tags.includes(norm(k)) || mistakes.includes(norm(k)));
}
function avg(values:number[]){ return values.length ? values.reduce((a,b)=>a+b,0)/values.length : 0; }
function periodKey(t:DiagnosisTrade){ return t.trade_date || ''; }

export function diagnoseTrading(trades:DiagnosisTrade[], actions:{title:string;status:string;result?:string|null}[]=[]): Diagnosis {
  const closed=trades.filter(t=>t.pnl_amount!=null || t.r_multiple!=null);
  const sorted=[...closed].sort((a,b)=>periodKey(a).localeCompare(periodKey(b)));
  const split=Math.max(1, Math.floor(sorted.length*0.5));
  const previous=sorted.slice(0,split);
  const recent=sorted.slice(split);
  const scores=closed.map(t=>Number(t.process_score)).filter(Number.isFinite);
  const risk=closed.map(t=>Number(t.risk_percent)).filter(Number.isFinite);
  const executionScores=closed.map(t=>Number(t.process_score)).filter(Number.isFinite);
  const strategyScores=closed.filter(t=>t.strategy_id).map(t=>Number(t.process_score)).filter(Number.isFinite);
  const psychTagged=closed.filter(t=>(t.psychology_tags||[]).length>0 || Boolean(t.mistakes));
  const strategy= strategyScores.length ? Math.round(avg(strategyScores)) : null;
  const execution= executionScores.length ? Math.round(avg(executionScores)) : null;
  const psychology= psychTagged.length ? Math.max(0,Math.min(100,Math.round(100 - psychTagged.length/Math.max(1,closed.length)*100))) : null;
  const problems:ProblemStat[]=[];
  (Object.keys(definitions) as ProblemKey[]).forEach(key=>{
    const def=definitions[key];
    const matched=key==='process_drop' ? closed.filter(t=>Number.isFinite(Number(t.process_score)) && Number(t.process_score)<70) : closed.filter(t=>matches(t,def));
    if(!matched.length) return;
    const recentMatched=(recent.length?recent:sorted).filter(t=>key==='process_drop' ? Number(t.process_score)<70 : matches(t,def));
    const prevMatched=previous.filter(t=>key==='process_drop' ? Number(t.process_score)<70 : matches(t,def));
    const r=matched.reduce((s,t)=>s+(Number(t.r_multiple)||0),0);
    const rRecent=recentMatched.reduce((s,t)=>s+(Number(t.r_multiple)||0),0);
    const rPrev=prevMatched.reduce((s,t)=>s+(Number(t.r_multiple)||0),0);
    const ratioRecent=recent.length?recentMatched.length/recent.length:0;
    const ratioPrev=previous.length?prevMatched.length/previous.length:0;
    const diff=ratioRecent-ratioPrev;
    const trend=diff>0.05?'worsening':diff<-0.05?'improving':'stable';
    const severity=(recentMatched.length>=4 && rRecent<-3)?'critical':(matched.length>=3 && r<0)?'high':matched.length>=3?'medium':'low';
    problems.push({key,label:def.label,trades:matched.length,r,pnl:matched.reduce((s,t)=>s+(Number(t.pnl_amount)||0),0),avgR:r/matched.length,confidence:sampleConfidence(matched.length),recentCount:recentMatched.length,previousCount:prevMatched.length,trend,severity,lastDate:(matched.map(t=>t.trade_date).sort().slice(-1)[0]||null)});
  });
  problems.sort((a,b)=>({critical:4,high:3,medium:2,low:1}[b.severity]-({critical:4,high:3,medium:2,low:1}[a.severity]) || a.r-b.r));
  const primary=problems[0]||null;
  let explanation='داده کافی برای تشخیص مسئله اصلی وجود ندارد.';
  if(primary){
    const action=actions.find(a=>a.title.toLowerCase().includes(primary.key) || a.title.includes(primary.label));
    explanation=`مهم‌ترین مسئله فعلی «${primary.label}» است: ${primary.trades} معامله مرتبط، ${primary.avgR.toFixed(2)}R میانگین و روند ${primary.trend==='worsening'?'رو به بدتر شدن':primary.trend==='improving'?'رو به بهبود':'نسبتاً ثابت'} دارد.` + (action?.status==='ACTIVE'?' یک اقدام مرتبط هنوز فعال است.':action?.result==='NOT_IMPROVED'?' اقدام قبلی نتیجه مطلوب نداده و باید بازطراحی شود.':'');
  }
  return {strategy,execution,psychology,primary,problems:problems.slice(0,10),explanation};
}

export function recurringProblems(trades:DiagnosisTrade[], minOccurrences=3){
  const diagnosis=diagnoseTrading(trades);
  return diagnosis.problems.filter(p=>p.trades>=minOccurrences && (p.previousCount>0 || p.recentCount>=minOccurrences));
}
