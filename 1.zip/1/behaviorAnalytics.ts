export type TradeLike = {
  trade_date: string;
  result: string | null;
  pnl_amount?: number | null;
  r_multiple?: number | null;
  psychology_tags?: string[] | null;
  feeling_before?: string | null;
  feeling_during?: string | null;
  feeling_after?: string | null;
  session?: string | null;
  symbol?: string | null;
  direction?: string | null;
  entry_reason?: string | null;
  exit_reason?: string | null;
  mistakes?: string | null;
  lessons?: string | null;
  risk_percent?: number | null;
  rr_ratio?: number | null;
  process_score?: number | null;
};

export type SegmentMetric = {
  key: string;
  label: string;
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  pnl: number;
  avgR: number;
  avgProcess: number | null;
};

const n = (v: unknown) => Number(v) || 0;
const labelMap: Record<string,string> = {
  calm:'😌 آرام', confident:'💪 مطمئن', neutral:'😐 خنثی', anxious:'😟 نگران', fearful:'😨 ترس', greedy:'🤑 طمع', excited:'🤩 هیجان‌زده', angry:'😡 عصبانی', satisfied:'😊 راضی', frustrated:'😤 ناامید'
};
export const psychologyLabel = (key:string) => labelMap[key] || key || 'ثبت نشده';

function metric(key:string,label:string,rows:TradeLike[]): SegmentMetric {
  const wins = rows.filter(t=>t.result==='win').length;
  const pnl = rows.reduce((s,t)=>s+n(t.pnl_amount),0);
  const rs = rows.filter(t=>t.r_multiple !== null && t.r_multiple !== undefined);
  const ps = rows.filter(t=>t.process_score !== null && t.process_score !== undefined);
  return {key,label,trades:rows.length,wins,losses:rows.filter(t=>t.result==='loss').length,winRate:rows.length?wins/rows.length*100:0,pnl,avgR:rs.length?rs.reduce((s,t)=>s+n(t.r_multiple),0)/rs.length:0,avgProcess:ps.length?ps.reduce((s,t)=>s+n(t.process_score),0)/ps.length:null};
}

export function groupByField(trades:TradeLike[], field:keyof TradeLike, labelFn=(v:string)=>v||'ثبت نشده'):SegmentMetric[] {
  const map:Record<string,TradeLike[]>={};
  trades.forEach(t=>{
    const raw=t[field];
    const vals=Array.isArray(raw)?raw:[raw];
    const usable=vals.filter(Boolean).map(String);
    (usable.length?usable:['unknown']).forEach(v=>(map[v]??=[]).push(t));
  });
  return Object.entries(map).map(([k,rows])=>metric(k,labelFn(k),rows)).sort((a,b)=>b.pnl-a.pnl);
}

export function psychologyBreakdown(trades:TradeLike[]) {
  return groupByField(trades,'psychology_tags',psychologyLabel);
}

export function findPatterns(trades:TradeLike[]) {
  const candidates: {label:string; score:number; detail:string; type:'positive'|'warning'}[]=[];
  const fields:[keyof TradeLike,string,(v:string)=>string][]=[
    ['session','سشن',v=>v==='london'?'لندن':v==='new_york'?'نیویورک':v==='asian'?'آسیا':v],
    ['symbol','نماد',v=>v],
    ['direction','جهت',v=>v==='buy'?'خرید':v==='sell'?'فروش':v],
    ['entry_reason','دلیل ورود',v=>v],
  ];
  for(const [field,title,fn] of fields){
    for(const s of groupByField(trades,field,fn)){
      if(s.trades<3) continue;
      const score=s.avgR*100 + (s.winRate-50)*0.6;
      candidates.push({label:`${title}: ${s.label}`,score,detail:`${s.trades} معامله · وین‌ریت ${s.winRate.toFixed(0)}٪ · میانگین ${s.avgR.toFixed(2)}R · ${s.pnl>=0?'+':''}$${s.pnl.toFixed(0)}`,type:s.avgR>=0?'positive':'warning'});
    }
  }
  const psych=psychologyBreakdown(trades).filter(x=>x.trades>=3);
  psych.forEach(s=>candidates.push({label:`روانشناسی: ${s.label}`,score:s.avgR*100,detail:`${s.trades} معامله · ${s.avgR.toFixed(2)}R میانگین · ${s.pnl>=0?'+':''}$${s.pnl.toFixed(0)}`,type:s.avgR>=0?'positive':'warning'}));
  return candidates.sort((a,b)=>b.score-a.score).slice(0,12);
}

export function processDiscipline(trades:TradeLike[]) {
  const reviewed=trades.filter(t=>(t as any).review_completed === true);
  const scores=trades.filter(t=>t.process_score!==null && t.process_score!==undefined).map(t=>n(t.process_score));
  const riskBreaches=trades.filter(t=>n(t.risk_percent)>1).length;
  const mistakes=trades.filter(t=>t.mistakes).length;
  return {reviewRate:trades.length?reviewed.length/trades.length*100:0,avgProcess:scores.length?scores.reduce((a,b)=>a+b,0)/scores.length:null,riskBreaches,mistakes};
}
