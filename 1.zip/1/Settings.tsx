import { useState, useEffect, useCallback } from 'react';
import {
  Settings as SettingsIcon, User, Wallet, Tag as TagIcon, ShieldCheck,
  Plus, Pencil, Trash2, LogOut, Save, Check, Eye, EyeOff, Bell, BellOff
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency } from '@/lib/utils';
import { getNotificationPermission, requestNotificationPermission, isNotificationSupported } from '@/lib/notify';
import { explainSupabaseError } from '@/lib/supabaseErrors';

type Account = {
  id: string; name: string; broker: string | null; account_type: string;
  currency: string; initial_balance: number; current_balance: number; is_active: boolean;
  prop_max_drawdown_percent: number | null; prop_profit_target_percent: number | null;
};

type TagRow = { id: string; name: string; color: string };

const ACCOUNT_TYPES: Record<string, string> = { live: 'واقعی', demo: 'دمو', prop: 'پراپ' };
const TAG_COLORS = ['#f59e0b', '#22c55e', '#ef4444', '#3b82f6', '#a855f7', '#ec4899', '#14b8a6', '#6c757d'];

const emptyAccountForm = { name: '', broker: '', account_type: 'live', currency: 'USD', initial_balance: '0', is_active: true, prop_max_drawdown_percent: '', prop_profit_target_percent: '' };

export default function Settings() {
  const { user, profile, refreshProfile, signOut } = useAuth();
  const [section, setSection] = useState<'profile' | 'accounts' | 'tags' | 'security'>('profile');

  // Profile
  const [profileForm, setProfileForm] = useState({ display_name: '', currency: 'USD', initial_capital: '0' });
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileSaved, setProfileSaved] = useState(false);

  useEffect(() => {
    if (profile) {
      setProfileForm({
        display_name: profile.display_name || '',
        currency: profile.currency || 'USD',
        initial_capital: String(profile.initial_capital ?? 0),
      });
    }
  }, [profile]);

  const handleSaveProfile = async () => {
    if (!user) return;
    setSavingProfile(true);
    setSettingsError(null);

    const initialCapital = Math.max(0, Number(profileForm.initial_capital) || 0);
    await supabase.rpc('ensure_my_trading_os_data');
    const payload = {
      id: user.id,
      display_name: profileForm.display_name.trim() || null,
      currency: profileForm.currency || 'USD',
      initial_capital: initialCapital,
    };

    // Upsert makes Settings resilient for older users whose profile row was
    // not created by the signup trigger. It does not require any service key.
    const { error } = await supabase.from('profiles').upsert(payload, { onConflict: 'id' });
    if (error) {
      setSettingsError(`ذخیره پروفایل ناموفق بود: ${explainSupabaseError(error)}`);
      setSavingProfile(false);
      return;
    }

    await refreshProfile();
    setSavingProfile(false);
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2000);
  };

  // Accounts
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loadingAccounts, setLoadingAccounts] = useState(true);
  const [showAccountForm, setShowAccountForm] = useState(false);
  const [editingAccountId, setEditingAccountId] = useState<string | null>(null);
  const [accountForm, setAccountForm] = useState(emptyAccountForm);
  const [deleteAccountId, setDeleteAccountId] = useState<string | null>(null);
  const [resetAccountId, setResetAccountId] = useState<string | null>(null);
  const [resetCapital, setResetCapital] = useState('0');
  const [resettingAccount, setResettingAccount] = useState(false);
  const [resetFreshConfirm, setResetFreshConfirm] = useState<string | null>(null);
  const [settingsError, setSettingsError] = useState<string | null>(null);

  const loadAccounts = useCallback(async () => {
    if (!user) return;
    setLoadingAccounts(true);
    await supabase.rpc('ensure_my_trading_os_data');
    const { data, error } = await supabase.from('accounts').select('*').eq('user_id', user.id).order('created_at');
    if (error) {
      setSettingsError(`بارگذاری حساب‌ها ناموفق بود: ${explainSupabaseError(error)}`);
      setAccounts([]);
    } else {
      setAccounts(data || []);
    }
    setLoadingAccounts(false);
  }, [user]);

  useEffect(() => { loadAccounts(); }, [loadAccounts]);

  const openCreateAccount = () => {
    setSettingsError(null);
    setEditingAccountId(null);
    setAccountForm(emptyAccountForm);
    setShowAccountForm(true);
  };

  const openEditAccount = (a: Account) => {
    setSettingsError(null);
    setEditingAccountId(a.id);
    setAccountForm({
      name: a.name, broker: a.broker || '', account_type: a.account_type,
      currency: a.currency, initial_balance: String(a.initial_balance), is_active: a.is_active,
      prop_max_drawdown_percent: a.prop_max_drawdown_percent != null ? String(a.prop_max_drawdown_percent) : '',
      prop_profit_target_percent: a.prop_profit_target_percent != null ? String(a.prop_profit_target_percent) : '',
    });
    setShowAccountForm(true);
  };

  const handleSaveAccount = async () => {
    if (!user || !accountForm.name.trim()) return;
    setSettingsError(null);
    if (editingAccountId) {
      const { error } = await supabase.from('accounts').update({
        name: accountForm.name.trim(),
        broker: accountForm.broker.trim() || null,
        account_type: accountForm.account_type,
        currency: accountForm.currency,
        is_active: accountForm.is_active,
        prop_max_drawdown_percent: accountForm.account_type === 'prop' && accountForm.prop_max_drawdown_percent ? Number(accountForm.prop_max_drawdown_percent) : null,
        prop_profit_target_percent: accountForm.account_type === 'prop' && accountForm.prop_profit_target_percent ? Number(accountForm.prop_profit_target_percent) : null,
      }).eq('id', editingAccountId).eq('user_id', user.id);
      if (error) { setSettingsError(`ویرایش حساب ناموفق بود: ${explainSupabaseError(error)}`); return; }
    } else {
      const initBalance = Number(accountForm.initial_balance) || 0;
      const { error } = await supabase.from('accounts').insert({
        user_id: user.id,
        name: accountForm.name.trim(),
        broker: accountForm.broker.trim() || null,
        account_type: accountForm.account_type,
        currency: accountForm.currency,
        initial_balance: initBalance,
        current_balance: initBalance,
        is_active: accountForm.is_active,
        prop_max_drawdown_percent: accountForm.account_type === 'prop' && accountForm.prop_max_drawdown_percent ? Number(accountForm.prop_max_drawdown_percent) : null,
        prop_profit_target_percent: accountForm.account_type === 'prop' && accountForm.prop_profit_target_percent ? Number(accountForm.prop_profit_target_percent) : null,
      });
      if (error) { setSettingsError(`ایجاد حساب ناموفق بود: ${explainSupabaseError(error)}`); return; }
    }
    setShowAccountForm(false);
    loadAccounts();
  };

  const openResetAccount = (a: Account) => { setResetAccountId(a.id); setResetCapital(String(a.initial_balance ?? 0)); };
  const handleResetAccount = async () => {
    setSettingsError(null);
    if (!user || !resetAccountId) return;
    setResettingAccount(true);
    const amount = Math.max(0, Number(resetCapital) || 0);
    const { error: accountError } = await supabase.rpc('reset_account_balance', {
      p_account_id: resetAccountId,
      p_new_initial: amount,
    });
    if (accountError) {
      setSettingsError(`تنظیم سرمایه حساب ناموفق بود: ${explainSupabaseError(accountError)}`);
    } else {
      const { error: profileError } = await supabase
        .from('profiles')
        .upsert({ id: user.id, initial_capital: amount, current_capital: amount }, { onConflict: 'id' });
      if (profileError) setSettingsError(`به‌روزرسانی پروفایل ناموفق بود: ${explainSupabaseError(profileError)}`);
      await refreshProfile();
      await loadAccounts();
    }
    setResettingAccount(false);
    setResetAccountId(null);
  };

  const handleFreshReset = async (accountId: string) => {
    if (!user) return;
    setResettingAccount(true); setSettingsError(null);
    const { error } = await supabase.rpc('reset_account_fresh', { p_account_id: accountId });
    if (error) setSettingsError(`شروع حساب از صفر ناموفق بود: ${explainSupabaseError(error)}`);
    await refreshProfile(); await loadAccounts();
    setResettingAccount(false); setResetFreshConfirm(null);
  };

  const handleDeleteAccount = async (id: string) => {
    if (!user) return;
    const { error } = await supabase.from('accounts').delete().eq('id', id).eq('user_id', user.id);
    if (error) {
      setSettingsError(`حذف حساب ناموفق بود: ${explainSupabaseError(error)}`);
      return;
    }
    setDeleteAccountId(null);
    loadAccounts();
  };

  // Tags
  const [tags, setTags] = useState<TagRow[]>([]);
  const [loadingTags, setLoadingTags] = useState(true);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState(TAG_COLORS[0]);
  const [deleteTagId, setDeleteTagId] = useState<string | null>(null);

  const loadTags = useCallback(async () => {
    if (!user) return;
    setLoadingTags(true);
    const { data } = await supabase.from('tags').select('*').eq('user_id', user.id).order('created_at');
    setTags(data || []);
    setLoadingTags(false);
  }, [user]);

  useEffect(() => { loadTags(); }, [loadTags]);

  const handleAddTag = async () => {
    if (!user || !newTagName.trim()) return;
    setSettingsError(null);
    const { error } = await supabase.from('tags').insert({ user_id: user.id, name: newTagName.trim(), color: newTagColor });
    if (error) {
      setSettingsError(`افزودن تگ ناموفق بود: ${explainSupabaseError(error)}`);
      return;
    }
    setNewTagName('');
    await loadTags();
  };

  const handleDeleteTag = async (id: string) => {
    if (!user) return;
    setSettingsError(null);
    const { error } = await supabase.from('tags').delete().eq('id', id).eq('user_id', user.id);
    if (error) {
      setSettingsError(`حذف تگ ناموفق بود: ${explainSupabaseError(error)}`);
      return;
    }
    setDeleteTagId(null);
    await loadTags();
  };

  // Security
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false);

  const handleChangePassword = async () => {
    setPasswordError(null);
    if (newPassword.length < 6) {
      setPasswordError('رمز عبور باید حداقل ۶ کاراکتر باشد.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('رمز عبور و تکرار آن یکسان نیستند.');
      return;
    }
    setChangingPassword(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setChangingPassword(false);
    if (error) {
      setPasswordError(error.message);
      return;
    }
    setNewPassword('');
    setConfirmPassword('');
    setPasswordSuccess(true);
    setTimeout(() => setPasswordSuccess(false), 3000);
  };

  const navItems = [
    { key: 'profile', label: 'پروفایل', icon: User },
    { key: 'accounts', label: 'حساب‌ها', icon: Wallet },
    { key: 'tags', label: 'تگ‌ها', icon: TagIcon },
    { key: 'security', label: 'امنیت', icon: ShieldCheck },
  ] as const;

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div className="flex items-center gap-2">
          <SettingsIcon className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-bold text-white">تنظیمات</h1>
        </div>
      </div>

      <div className="flex gap-1 border-b border-white/5 overflow-x-auto">
        {navItems.map(item => (
          <button
            key={item.key}
            onClick={() => setSection(item.key)}
            className={`flex items-center gap-1.5 px-3 py-2 text-sm border-b-2 whitespace-nowrap transition-colors ${
              section === item.key ? 'border-gold-500 text-gold-400' : 'border-transparent text-dark-400 hover:text-white'
            }`}
          >
            <item.icon className="w-4 h-4" /> {item.label}
          </button>
        ))}
      </div>

      {/* Profile */}
      {section === 'profile' && (
        <div className="glass-card p-4 md:p-6 space-y-4 max-w-lg">
          <div>
            <label className="label-text">نام نمایشی</label>
            <input type="text" value={profileForm.display_name} onChange={e => setProfileForm(f => ({ ...f, display_name: e.target.value }))} className="input-field" />
          </div>
          <div>
            <label className="label-text">ایمیل</label>
            <input type="text" value={user?.email || ''} disabled className="input-field opacity-60 cursor-not-allowed" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label-text">واحد پول</label>
              <select value={profileForm.currency} onChange={e => setProfileForm(f => ({ ...f, currency: e.target.value }))} className="select-field">
                <option value="USD">دلار (USD)</option>
                <option value="EUR">یورو (EUR)</option>
                <option value="IRR">ریال (IRR)</option>
              </select>
            </div>
            <div>
              <label className="label-text">سرمایه‌ی اولیه</label>
              <input type="number" step="0.01" value={profileForm.initial_capital} onChange={e => setProfileForm(f => ({ ...f, initial_capital: e.target.value }))} className="input-field number-ltr" />
            </div>
          </div>
          <div className="flex items-center gap-3 pt-2 border-t border-white/5">
            <button onClick={handleSaveProfile} disabled={savingProfile} className="btn-primary flex items-center gap-1.5 text-sm">
              <Save className="w-4 h-4" /> {savingProfile ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
            </button>
            {profileSaved && <span className="text-xs text-success-400 flex items-center gap-1"><Check className="w-3.5 h-3.5" /> ذخیره شد</span>}
            {settingsError && !showAccountForm && <span className="text-xs text-danger-400">{settingsError}</span>}
          </div>
        </div>
      )}

      {/* Accounts */}
      {section === 'accounts' && (
        <div className="space-y-3">
          <div className="flex justify-end">
            <button onClick={openCreateAccount} className="btn-primary flex items-center gap-1.5 text-sm">
              <Plus className="w-4 h-4" /> حساب جدید
            </button>
          </div>

          {loadingAccounts ? (
            <div className="flex justify-center py-10"><div className="w-6 h-6 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" /></div>
          ) : accounts.length === 0 ? (
            <div className="glass-card p-10 text-center">
              <Wallet className="w-10 h-10 text-dark-500 mx-auto mb-3" />
              <p className="text-dark-400 text-sm mb-4">هنوز حساب معاملاتی‌ای ثبت نکرده‌اید.</p>
              <button onClick={openCreateAccount} className="btn-primary mx-auto text-sm">افزودن اولین حساب</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {accounts.map(a => (
                <div key={a.id} className="glass-card p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-semibold text-white">{a.name}</h3>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-dark-700 text-dark-400">{ACCOUNT_TYPES[a.account_type] || a.account_type}</span>
                        {!a.is_active && <span className="text-[10px] px-1.5 py-0.5 rounded bg-dark-700 text-dark-500">غیرفعال</span>}
                      </div>
                      {a.broker && <p className="text-xs text-dark-500 mt-0.5">{a.broker}</p>}
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => openEditAccount(a)} className="p-1.5 rounded-lg text-dark-400 hover:text-gold-400 hover:bg-white/5">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => openResetAccount(a)} className="p-1.5 rounded-lg text-dark-400 hover:text-gold-400 hover:bg-white/5" title="تنظیم سرمایه"><Wallet className="w-3.5 h-3.5"/></button> <button onClick={() => setResetFreshConfirm(a.id)} className="btn-danger text-xs">شروع حساب از صفر</button><button onClick={() => setDeleteAccountId(a.id)} className="p-1.5 rounded-lg text-dark-400 hover:text-danger-400 hover:bg-white/5">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-3">
                    <div className="rounded-lg bg-dark-900/60 p-2 text-center">
                      <p className="text-[10px] text-dark-400">موجودی اولیه</p>
                      <p className="text-xs font-semibold text-white number-ltr">{formatCurrency(a.initial_balance)}</p>
                    </div>
                    <div className="rounded-lg bg-dark-900/60 p-2 text-center">
                      <p className="text-[10px] text-dark-400">موجودی فعلی</p>
                      <p className={`text-xs font-semibold number-ltr ${a.current_balance >= a.initial_balance ? 'profit-text' : 'loss-text'}`}>{formatCurrency(a.current_balance)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

          {resetAccountId && <div className="fixed inset-0 z-[90] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"><div className="glass-card w-full max-w-md p-5" dir="rtl"><h3 className="text-lg font-semibold text-white">تنظیم سرمایه حساب</h3><p className="text-sm text-dark-400 mt-1">معاملات حذف نمی‌شوند؛ فقط سرمایه اولیه و موجودی دوباره تنظیم می‌شوند.</p><label className="label-text mt-4">سرمایه اولیه جدید</label><input type="number" min="0" step="0.01" value={resetCapital} onChange={e=>setResetCapital(e.target.value)} className="input-field number-ltr" placeholder="مثلاً 5000"/><div className="flex gap-2 justify-end mt-4"><button type="button" onClick={()=>setResetAccountId(null)} className="btn-secondary">انصراف</button><button type="button" disabled={resettingAccount} onClick={handleResetAccount} className="btn-primary">{resettingAccount?'در حال ذخیره...':'تأیید و تنظیم سرمایه'}</button></div></div></div>}

      {/* Tags */}
      {section === 'tags' && (
        <div className="space-y-4">
          <div className="glass-card p-4 flex items-end gap-3 flex-wrap">
            <div className="flex-1 min-w-[160px]">
              <label className="label-text">نام تگ جدید</label>
              <input type="text" value={newTagName} onChange={e => setNewTagName(e.target.value)} className="input-field" placeholder="مثلاً: نیوز، اسکالپ" onKeyDown={e => e.key === 'Enter' && handleAddTag()} />
            </div>
            <div>
              <label className="label-text">رنگ</label>
              <div className="flex gap-1.5">
                {TAG_COLORS.map(c => (
                  <button
                    key={c}
                    onClick={() => setNewTagColor(c)}
                    className={`w-7 h-7 rounded-full border-2 transition-transform ${newTagColor === c ? 'border-white scale-110' : 'border-transparent'}`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
            <button onClick={handleAddTag} disabled={!newTagName.trim()} className="btn-primary flex items-center gap-1.5 text-sm">
              <Plus className="w-4 h-4" /> افزودن
            </button>
          </div>

          {loadingTags ? (
            <div className="flex justify-center py-10"><div className="w-6 h-6 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" /></div>
          ) : tags.length === 0 ? (
            <p className="text-sm text-dark-500 text-center py-6">هنوز تگی ثبت نشده است.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {tags.map(t => (
                <div key={t.id} className="flex items-center gap-2 pr-1 pl-3 py-1.5 rounded-full border border-white/10 bg-dark-900/60">
                  <button onClick={() => setDeleteTagId(t.id)} className="p-1 rounded-full text-dark-400 hover:text-danger-400 hover:bg-white/10">
                    <Trash2 className="w-3 h-3" />
                  </button>
                  <span className="text-xs text-white">{t.name}</span>
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: t.color }} />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Security */}
      {section === 'security' && (
        <div className="space-y-4 max-w-lg">
          <NotificationCard />
          <div className="glass-card p-4 md:p-6 space-y-4">
            <h2 className="text-sm font-semibold text-white">تغییر رمز عبور</h2>
            <div>
              <label className="label-text">رمز عبور جدید</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  className="input-field pl-10"
                  placeholder="حداقل ۶ کاراکتر"
                />
                <button type="button" onClick={() => setShowPassword(s => !s)} className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-400 hover:text-white">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className="label-text">تکرار رمز عبور</label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                className="input-field"
              />
            </div>
            {passwordError && <p className="text-xs text-danger-400">{passwordError}</p>}
            <div className="flex items-center gap-3 pt-1">
              <button onClick={handleChangePassword} disabled={changingPassword || !newPassword} className="btn-primary text-sm">
                {changingPassword ? 'در حال تغییر...' : 'تغییر رمز عبور'}
              </button>
              {passwordSuccess && <span className="text-xs text-success-400 flex items-center gap-1"><Check className="w-3.5 h-3.5" /> رمز عبور تغییر کرد</span>}
            </div>
          </div>

          <div className="glass-card p-4 md:p-6">
            <h2 className="text-sm font-semibold text-white mb-1">خروج از حساب</h2>
            <p className="text-xs text-dark-500 mb-3">با خروج از حساب، باید دوباره وارد شوید.</p>
            <button onClick={() => setShowSignOutConfirm(true)} className="btn-danger flex items-center gap-1.5 text-sm">
              <LogOut className="w-4 h-4" /> خروج از حساب
            </button>
          </div>
        </div>
      )}

      {/* Account form modal */}
      {showAccountForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-semibold text-white">{editingAccountId ? 'ویرایش حساب' : 'حساب جدید'}</h3>
            {settingsError && (
              <div className="bg-danger-500/10 border border-danger-500/30 rounded-lg px-3 py-2 text-danger-400 text-sm">{settingsError}</div>
            )}
            <div>
              <label className="label-text">نام حساب</label>
              <input type="text" value={accountForm.name} onChange={e => setAccountForm(f => ({ ...f, name: e.target.value }))} className="input-field" placeholder="مثلاً: حساب اصلی" autoFocus />
            </div>
            <div>
              <label className="label-text">بروکر</label>
              <input type="text" value={accountForm.broker} onChange={e => setAccountForm(f => ({ ...f, broker: e.target.value }))} className="input-field" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label-text">نوع حساب</label>
                <select value={accountForm.account_type} onChange={e => setAccountForm(f => ({ ...f, account_type: e.target.value }))} className="select-field">
                  {Object.entries(ACCOUNT_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="label-text">واحد پول</label>
                <select value={accountForm.currency} onChange={e => setAccountForm(f => ({ ...f, currency: e.target.value }))} className="select-field">
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                  <option value="IRR">IRR</option>
                </select>
              </div>
            </div>
            {!editingAccountId && (
              <div>
                <label className="label-text">موجودی اولیه</label>
                <input type="number" step="0.01" value={accountForm.initial_balance} onChange={e => setAccountForm(f => ({ ...f, initial_balance: e.target.value }))} className="input-field number-ltr" />
              </div>
            )}
            {accountForm.account_type === 'prop' && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label-text">حداکثر افت سرمایه مجاز (٪)</label>
                  <input type="number" step="0.1" value={accountForm.prop_max_drawdown_percent} onChange={e => setAccountForm(f => ({ ...f, prop_max_drawdown_percent: e.target.value }))} className="input-field number-ltr" placeholder="مثلاً 10" />
                </div>
                <div>
                  <label className="label-text">هدف سود ارزیابی (٪)</label>
                  <input type="number" step="0.1" value={accountForm.prop_profit_target_percent} onChange={e => setAccountForm(f => ({ ...f, prop_profit_target_percent: e.target.value }))} className="input-field number-ltr" placeholder="مثلاً 8" />
                </div>
              </div>
            )}
            <label className="flex items-center gap-2 cursor-pointer w-fit">
              <input type="checkbox" checked={accountForm.is_active} onChange={e => setAccountForm(f => ({ ...f, is_active: e.target.checked }))} className="w-4 h-4 accent-gold-500" />
              <span className="text-sm text-dark-300">حساب فعال است</span>
            </label>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowAccountForm(false)} className="btn-secondary">انصراف</button>
              <button onClick={handleSaveAccount} disabled={!accountForm.name.trim()} className="btn-primary">ذخیره</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete account confirm */}
      {deleteAccountId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف حساب</h3>
            <p className="text-sm text-dark-400 mb-4">با حذف این حساب، معاملات مرتبط با آن نیز ممکن است تحت تأثیر قرار بگیرند. ادامه می‌دهید؟</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteAccountId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => handleDeleteAccount(deleteAccountId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete tag confirm */}
      {deleteTagId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف تگ</h3>
            <p className="text-sm text-dark-400 mb-4">آیا مطمئن هستید؟</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteTagId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => handleDeleteTag(deleteTagId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}

      {/* Sign out confirm */}
      {showSignOutConfirm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">خروج از حساب</h3>
            <p className="text-sm text-dark-400 mb-4">آیا مطمئن هستید که می‌خواهید خارج شوید؟</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setShowSignOutConfirm(false)} className="btn-secondary">انصراف</button>
              <button onClick={signOut} className="btn-danger">خروج</button>
            </div>
          </div>
        </div>
      )}
    {resetFreshConfirm && (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4">
        <div className="glass-card p-6 w-full max-w-md">
          <h3 className="text-lg font-bold text-white">شروع حساب از صفر</h3>
          <p className="text-sm text-dark-400 mt-2">این عملیات تمام معاملات متعلق به این حساب را حذف می‌کند و سرمایه اولیه و فعلی را صفر می‌کند. این کار قابل بازگشت نیست.</p>
          <div className="flex gap-2 justify-end mt-5"><button onClick={()=>setResetFreshConfirm(null)} className="btn-secondary">انصراف</button><button disabled={resettingAccount} onClick={()=>handleFreshReset(resetFreshConfirm)} className="btn-danger">شروع از صفر</button></div>
        </div>
      </div>
    )}
    </div>
  );
}

function NotificationCard() {
  const [permission, setPermission] = useState(getNotificationPermission());

  if (!isNotificationSupported()) return null;

  const handleEnable = async () => {
    const result = await requestNotificationPermission();
    setPermission(result);
  };

  return (
    <div className="glass-card p-4 md:p-6">
      <h2 className="text-sm font-semibold text-white mb-1 flex items-center gap-1.5">
        {permission === 'granted' ? <Bell className="w-4 h-4 text-gold-400" /> : <BellOff className="w-4 h-4 text-dark-400" />}
        هشدارهای Push مرورگر
      </h2>
      <p className="text-xs text-dark-500 mb-3">
        وقتی فعال باشه، هشدارهای مهم (مثل رسیدن به سقف ضرر روزانه یا باخت متوالی) حتی وقتی این تب باز نیست هم بهت اطلاع داده می‌شه.
      </p>
      {permission === 'granted' ? (
        <span className="text-xs text-success-400 flex items-center gap-1"><Check className="w-3.5 h-3.5" /> فعاله</span>
      ) : permission === 'denied' ? (
        <p className="text-xs text-danger-400">دسترسی رد شده — از تنظیمات مرورگر برای این سایت فعالش کن.</p>
      ) : (
        <button onClick={handleEnable} className="btn-secondary text-sm flex items-center gap-1.5">
          <Bell className="w-3.5 h-3.5" /> فعال‌سازی هشدارها
        </button>
      )}
    </div>

  );
}
