import { useEffect,useMemo,useState } from 'react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { psychologyBreakdown, findPatterns, processDiscipline } from '@/lib/behaviorAnalytics';
import { Brain, TrendingUp, TrendingDown, ShieldAlert, Target, Sparkles, Activity } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

function Card({title,icon:Icon,children}:{title:string;icon:any;children:any}){return <section className="glass-card p-4"><h2 className="section-title"><Icon className="w-4 h-4 text-gold-400"/>{title}</h2>{children}</section>}
function Bar({label,value,max=100,good=true}:{label:string;value:number;max?:number;good?:boolean}){return <div className="space-y-1"><div className="flex justify-between text-xs"><span className="text-dark-300">{label}</span><span className={good?'text-success-400':'text-danger-400'}>{value.toFixed(0)}%</span></div><div className="h-2 rounded-full bg-dark-800 overflow-hidden"><div className={good?'h-full bg-success-500':'h-full bg-danger-500'} style={{width:`${Math.min(100,Math.max(0,value/max*100))}%`}}/></div></div>}

export default function Psychology(){
 const {user}=useAuth(); const [trades,setTrades]=useState<any[]>([]); const [loading,setLoading]=useState(true);
 useEffect(()=>{if(!user)return; supabase.from('trades').select('*').eq('user_id',user.id).eq('account_id', getActiveAccountId()).not('result','eq','open').order('trade_date',{ascending:false}).then(({data})=>{setTrades(data||[]);setLoading(false)})},[user]);
 const psych=useMemo(()=>psychologyBreakdown(trades),[trades]); const patterns=useMemo(()=>findPatterns(trades),[trades]); const discipline=useMemo(()=>processDiscipline(trades),[trades]);
 const best=psych.filter(x=>x.trades>=3).sort((a,b)=>b.avgR-a.avgR)[0]; const worst=psych.filter(x=>x.trades>=3).sort((a,b)=>a.avgR-b.avgR)[0];
 if(loading)return <div className="page-container flex justify-center py-20"><div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin"/></div>;
 return <div className="page-container space-y-5" dir="rtl">
  <div><h1 className="page-title flex items-center gap-2"><Brain className="w-6 h-6 text-gold-400"/>اتاق تحلیل روانشناسی</h1><p className="text-dark-400 text-sm mt-1">تحلیل رفتار واقعی معاملات؛ بدون AI و فقط بر اساس داده‌های ثبت‌شده.</p></div>
  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
   <div className="glass-card p-4"><p className="text-xs text-dark-400">میانگین Process Score</p><p className="text-2xl font-bold text-white mt-1">{discipline.avgProcess==null?'—':discipline.avgProcess.toFixed(0)}<span className="text-xs text-dark-500">/100</span></p></div>
   <div className="glass-card p-4"><p className="text-xs text-dark-400">انضباط ژورنال</p><p className="text-2xl font-bold text-white mt-1">{discipline.reviewRate.toFixed(0)}٪</p></div>
   <div className="glass-card p-4"><p className="text-xs text-dark-400">بهترین حالت</p><p className="text-lg font-bold text-success-400 mt-1">{best?.label||'داده کافی نیست'}</p></div>
   <div className="glass-card p-4"><p className="text-xs text-dark-400">پرریسک‌ترین حالت</p><p className="text-lg font-bold text-danger-400 mt-1">{worst?.label||'داده کافی نیست'}</p></div>
  </div>
  <div className="grid lg:grid-cols-2 gap-4">
   <Card title="رابطه حالت ذهنی و نتیجه" icon={Activity}>{psych.length?<div className="space-y-4">{psych.map(x=><div key={x.key}><div className="flex items-center justify-between mb-1"><span className="text-sm text-white">{x.label}</span><span className={`text-sm font-semibold number-ltr ${x.avgR>=0?'text-success-400':'text-danger-400'}`}>{x.avgR>=0?'+':''}{x.avgR.toFixed(2)}R</span></div><Bar label={`${x.trades} معامله · ${x.winRate.toFixed(0)}٪ برد · ${formatCurrency(x.pnl)}`} value={x.winRate} good={x.avgR>=0}/></div>)}</div>:<p className="text-dark-500 text-sm">هنوز داده روانشناسی کافی ثبت نشده.</p>}</Card>
   <Card title="الگوهای قابل توجه" icon={Sparkles}>{patterns.length?<div className="space-y-2">{patterns.map((p,i)=><div key={i} className={`rounded-xl border p-3 ${p.type==='positive'?'border-success-500/20 bg-success-500/5':'border-danger-500/20 bg-danger-500/5'}`}><div className="flex gap-2"><span>{p.type==='positive'?'🟢':'🔴'}</span><div><p className="text-sm font-medium text-white">{p.label}</p><p className="text-xs text-dark-400 mt-0.5">{p.detail}</p></div></div></div>)}</div>:<p className="text-dark-500 text-sm">برای کشف الگو حداقل چند معامله مشابه لازم است.</p>}</Card>
  </div>
  <Card title="کنترل فرآیند" icon={ShieldAlert}><div className="grid md:grid-cols-3 gap-3"><div className="rounded-xl bg-dark-800/60 p-3"><p className="text-xs text-dark-400">مرور ثبت‌شده</p><p className="text-xl font-bold text-white mt-1">{discipline.reviewRate.toFixed(0)}٪</p></div><div className="rounded-xl bg-dark-800/60 p-3"><p className="text-xs text-dark-400">معاملات دارای خطای ثبت‌شده</p><p className="text-xl font-bold text-white mt-1">{discipline.mistakes}</p></div><div className="rounded-xl bg-dark-800/60 p-3"><p className="text-xs text-dark-400">ریسک بالاتر از ۱٪</p><p className={`text-xl font-bold mt-1 ${discipline.riskBreaches?'text-danger-400':'text-success-400'}`}>{discipline.riskBreaches}</p></div></div></Card>
  <div className="glass-card p-4 border-gold-500/10"><div className="flex gap-3"><Target className="w-5 h-5 text-gold-400 mt-0.5"/><div><p className="font-semibold text-white">قانون مربی‌گری بدون AI</p><p className="text-sm text-dark-400 mt-1">این صفحه تشخیص قطعی نمی‌دهد؛ فقط رابطه‌های آماری را نشان می‌دهد. هیچ الگوی کم‌نمونه‌ای به‌عنوان «Edge» معرفی نمی‌شود و قبل از تصمیم‌گیری باید تعداد معاملات و شرایط بازار را هم در نظر بگیری.</p></div></div></div>
 </div>
}