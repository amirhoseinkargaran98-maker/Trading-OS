import { useState, useEffect, useCallback } from 'react';
import { Clock3, Plus, Trash2, CalendarOff } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

type Window = { id: string; label: string; day_of_week: number | null; start_time: string; end_time: string; is_active: boolean };

const DAYS = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];

export default function NoTradeWindowsManager() {
  const { user } = useAuth();
  const [windows, setWindows] = useState<Window[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ label: '', day_of_week: '', start_time: '15:25', end_time: '15:45' });
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase.from('no_trade_windows').select('*').eq('user_id', user.id).order('created_at');
    setWindows(data || []);
    setLoading(false);
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const addWindow = async () => {
    if (!user || !form.label.trim()) return;
    await supabase.from('no_trade_windows').insert({
      user_id: user.id,
      label: form.label.trim(),
      day_of_week: form.day_of_week === '' ? null : Number(form.day_of_week),
      start_time: form.start_time,
      end_time: form.end_time,
    });
    setForm({ label: '', day_of_week: '', start_time: '15:25', end_time: '15:45' });
    load();
  };

  const toggleActive = async (w: Window) => {
    if (!user) return;
    await supabase.from('no_trade_windows').update({ is_active: !w.is_active }).eq('id', w.id).eq('user_id', user.id);
    load();
  };

  const removeWindow = async (id: string) => {
    if (!user) return;
    await supabase.from('no_trade_windows').delete().eq('id', id).eq('user_id', user.id);
    setDeleteId(null);
    load();
  };

  return (
    <div>
      <h2 className="section-title"><CalendarOff className="w-4 h-4 text-gold-400" /> بازه‌های معامله‌نکردن</h2>
      <p className="text-xs text-dark-500 mb-3">ساعت‌هایی که خودت می‌دونی نباید معامله کنی (اخبار مهم، اسپرد باز شدن، و غیره) — قبل از ثبت معامله بهت هشدار داده می‌شه.</p>

      <div className="glass-card p-4 space-y-3">
        {loading ? (
          <div className="flex justify-center py-6"><div className="w-5 h-5 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" /></div>
        ) : windows.length === 0 ? (
          <p className="text-xs text-dark-500 text-center py-2">هنوز بازه‌ای تعریف نکردی.</p>
        ) : (
          <div className="space-y-2">
            {windows.map(w => (
              <div key={w.id} className={`flex items-center justify-between gap-2 rounded-lg bg-dark-900/60 px-3 py-2 ${!w.is_active ? 'opacity-40' : ''}`}>
                <div className="flex items-center gap-2 min-w-0">
                  <Clock3 className="w-3.5 h-3.5 text-gold-400 flex-shrink-0" />
                  <span className="text-sm text-white truncate">{w.label}</span>
                  <span className="text-xs text-dark-500 number-ltr flex-shrink-0">{w.start_time.slice(0, 5)}–{w.end_time.slice(0, 5)}</span>
                  <span className="text-[10px] text-dark-500 flex-shrink-0">{w.day_of_week === null ? 'هر روز' : DAYS[w.day_of_week]}</span>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => toggleActive(w)} className="text-[10px] text-dark-400 hover:text-white px-1.5">{w.is_active ? 'غیرفعال' : 'فعال'}</button>
                  <button onClick={() => setDeleteId(w.id)} className="p-1 text-dark-400 hover:text-danger-400"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 pt-2 border-t border-white/5">
          <input type="text" value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} className="input-field text-xs py-1.5 col-span-2" placeholder="مثلاً: NFP" />
          <select value={form.day_of_week} onChange={e => setForm(f => ({ ...f, day_of_week: e.target.value }))} className="select-field text-xs py-1.5">
            <option value="">هر روز</option>
            {DAYS.map((d, i) => <option key={i} value={i}>{d}</option>)}
          </select>
          <input type="time" value={form.start_time} onChange={e => setForm(f => ({ ...f, start_time: e.target.value }))} className="input-field text-xs py-1.5 number-ltr" />
          <input type="time" value={form.end_time} onChange={e => setForm(f => ({ ...f, end_time: e.target.value }))} className="input-field text-xs py-1.5 number-ltr" />
        </div>
        <button onClick={addWindow} disabled={!form.label.trim()} className="btn-secondary text-xs py-1.5 flex items-center gap-1.5 w-fit">
          <Plus className="w-3.5 h-3.5" /> افزودن بازه
        </button>
      </div>

      {deleteId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف بازه</h3>
            <p className="text-sm text-dark-400 mb-4">آیا مطمئنی؟</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => removeWindow(deleteId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
