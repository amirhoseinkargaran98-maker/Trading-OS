import { useCallback, useEffect, useMemo, useState } from 'react';
import { Database, Download, FileSpreadsheet, FileUp, FileJson, Search, Save, Trash2, AlertTriangle, CheckCircle2, X, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency, toPersianDate, toGregorianDateInput, combineTradeDateTime } from '@/lib/utils';
import { downloadBlob, exportRowsJson, normalizeRows, parseImportFile, rowsToCsv, type ImportRow } from '@/lib/importExport';

const EXPORT_FIELDS = ['id','trade_date','entry_time','exit_time','symbol','direction','timeframe','session','strategy_id','setup_id','entry_price','stop_loss','take_profit','exit_price','lot_size','risk_percent','risk_amount','pnl_amount','r_multiple','rr_ratio','result','notes','mistakes','lessons','process_score','review_completed'];

type Validation = { valid: boolean; errors: string[]; duplicate?: boolean };

function combineImportTimestamp(date: string, value: string): string | null {
  const hm = value.trim().match(/^(?:\d{4}-\d{2}-\d{2}T)?(\d{1,2}):(\d{2})/);
  if (!hm) return null;
  return combineTradeDateTime(date, `${String(Number(hm[1])).padStart(2,'0')}:${hm[2]}`);
}

function validateRow(row: ImportRow): Validation {
  const errors: string[] = [];
  const date = String(row.trade_date ?? '');
  const symbol = String(row.symbol ?? '').trim();
  const direction = String(row.direction ?? '').toLowerCase();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) errors.push('trade_date باید YYYY-MM-DD باشد');
  if (!symbol) errors.push('symbol الزامی است');
  if (!['buy','sell'].includes(direction)) errors.push('direction باید buy یا sell باشد');
  for (const key of ['entry_price','stop_loss','take_profit','exit_price']) {
    if (row[key] !== null && row[key] !== undefined && row[key] !== '' && Number.isNaN(Number(row[key]))) errors.push(`${key} عددی نیست`);
  }
  return { valid: errors.length === 0, errors };
}

export default function DataCenter() {
  const { user } = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [saved, setSaved] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [importRows, setImportRows] = useState<ImportRow[]>([]);
  const [importFile, setImportFile] = useState('');
  const [importError, setImportError] = useState('');
  const [importBusy, setImportBusy] = useState(false);
  const [query, setQuery] = useState('');
  const [saveName, setSaveName] = useState('');
  const [toast, setToast] = useState('');
  const [activeSavedId, setActiveSavedId] = useState<string | null>(null);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [importAccountId, setImportAccountId] = useState<string>('');

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const [tradesRes, savedRes, accountsRes] = await Promise.all([
      supabase.from('trades').select('*').eq('user_id', user.id).order('trade_date', { ascending: false }).order('entry_time', { ascending: false }).limit(5000),
      supabase.from('saved_trade_filters').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('accounts').select('id,name,broker').eq('user_id', user.id).eq('is_active', true).order('created_at', { ascending: true }),
    ]);
    setRows(tradesRes.data || []);
    setSaved(savedRes.data || []);
    setAccounts(accountsRes.data || []);
    if (accountsRes.data && accountsRes.data.length > 0 && !importAccountId) {
      setImportAccountId(accountsRes.data[0].id);
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);
  useEffect(() => { load(); }, [load]);

  const filteredRows = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter(t => [t.symbol,t.notes,t.mistakes,t.lessons,t.session,t.result,t.direction].some(v => String(v ?? '').toLowerCase().includes(q)));
  }, [rows, query]);

  const exportData = (type: 'csv'|'json') => {
    const data = filteredRows.map(t => Object.fromEntries(EXPORT_FIELDS.map(f => [f, t[f] ?? null])));
    const stamp = toGregorianDateInput(new Date());
    if (type === 'csv') downloadBlob(rowsToCsv(data, EXPORT_FIELDS), `trading-os-${stamp}.csv`, 'text/csv;charset=utf-8');
    else downloadBlob(exportRowsJson(data), `trading-os-${stamp}.json`, 'application/json;charset=utf-8');
  };

  const onImport = async (file?: File) => {
    if (!file) return;
    setImportError(''); setImportFile(file.name);
    try { setImportRows(normalizeRows(await parseImportFile(file))); }
    catch (e) { setImportRows([]); setImportError(e instanceof Error ? e.message : 'خطا در خواندن فایل'); }
  };

  const validations = useMemo(() => {
    const seen = new Set<string>();
    return importRows.map(row => {
      const base = validateRow(row);
      const key = [row.trade_date, String(row.symbol ?? '').trim().toUpperCase(), String(row.direction ?? '').toLowerCase(), row.entry_price ?? '', row.exit_price ?? ''].join('|');
      if (base.valid && seen.has(key)) return { valid: false, duplicate: true, errors: ['تکراری داخل فایل'] };
      if (base.valid) seen.add(key);
      return base;
    });
  }, [importRows]);
  const validCount = validations.filter(v => v.valid).length;

  const executeImport = async () => {
    if (!user || !validCount) return;
    setImportBusy(true); setImportError('');
    try {
      const [strategyRes, setupRes] = await Promise.all([
        supabase.from('strategies').select('id,name').eq('user_id', user.id),
        supabase.from('setups').select('id,name').eq('user_id', user.id),
      ]);
      if (strategyRes.error) throw strategyRes.error;
      if (setupRes.error) throw setupRes.error;
      const strategyByName = new Map((strategyRes.data || []).map(x => [String(x.name).trim().toLowerCase(), x.id]));
      const setupByName = new Map((setupRes.data || []).map(x => [String(x.name).trim().toLowerCase(), x.id]));
      const validRows = importRows.filter((_, i) => validations[i].valid).map(r => ({
        user_id: user.id,
        account_id: importAccountId || null,
        trade_date: String(r.trade_date),
        entry_time: r.entry_time ? combineImportTimestamp(String(r.trade_date), String(r.entry_time)) : null,
        exit_time: r.exit_time ? combineImportTimestamp(String(r.trade_date), String(r.exit_time)) : null,
        symbol: String(r.symbol).trim().toUpperCase(),
        direction: String(r.direction).toLowerCase(),
        timeframe: r.timeframe ?? null, session: r.session ?? null,
        strategy_id: r.strategy_id ?? (r.strategy ? strategyByName.get(String(r.strategy).trim().toLowerCase()) ?? null : null),
        setup_id: r.setup_id ?? (r.setup ? setupByName.get(String(r.setup).trim().toLowerCase()) ?? null : null),
        entry_price: r.entry_price ?? null, stop_loss: r.stop_loss ?? null, take_profit: r.take_profit ?? null, exit_price: r.exit_price ?? null,
        lot_size: r.lot_size ?? null, risk_percent: r.risk_percent ?? null, risk_amount: r.risk_amount ?? null,
        pnl_amount: r.pnl_amount ?? null, r_multiple: r.r_multiple ?? null, rr_ratio: r.rr_ratio ?? null,
        result: r.result ?? null, notes: r.notes ?? null, mistakes: r.mistakes ?? null, lessons: r.lessons ?? null,
      }));
      // Resolve duplicates against the user's existing trades using the stable market/date identity tuple.
      const dates = [...new Set(validRows.map(r => r.trade_date))];
      const existingRes = await supabase.from('trades').select('trade_date,symbol,direction,entry_price,exit_price').eq('user_id', user.id).in('trade_date', dates);
      if (existingRes.error) throw existingRes.error;
      const existing = new Set((existingRes.data || []).map(t => [t.trade_date,t.symbol,t.direction,t.entry_price,t.exit_price].join('|')));
      const fresh = validRows.filter(r => !existing.has([r.trade_date,r.symbol,r.direction,r.entry_price,r.exit_price].join('|')));
      if (!fresh.length) throw new Error('تمام معاملات فایل با معاملات فعلی تکراری هستند.');
      const { error } = await supabase.from('trades').insert(fresh);
      if (error) throw error;
      setToast(`${fresh.length} معامله با موفقیت وارد شد`); setImportRows([]); setImportFile(''); await load();
    } catch (e) { setImportError(e instanceof Error ? e.message : 'خطا در ورود اطلاعات'); }
    finally { setImportBusy(false); }
  };

  const applySaved = (f: any) => {
    setQuery(String(f.filters?.search ?? ''));
    setActiveSavedId(f.id);
    setToast(`فیلتر «${f.name}» فعال شد`);
  };

  const saveFilter = async () => {
    if (!user || !saveName.trim()) return;
    const { error } = await supabase.from('saved_trade_filters').insert({ user_id: user.id, name: saveName.trim(), filters: { search: query } });
    if (!error) { setSaveName(''); setToast('فیلتر ذخیره شد'); await load(); }
    else setImportError(error.message);
  };

  const deleteSaved = async (id: string) => { await supabase.from('saved_trade_filters').delete().eq('id', id).eq('user_id', user!.id); await load(); };

  return <div className="page-container space-y-5" dir="rtl">
    <div className="section-header"><div><h1 className="text-xl font-bold text-white">مرکز داده</h1><p className="text-xs text-dark-400 mt-1">جستجو، ورود، خروج و مدیریت امن داده‌های ژورنال</p></div><button className="btn-secondary flex items-center gap-2" onClick={load}><RefreshCw className="w-4 h-4"/> بروزرسانی</button></div>

    {toast && <div className="glass-card border-success-500/20 bg-success-500/5 p-3 flex items-center gap-2 text-sm text-success-300"><CheckCircle2 className="w-4 h-4"/>{toast}<button className="mr-auto" onClick={()=>setToast('')}><X className="w-4 h-4"/></button></div>}

    <div className="grid md:grid-cols-3 gap-4">
      <div className="glass-card p-5"><Database className="w-5 h-5 text-gold-400 mb-3"/><p className="text-2xl font-bold text-white">{loading ? '—' : rows.length}</p><p className="text-xs text-dark-400">کل معاملات</p></div>
      <div className="glass-card p-5"><Search className="w-5 h-5 text-blue-400 mb-3"/><p className="text-2xl font-bold text-white">{filteredRows.length}</p><p className="text-xs text-dark-400">نتیجه جستجو</p></div>
      <div className="glass-card p-5"><FileUp className="w-5 h-5 text-emerald-400 mb-3"/><p className="text-2xl font-bold text-white">{validCount}</p><p className="text-xs text-dark-400">ردیف آماده ورود</p></div>
    </div>

    <div className="glass-card p-5 space-y-4"><div className="flex items-center gap-2"><Search className="w-5 h-5 text-gold-400"/><h2 className="font-semibold text-white">جستجوی سراسری معاملات</h2></div><input className="input-field" value={query} onChange={e=>setQuery(e.target.value)} placeholder="نماد، یادداشت، اشتباه، درس، سشن، نتیجه..."/><div className="flex flex-wrap gap-2"><button className="btn-secondary flex items-center gap-2" onClick={()=>exportData('csv')}><Download className="w-4 h-4"/> خروجی CSV</button><button className="btn-secondary flex items-center gap-2" onClick={()=>exportData('json')}><FileJson className="w-4 h-4"/> خروجی JSON</button></div></div>

    <div className="glass-card p-5 space-y-4"><div className="flex items-center gap-2"><FileSpreadsheet className="w-5 h-5 text-emerald-400"/><h2 className="font-semibold text-white">ورود CSV / Excel / JSON</h2></div><div className="border border-dashed border-white/10 rounded-xl p-6 text-center"><input id="trade-import" type="file" accept=".csv,.xlsx,.xls,.json" className="hidden" onChange={e=>onImport(e.target.files?.[0])}/><label htmlFor="trade-import" className="cursor-pointer inline-flex items-center gap-2 btn-secondary"><FileUp className="w-4 h-4"/> انتخاب فایل</label>{importFile && <p className="text-xs text-dark-300 mt-3">{importFile}</p>}</div>{importError && <div className="p-3 rounded-lg bg-danger-500/5 border border-danger-500/20 text-danger-300 text-sm flex gap-2"><AlertTriangle className="w-4 h-4 flex-shrink-0"/>{importError}</div>}{importRows.length>0 && <div className="space-y-3">{accounts.length>0 && <div><label className="label-text">ورود به حساب</label><select value={importAccountId} onChange={e=>setImportAccountId(e.target.value)} className="select-field">{accounts.map(a=><option key={a.id} value={a.id}>{a.name}{a.broker?` — ${a.broker}`:''}</option>)}</select></div>}<div className="flex flex-wrap gap-3 text-xs text-dark-300"><span>کل: {importRows.length}</span><span className="text-success-400">معتبر: {validCount}</span><span className="text-danger-400">دارای خطا: {importRows.length-validCount}</span></div><div className="max-h-64 overflow-auto rounded-lg border border-white/5"><table className="w-full text-xs"><thead className="bg-dark-900 sticky top-0"><tr><th className="p-2">ردیف</th><th className="p-2">تاریخ</th><th className="p-2">نماد</th><th className="p-2">جهت</th><th className="p-2">وضعیت</th><th className="p-2">خطا</th></tr></thead><tbody>{importRows.slice(0,100).map((r,i)=><tr key={i} className="border-t border-white/5"><td className="p-2">{i+1}</td><td className="p-2 number-ltr">{String(r.trade_date??'')}</td><td className="p-2">{String(r.symbol??'')}</td><td className="p-2">{String(r.direction??'')}</td><td className="p-2">{validations[i].valid?<CheckCircle2 className="w-4 h-4 text-success-400"/>:<AlertTriangle className="w-4 h-4 text-danger-400"/>}</td><td className="p-2 text-danger-300">{validations[i].errors.join('، ')}</td></tr>)}</tbody></table></div><button disabled={!validCount||importBusy} onClick={executeImport} className="btn-primary disabled:opacity-40">{importBusy?'در حال ورود...':`وارد کردن ${validCount} معامله معتبر`}</button></div>}</div>

    <div className="glass-card p-5 space-y-4"><div className="flex items-center gap-2"><Save className="w-5 h-5 text-gold-400"/><h2 className="font-semibold text-white">فیلترهای ذخیره‌شده</h2></div><div className="flex gap-2"><input className="input-field flex-1" value={saveName} onChange={e=>setSaveName(e.target.value)} placeholder="مثلاً XAUUSD — معاملات لندن"/><button className="btn-primary flex items-center gap-2" onClick={saveFilter} disabled={!saveName.trim()}><Save className="w-4 h-4"/> ذخیره</button></div>{saved.length===0?<p className="text-xs text-dark-500">هنوز فیلتر ذخیره‌شده‌ای ندارید.</p>:<div className="space-y-2">{saved.map(f=><div key={f.id} className="flex items-center gap-3 p-3 rounded-lg bg-dark-900/40 border border-white/5"><button onClick={()=>applySaved(f)} className={`text-sm text-right flex-1 ${activeSavedId===f.id?'text-gold-400':'text-white'}`}>{f.name}</button><button className="p-2 text-danger-400 hover:bg-danger-500/10 rounded" onClick={()=>deleteSaved(f.id)}><Trash2 className="w-4 h-4"/></button></div>)}</div>}</div>

    <div className="glass-card p-4 text-xs text-dark-400">برای جلوگیری از ورود داده خراب، تاریخ وارداتی باید به شکل <span className="text-white number-ltr">YYYY-MM-DD</span> باشد. قبل از ذخیره، ردیف‌ها اعتبارسنجی و Duplicate Detection می‌شوند. معاملات نامعتبر وارد Database نمی‌شوند.</div>
  </div>;
}
