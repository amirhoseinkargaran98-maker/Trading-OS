import { useState, useEffect, useCallback, useRef } from 'react';
import { Image as ImageIcon, Upload, X, Trash2, Camera, Images, GripVertical } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

type Screenshot = { id: string; url: string; storage_path?: string | null; screenshot_type: string; caption: string | null; created_at: string; };
const TYPE_LABELS: Record<string, string> = { before: 'قبل از ورود', entry: 'حین معامله / ورود', after: 'بعد از خروج' };
const TYPE_HINTS: Record<string, string> = { before: 'Setup، ساختار بازار و سناریوی ورود', entry: 'نقطه ورود و مدیریت حین معامله', after: 'خروج، نتیجه و اتفاق بعد از خروج' };
const BUCKET = 'trade-screenshots';
function extractStoragePath(url?: string | null){ if(!url)return null; const marker=`/${BUCKET}/`; const i=url.indexOf(marker); return i>=0?decodeURIComponent(url.slice(i+marker.length)):null; }
const MAX_PER_TYPE = 5;

function safeRandomId() { try { if (crypto.randomUUID) return crypto.randomUUID(); } catch {} return `${Date.now()}-${Math.random().toString(36).slice(2,10)}`; }

async function optimizeImage(file: File): Promise<{ blob: Blob; contentType: string; extension: string }> {
  if (file.size <= 2 * 1024 * 1024) {
    const contentType = file.type || 'application/octet-stream';
    const extension = contentType === 'image/png' ? 'png' : contentType === 'image/webp' ? 'webp' : contentType === 'image/gif' ? 'gif' : 'jpg';
    return { blob: file, contentType, extension };
  }
  return new Promise((resolve, reject) => {
    const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = () => { URL.revokeObjectURL(url); const scale = Math.min(1, 2200 / Math.max(img.width, img.height)); const w = Math.max(1, Math.round(img.width * scale)); const h = Math.max(1, Math.round(img.height * scale)); const canvas = document.createElement('canvas'); canvas.width=w; canvas.height=h; const ctx=canvas.getContext('2d'); if(!ctx) return reject(new Error('مرورگر امکان فشرده‌سازی تصویر را ندارد.')); ctx.drawImage(img,0,0,w,h); canvas.toBlob(b => b ? resolve({ blob:b, contentType:'image/webp', extension:'webp' }) : reject(new Error('فشرده‌سازی تصویر ناموفق بود.')), 'image/webp', .82); };
    img.onerror=()=>{URL.revokeObjectURL(url); reject(new Error('تصویر قابل خواندن نیست.'));}; img.src=url;
  });
}

export default function TradeScreenshots({ tradeId }: { tradeId: string }) {
  const { user } = useAuth(); const [screenshots,setScreenshots]=useState<Screenshot[]>([]); const [loading,setLoading]=useState(true); const [uploading,setUploading]=useState(false); const [uploadType,setUploadType]=useState('before'); const [error,setError]=useState<string|null>(null); const [lightbox,setLightbox]=useState<Screenshot|null>(null); const [deleteId,setDeleteId]=useState<string|null>(null); const [caption,setCaption]=useState(''); const inputRef=useRef<HTMLInputElement>(null); const dropRef=useRef<HTMLDivElement>(null); const [dragging,setDragging]=useState(false);
  const load=useCallback(async()=>{
    if(!user)return;
    setLoading(true);
    const {data,error:e}=await supabase.from('trade_screenshots').select('*').eq('trade_id',tradeId).eq('user_id',user.id).order('created_at',{ascending:true});
    if(e){setError(e.message);setScreenshots([]);setLoading(false);return;}
    const hydrated=await Promise.all((data||[]).map(async row=>{
      const path=row.storage_path||extractStoragePath(row.url);
      if(!path) return row as Screenshot;
      const {data:signed,error:signedError}=await supabase.storage.from(BUCKET).createSignedUrl(path,86400);
      return {...row,url:signed?.signedUrl||'',storage_path:path} as Screenshot;
    }));
    setScreenshots(hydrated);
    setLoading(false);
  },[user,tradeId]);

  useEffect(()=>{load();},[load]);

  const uploadFiles=async(files:File[])=>{
    if(!user||!files.length||uploading)return;
    setError(null);
    const current=screenshots.filter(s=>s.screenshot_type===uploadType).length;
    if(current+files.length>MAX_PER_TYPE){setError(`برای «${TYPE_LABELS[uploadType]}» حداکثر ${MAX_PER_TYPE} تصویر نگه‌داری می‌شود.`);return;}
    setUploading(true);
    try {
      for(const file of files){
        if(!file.type.startsWith('image/')) throw new Error('فقط فایل تصویری مجاز است.');
        if(file.size>12*1024*1024) throw new Error('حجم هر تصویر نباید بیشتر از ۱۲ مگابایت باشد.');
        const optimized=await optimizeImage(file);
        const path=`${user.id}/${tradeId}/${safeRandomId()}.${optimized.extension}`;
        const {error:ue}=await supabase.storage.from(BUCKET).upload(path,optimized.blob,{cacheControl:'31536000',contentType:optimized.contentType,upsert:false});
        if(ue) throw new Error(/bucket not found/i.test(ue.message)?'فضای تصاویر روی Supabase آماده نشده است.':ue.message);
        const {error:ie}=await supabase.from('trade_screenshots').insert({trade_id:tradeId,user_id:user.id,url:'',storage_path:path,screenshot_type:uploadType,caption:caption.trim()||null});
        if(ie){ await supabase.storage.from(BUCKET).remove([path]); throw ie; }
      }
      setCaption('');
      await load();
    }catch(e:any){
      const message=e?.message||'';
      setError(message.includes('Failed to fetch') || e instanceof TypeError ? 'ارتباط با فضای ذخیره‌سازی تصویر قطع شد. اتصال اینترنت/Firewall و Storage Supabase را بررسی کن و دوباره تلاش کن.' : message || 'خطا در آپلود تصویر');
    }finally{setUploading(false); if(inputRef.current)inputRef.current.value='';}
  };

  const handleDelete=async(s:Screenshot)=>{
    if(!user||uploading)return;
    setError(null);
    const path=s.storage_path||extractStoragePath(s.url);
    const storageResult=path ? await supabase.storage.from(BUCKET).remove([path]) : { error:null };
    const {error:dbError}=await supabase.from('trade_screenshots').delete().eq('id',s.id).eq('user_id',user.id);
    if(storageResult.error && !/not found/i.test(storageResult.error.message||'')){setError(storageResult.error.message);return;}
    if(dbError){setError(dbError.message);return;}
    setScreenshots(prev=>prev.filter(x=>x.id!==s.id));
    setDeleteId(null);
  };
  const grouped=['before','entry','after'].map(type=>({type,items:screenshots.filter(s=>s.screenshot_type===type)}));
  return <div className="glass-card p-4" ref={dropRef}>
    <div className="flex items-start justify-between mb-4 flex-wrap gap-3"><div><h2 className="section-title mb-1"><Images className="w-4 h-4 text-gold-400"/> آرشیو تصویری معامله</h2><p className="text-[11px] text-dark-500">قبل، حین و بعد معامله را کنار هم نگه دار؛ سیستم تصاویر بزرگ را قبل از آپلود بهینه می‌کند.</p></div><div className="flex gap-2 flex-wrap"><select value={uploadType} onChange={e=>setUploadType(e.target.value)} className="select-field w-auto text-xs py-1.5">{Object.entries(TYPE_LABELS).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select><button type="button" onClick={()=>inputRef.current?.click()} disabled={uploading} className="btn-primary text-xs py-1.5 flex items-center gap-1.5"><Upload className="w-3.5 h-3.5"/>{uploading?'در حال آماده‌سازی...':'افزودن تصویر'}</button><input ref={inputRef} type="file" accept="image/*" multiple className="hidden" onChange={e=>uploadFiles(Array.from(e.target.files||[]))}/></div></div>
    <div className="grid md:grid-cols-[1fr_auto] gap-3 mb-4"><div className={`input-field flex items-center gap-2 text-xs cursor-pointer transition-all ${dragging ? "border-gold-500/60 bg-gold-500/10 text-gold-300" : "text-dark-400"}`} onClick={()=>inputRef.current?.click()} onDragOver={e=>{e.preventDefault();setDragging(true)}} onDragLeave={()=>setDragging(false)} onDrop={e=>{e.preventDefault();setDragging(false);uploadFiles(Array.from(e.dataTransfer.files||[]))}}><Camera className="w-4 h-4 text-gold-400"/><span>{dragging ? "تصویر را همین‌جا رها کن" : "تصویر را اینجا رها کن یا برای انتخاب چند تصویر کلیک کن"}</span><GripVertical className="w-4 h-4 mr-auto opacity-30"/></div><input value={caption} onChange={e=>setCaption(e.target.value)} className="input-field md:w-64 text-xs" placeholder="توضیح کوتاه (اختیاری)"/></div>
    {error&&<p className="text-xs text-danger-400 mb-3">{error}</p>}
    {loading?<div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-gold-500 border-t-transparent rounded-full animate-spin"/></div>:<div className="space-y-5">{grouped.map(g=><div key={g.type} className="rounded-xl border border-white/5 bg-dark-900/30 p-3"><div className="flex items-center justify-between mb-2"><div><p className="text-xs font-semibold text-white">{TYPE_LABELS[g.type]}</p><p className="text-[10px] text-dark-500 mt-0.5">{TYPE_HINTS[g.type]}</p></div><span className="text-[10px] text-dark-500">{g.items.length}/{MAX_PER_TYPE}</span></div>{g.items.length===0?<div className="border border-dashed border-white/10 rounded-lg py-6 text-center"><ImageIcon className="w-6 h-6 text-dark-600 mx-auto mb-1"/><p className="text-[10px] text-dark-500">هنوز تصویری ثبت نشده</p></div>:<div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">{g.items.map(s=><div key={s.id} className="relative group aspect-video rounded-lg overflow-hidden border border-white/10 bg-dark-950"><img src={s.url} alt={TYPE_LABELS[s.screenshot_type]} loading="lazy" decoding="async" className="w-full h-full object-cover cursor-zoom-in transition-transform group-hover:scale-[1.03]" onClick={()=>setLightbox(s)}/><button type="button" onClick={()=>setDeleteId(s.id)} className="absolute top-1 left-1 p-1 rounded-md bg-black/70 text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-danger-600"><Trash2 className="w-3 h-3"/></button>{s.caption&&<span className="absolute bottom-0 inset-x-0 bg-black/70 text-[9px] px-2 py-1 truncate text-white">{s.caption}</span>}</div>)}</div>}</div>)}</div>}
    {lightbox&&<div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-[80] p-4" onClick={()=>setLightbox(null)}><button type="button" onClick={()=>setLightbox(null)} className="absolute top-4 left-4 text-white/70 hover:text-white"><X className="w-7 h-7"/></button><div className="max-w-6xl max-h-[90vh]" onClick={e=>e.stopPropagation()}><img src={lightbox.url} alt="" className="max-w-full max-h-[82vh] rounded-xl object-contain"/><p className="text-center text-xs text-dark-300 mt-2">{TYPE_LABELS[lightbox.screenshot_type]}{lightbox.caption?` · ${lightbox.caption}`:''}</p></div></div>}
    {deleteId&&<div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[90] p-4"><div className="glass-card p-6 w-full max-w-sm"><h3 className="text-lg font-semibold text-white mb-2">حذف تصویر</h3><p className="text-sm text-dark-400 mb-4">این تصویر از آرشیو معامله حذف می‌شود.</p><div className="flex gap-3 justify-end"><button type="button" onClick={()=>setDeleteId(null)} className="btn-secondary">انصراف</button><button type="button" onClick={()=>{const s=screenshots.find(x=>x.id===deleteId);if(s)handleDelete(s)}} className="btn-danger">حذف</button></div></div></div>}
  </div>;
}
