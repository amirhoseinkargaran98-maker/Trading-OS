import { sampleConfidence } from '@/lib/tradingEngine';

export type ImprovementTrade = {
  pnl_amount?: number | null;
  r_multiple?: number | null;
  psychology_tags?: string[] | null;
  mistakes?: string | null;
};

export type MistakeCost = {
  key: string;
  label: string;
  trades: number;
  pnl: number;
  r: number;
  avgR: number;
  confidence: 'low' | 'medium' | 'high';
};

const mistakeMap: Record<string, { label: string; keywords: string[] }> = {
  revenge: { label: 'انتقام از بازار', keywords: ['revenge', 'انتقام'] },
  fomo: { label: 'FOMO / تعقیب بازار', keywords: ['fomo', 'تعقیب', 'جا ماندن'] },
  overtrading: { label: 'اورترید', keywords: ['overtrading', 'اورترید', 'زیاده‌روی'] },
  fear: { label: 'ترس', keywords: ['fear', 'ترس'] },
  greed: { label: 'طمع', keywords: ['greed', 'طمع'] },
  hesitation: { label: 'تردید', keywords: ['hesitation', 'تردید'] },
  premature_exit: { label: 'خروج زودهنگام', keywords: ['premature', 'زودهنگام', 'زود خارج'] },
  move_sl: { label: 'جابجایی استاپ', keywords: ['move sl', 'جابجایی استاپ', 'استاپ را جابجا'] },
  risk_violation: { label: 'نقض ریسک', keywords: ['risk violation', 'نقض ریسک', 'ریسک بیش از'] },
  rule_violation: { label: 'نقض قانون', keywords: ['rule violation', 'نقض قانون', 'خلاف قانون'] },
};

function normalize(value: string) {
  return value.toLowerCase().trim();
}

function tradeMatches(trade: ImprovementTrade, keywords: string[]) {
  const tags = (trade.psychology_tags || []).map(normalize);
  const mistakes = normalize(trade.mistakes || '');
  return keywords.some(k => tags.includes(normalize(k)) || mistakes.includes(normalize(k)));
}

export function calculateMistakeCosts(trades: ImprovementTrade[]): MistakeCost[] {
  return Object.entries(mistakeMap).map(([key, meta]) => {
    const matched = trades.filter(t => tradeMatches(t, meta.keywords));
    const pnl = matched.reduce((s, t) => s + (Number(t.pnl_amount) || 0), 0);
    const r = matched.reduce((s, t) => s + (Number(t.r_multiple) || 0), 0);
    return {
      key,
      label: meta.label,
      trades: matched.length,
      pnl,
      r,
      avgR: matched.length ? r / matched.length : 0,
      confidence: sampleConfidence(matched.length),
    };
  }).filter(x => x.trades > 0).sort((a, b) => a.r - b.r);
}

export function normalizeActionProgress(current: number, target: number) {
  if (target <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((current / target) * 100)));
}
