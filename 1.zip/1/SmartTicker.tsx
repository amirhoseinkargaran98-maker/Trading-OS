import { useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import { Activity, AlertTriangle, Brain, CircleDollarSign, Gauge, ShieldCheck, Sparkles, Target, Trophy, Wallet } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency, toGregorianDateInput } from '@/lib/utils';

type Tone = 'neutral' | 'positive' | 'warning' | 'danger';
type TickerIcon = typeof Activity;
type Item = { id:string; label:string; value:string; tone?:Tone; icon?:TickerIcon; priority?:number };
type TradeLite = { trade_date:string; pnl_amount:number|null; result:string|null; r_multiple:number|null; process_score:number|null; review_completed:boolean|null; psychology_tags:string[]|null; symbol:string|null };
type AccountLite = { current_balance:number|null };
type NewsLite = { title:string; currency:string; impact:'high'|'medium'|'low'|'unknown'; minutes:number|null; bias:'bullish'|'bearish'|'mixed'|'neutral' };

const QUOTES = [
  'وظیفه تو پیش‌بینی بازار نیست؛ وظیفه تو اجرای دقیق مزیت آماری‌ات است.',
  'یک معامله خوب می‌تواند ضررده باشد؛ کیفیت تصمیم را با نتیجه یک معامله اشتباه نگیر.',
  'معامله نکردن وقتی Setup وجود ندارد، خودش یک تصمیم حرفه‌ای است.',
  'بعد از یک ضرر، معامله بعدی نباید پاسخ معامله قبلی باشد.',
  'هیچ سودی ارزش شکستن قانونی را ندارد که برای محافظت از سرمایه‌ات نوشته‌ای.',
  'کیفیت اجرای یک معامله مهم‌تر از هیجان نتیجه آن است.',
  'قبل از پرسیدن «چقدر می‌توانم بگیرم؟» بپرس «اگر اشتباه کنم، چقدر هزینه می‌دهم؟»',
  'اگر نتیجه خوب است اما فرآیند بد بوده، آن برد را به عادت تبدیل نکن.',
  'اگر نتیجه بد است اما فرآیند درست بوده، آن ضرر را شکست شخصی تلقی نکن.',
  'بازار چیزی به تو بدهکار نیست؛ تو فقط مسئول کیفیت تصمیم بعدی هستی.',
];

function signedCurrency(value: number) {
  const prefix = value > 0 ? '+' : '';
  return `${prefix}${formatCurrency(value)}`;
}

function ItemGroup({ items, hidden = false }: { items: Item[]; hidden?: boolean }) {
  return (
    <div className="smart-ticker-group" aria-hidden={hidden}>
      {items.map((item) => {
        const Icon = item.icon || Activity;
        return (
          <div key={item.id} className={`smart-ticker-item smart-ticker-item--${item.tone || 'neutral'}`}>
            <Icon className="h-3.5 w-3.5 shrink-0" />
            <span className="smart-ticker-label">{item.label}</span>
            <span className="smart-ticker-value">{item.value}</span>
          </div>
        );
      })}
    </div>
  );
}

export default function SmartTicker() {
  const { user } = useAuth();
  const [items, setItems] = useState<Item[]>([]);
  const [quote, setQuote] = useState(QUOTES[0]);
  const [news, setNews] = useState<NewsLite[]>([]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    const load = async () => {
      const now=new Date();
      const today=toGregorianDateInput(now);
      const weekStart=toGregorianDateInput(new Date(now.getFullYear(),now.getMonth(),now.getDate()-6));
      const monthStart=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-01`;
      const activeId = getActiveAccountId();
      const [{data:trades,error:te},{data:account},{data:rs}, newsResult]=await Promise.all([
        supabase.from('trades').select('trade_date,pnl_amount,result,r_multiple,process_score,review_completed,psychology_tags,symbol').eq('user_id',user.id).eq('account_id', getActiveAccountId()).gte('trade_date',monthStart).lte('trade_date',today),
        supabase.from('accounts').select('current_balance').eq('user_id',user.id).eq('id',activeId).maybeSingle(),
        supabase.from('risk_settings').select('daily_max_loss').eq('user_id',user.id).eq('account_id',activeId).eq('is_active',true).maybeSingle(),
        supabase.functions.invoke('economic-calendar', { body: { symbols: ['XAUUSD','EURUSD','DJI'], limit: 4 } })
      ]);
      if(cancelled)return;
      const fetchedNews: NewsLite[] = newsResult?.data?.events && Array.isArray(newsResult.data.events) ? newsResult.data.events as NewsLite[] : [];
      if(fetchedNews.length) setNews(fetchedNews);
      const all=(trades||[]) as TradeLite[];
      const todayTrades=all.filter(t=>t.trade_date===today);
      const week=all.filter(t=>t.trade_date>=weekStart);
      const closed=all.filter(t=>t.result==='win'||t.result==='loss'||t.result==='breakeven');
      const todayPnl=todayTrades.reduce((a,t)=>a+Number(t.pnl_amount||0),0);
      const weekPnl=week.reduce((a,t)=>a+Number(t.pnl_amount||0),0);
      const wins=closed.filter(t=>t.result==='win').length;
      const winRate=closed.length?wins/closed.length*100:0;
      const rsn=closed.filter(t=>Number.isFinite(Number(t.r_multiple)));
      const avgR=rsn.length?rsn.reduce((a,t)=>a+Number(t.r_multiple),0)/rsn.length:0;
      const scored=all.filter(t=>Number.isFinite(Number(t.process_score)));
      const process=scored.length?scored.reduce((a,t)=>a+Number(t.process_score),0)/scored.length:null;
      const reviewed=all.filter(t=>t.review_completed===true).length;
      const balance=Number(account?.current_balance || 0);
      const dailyLoss=Number((rs||{})?.daily_max_loss||2);
      const todayPct=balance>0?todayPnl/balance*100:0;
      const riskStatus=Math.abs(Math.min(0,todayPct))>=dailyLoss?'قفل':Math.abs(Math.min(0,todayPct))>=dailyLoss*.8?'احتیاط':'آماده';
      const symbolPnl:Record<string,number>={};
      all.forEach(t=>{if(t.symbol)symbolPnl[t.symbol]=(symbolPnl[t.symbol]||0)+Number(t.pnl_amount||0)});
      const best=Object.entries(symbolPnl).sort((a,b)=>b[1]-a[1])[0];
      const psych:Record<string,number>={};
      all.forEach(t=>(t.psychology_tags||[]).forEach(p=>{psych[p]=(psych[p]||0)+1}));
      const bad=['fomo','revenge','overtrading','fear','greed','anger','hesitation','FOMO','انتقام','اورترید','ترس','طمع','عصبانیت'];
      const recurring=Object.entries(psych).filter(([k,v])=>bad.includes(k)&&v>=2).sort((a,b)=>b[1]-a[1])[0];
      const focus=todayTrades.length===0?'فقط Setupهای A+؛ نبودن معامله بهتر از معامله خارج از پلن است.':todayPnl<0?'امروز بعد از ضرر، جبران نکن؛ کیفیت تصمیم بعدی را حفظ کن.':process!==null&&process<70?'امروز Process را بالاتر از P&L قرار بده.':'کیفیت اجرا را بالاتر از تعداد معاملات نگه دار.';
      const quotes=todayPnl<0?['بعد از یک ضرر، معامله بعدی نباید پاسخ معامله قبلی باشد.','ریسک اضافه، راه جبران نیست؛ راه بزرگ‌تر کردن خطاست.']:process!==null&&process<70?['اگر فرآیند بد بوده، برد را به عادت تبدیل نکن.','کیفیت تصمیم را با نتیجه یک معامله اشتباه نگیر.']:QUOTES;
      const qi=Math.floor(Date.now()/(90*60*1000))%quotes.length;
      const dynamic:Item[]=[
        {id:'balance',label:'موجودی',value:formatCurrency(balance),icon:Wallet,priority:100},
        {id:'today',label:'امروز',value:signedCurrency(todayPnl),tone:todayPnl>=0?'positive':'danger',icon:todayPnl>=0?Trophy:AlertTriangle,priority:95},
        {id:'week',label:'۷ روز',value:signedCurrency(weekPnl),tone:weekPnl>=0?'positive':'danger',icon:Activity,priority:90},
        {id:'risk',label:'ریسک',value:riskStatus,tone:riskStatus==='قفل'?'danger':riskStatus==='احتیاط'?'warning':'positive',icon:ShieldCheck,priority:92},
        {id:'process',label:'Process',value:process===null?'—':`${process.toFixed(0)}/100`,tone:process===null?'neutral':process>=80?'positive':process>=65?'warning':'danger',icon:Gauge,priority:88},
        {id:'winrate',label:'Win Rate',value:`${winRate.toFixed(0)}٪`,tone:winRate>=50?'positive':'warning',icon:Target,priority:80}
      ];
      if(best)dynamic.push({id:'edge',label:'نماد برتر',value:`${best[0]} · ${signedCurrency(best[1])}`,tone:best[1]>=0?'positive':'danger',icon:Trophy,priority:84});
      if(recurring)dynamic.push({id:'psych',label:'هشدار روانی',value:`${recurring[0]} · ${recurring[1]} بار`,tone:'warning',icon:Brain,priority:120});
      dynamic.push(
        {id:'focus',label:'تمرکز امروز',value:focus,icon:Sparkles,priority:118},
        {id:'rule',label:'قانون امروز',value:'ریسک فقط ۰٫۵٪ یا ۱٪ و داخل باند مجاز.',icon:ShieldCheck,priority:110},
        {id:'review',label:'Review',value:all.length?`${Math.round(reviewed/all.length*100)}٪ کامل`:'—',tone:all.length&&reviewed/all.length>=.8?'positive':'warning',icon:Brain,priority:70}
      );
      const currentNews = fetchedNews[0] || news[0];
      if(currentNews) {
        const n=currentNews;
        const tone=n.impact==='high'?'danger':n.impact==='medium'?'warning':'neutral';
        dynamic.push({id:'news',label:'خبر نزدیک',value:`${n.currency} · ${n.title}${n.minutes!==null?` · ${n.minutes} دقیقه`:''}`,tone,icon:AlertTriangle,priority:n.impact==='high'?130:100});
      }
      setQuote(quotes[qi]);
      setItems(dynamic.sort((a,b)=>(b.priority||0)-(a.priority||0)));
    };
    load();
    const onAccountChanged = () => load();
    window.addEventListener('trading-os-active-account-changed', onAccountChanged);
    const timer = window.setInterval(load, 60_000);
    return () => { cancelled = true; window.clearInterval(timer); window.removeEventListener('trading-os-active-account-changed', onAccountChanged); };
  }, [user]);

  const tickerItems = useMemo(() => [
    ...items,
    { id: 'quote', label: 'مربی روان‌شناسی', value: quote, icon: Sparkles, tone: 'neutral' as Tone, priority: 1 },
  ], [items, quote]);

  const trackRef = useRef<HTMLDivElement>(null);
  const loopCount = useRef(0);
  const pauseTimeout = useRef<number | null>(null);
  const handleIteration = () => {
    loopCount.current += 1;
    if (loopCount.current % 3 === 0) {
      const el = trackRef.current;
      if (!el) return;
      el.style.animationPlayState = 'paused';
      if (pauseTimeout.current) window.clearTimeout(pauseTimeout.current);
      pauseTimeout.current = window.setTimeout(() => {
        if (trackRef.current) trackRef.current.style.animationPlayState = 'running';
      }, 15_000);
    }
  };
  useEffect(() => () => { if (pauseTimeout.current) window.clearTimeout(pauseTimeout.current); }, []);

  if (!user) return null;
  const visibleItems = tickerItems.length ? tickerItems : [{ id:'fallback', label:'Trading OS', value:'در حال آماده‌سازی داده‌های حساب…', icon:Activity, tone:'neutral' as Tone, priority:1 }];
  // Duration scales with item count, not measured pixel width — a fixed
  // px/s speed driven by a JS-measured width forces a style update (and a
  // visible animation restart) every time `items`/`quote` change, which is
  // what caused the "pause then snap back to the start" glitch. Item count
  // only changes rarely, so this stays stable across the periodic reloads,
  // and the two ItemGroup copies are identical, so the CSS default
  // `-50%` distance is always exactly right — no JS measurement needed.
  const durationSeconds = Math.max(70, visibleItems.length * 6.5);

  return (
    <section className="smart-ticker-shell" aria-label="نوار هوشمند Trading OS">
      <div className="smart-ticker-live"><span className="smart-ticker-live-dot" /> LIVE</div>
      <div className="smart-ticker-viewport">
        <div
          ref={trackRef}
          className="smart-ticker-track"
          style={{ "--ticker-duration": `${durationSeconds}s` } as CSSProperties}
          onAnimationIteration={handleIteration}
        >
          <ItemGroup items={visibleItems} />
          <ItemGroup items={visibleItems} hidden />
        </div>
      </div>
      <div className="smart-ticker-fade smart-ticker-fade--start" />
      <div className="smart-ticker-fade smart-ticker-fade--end" />
    </section>
  );
}