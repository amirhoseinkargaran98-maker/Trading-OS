import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          display_name: string | null;
          avatar_url: string | null;
          initial_capital: number;
          current_capital: number;
          currency: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['profiles']['Row']> & { id: string };
        Update: Partial<Database['public']['Tables']['profiles']['Row']>;
      };
      accounts: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          broker: string | null;
          account_type: string;
          currency: string;
          initial_balance: number;
          current_balance: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['accounts']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['accounts']['Row']>;
      };
      trades: {
        Row: {
          id: string;
          user_id: string;
          account_id: string | null;
          strategy_id: string | null;
          setup_id: string | null;
          trade_number: number;
          trade_date: string;
          entry_time: string | null;
          exit_time: string | null;
          duration_minutes: number | null;
          symbol: string;
          direction: 'buy' | 'sell';
          timeframe: string | null;
          session: string | null;
          market_condition: string | null;
          entry_price: number | null;
          exit_price: number | null;
          stop_loss: number | null;
          take_profit: number | null;
          lot_size: number | null;
          contract_size: number;
          risk_percent: number | null;
          risk_amount: number | null;
          potential_profit: number | null;
          rr_ratio: number | null;
          pnl_amount: number | null;
          pnl_percent: number | null;
          capital_before: number | null;
          capital_after: number | null;
          result: 'win' | 'loss' | 'breakeven' | 'open' | null;
          r_multiple: number | null;
          entry_reason: string | null;
          exit_reason: string | null;
          trend: string | null;
          feeling_before: string | null;
          feeling_during: string | null;
          feeling_after: string | null;
          psychology_tags: string[] | null;
          mistakes: string | null;
          lessons: string | null;
          notes: string | null;
          is_open: boolean;
          tags: string[] | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['trades']['Row'], 'id' | 'trade_number' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['trades']['Row']>;
      };
      strategies: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          description: string | null;
          rules: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['strategies']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['strategies']['Row']>;
      };
      setups: {
        Row: {
          id: string;
          user_id: string;
          strategy_id: string | null;
          name: string;
          description: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['setups']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['setups']['Row']>;
      };
      daily_reviews: {
        Row: {
          id: string;
          user_id: string;
          review_date: string;
          mood: string | null;
          content: string | null;
          lessons: string | null;
          plan_for_tomorrow: string | null;
          daily_pnl: number | null;
          total_trades: number;
          wins: number;
          losses: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['daily_reviews']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['daily_reviews']['Row']>;
      };
      notes: {
        Row: {
          id: string;
          user_id: string;
          note_type: string;
          title: string | null;
          content: string;
          note_date: string | null;
          tags: string[] | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['notes']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['notes']['Row']>;
      };
      goals: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          goal_type: string;
          target_value: number | null;
          current_value: number;
          period: string;
          start_date: string | null;
          end_date: string | null;
          is_achieved: boolean;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['goals']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['goals']['Row']>;
      };
      risk_settings: {
        Row: {
          id: string;
          user_id: string;
          account_id: string | null;
          max_risk_per_trade: number;
          daily_max_loss: number;
          daily_profit_target: number;
          max_trades_per_day: number;
          max_consecutive_losses: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['risk_settings']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['risk_settings']['Row']>;
      };
    };
  };
};
