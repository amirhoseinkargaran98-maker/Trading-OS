import { supabase } from '@/lib/supabase';

export type CoachContext = {
  profile?: Record<string, unknown> | null;
  riskSettings?: Record<string, unknown> | null;
  trades?: Record<string, unknown>[];
  goals?: Record<string, unknown>[];
  journals?: Record<string, unknown>[];
  question?: string;
  mode?: 'chat' | 'pre_trade' | 'post_trade' | 'daily_review' | 'performance';
};

export async function askTradingCoach(context: CoachContext) {
  const { data, error } = await supabase.functions.invoke('ai-coach', {
    body: context,
  });

  if (error) throw new Error(error.message || 'اتصال به AI Coach برقرار نشد.');
  if (!data?.success) throw new Error(data?.error || 'پاسخی از AI Coach دریافت نشد.');
  return data;
}

export function calculateDisciplineScore(trades: Record<string, unknown>[]) {
  if (!trades.length) return 100;
  let score = 100;
  const recent = trades.slice(0, 30);
  const revenge = recent.filter(t => Array.isArray(t.psychology_tags) && (t.psychology_tags as string[]).includes('revenge')).length;
  const fomo = recent.filter(t => Array.isArray(t.psychology_tags) && (t.psychology_tags as string[]).includes('fomo')).length;
  const overtrade = recent.filter(t => Array.isArray(t.psychology_tags) && (t.psychology_tags as string[]).includes('overtrading')).length;
  score -= Math.min(30, revenge * 8);
  score -= Math.min(20, fomo * 4);
  score -= Math.min(20, overtrade * 5);
  return Math.max(0, Math.round(score));
}

export function buildLocalCoachSignals(trades: Record<string, unknown>[]) {
  const recent = trades.slice(0, 50);
  const losses = recent.filter(t => t.result === 'loss');
  const wins = recent.filter(t => t.result === 'win');
  const pnl = recent.reduce((s, t) => s + Number(t.pnl_amount || 0), 0);
  const tags = recent.flatMap(t => Array.isArray(t.psychology_tags) ? t.psychology_tags as string[] : []);
  const counts = tags.reduce<Record<string, number>>((m, tag) => ({ ...m, [tag]: (m[tag] || 0) + 1 }), {});
  const topTag = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
  return {
    sampleSize: recent.length,
    wins: wins.length,
    losses: losses.length,
    winRate: recent.length ? Math.round((wins.length / recent.length) * 100) : 0,
    pnl,
    disciplineScore: calculateDisciplineScore(recent),
    topPsychologyTag: topTag?.[0] || null,
    topPsychologyCount: topTag?.[1] || 0,
  };
}
