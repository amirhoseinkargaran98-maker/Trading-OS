import { sampleConfidence } from '@/lib/tradingEngine';
import { getDayOfWeekFromDateInput, getHourFromTradeTimestamp } from '@/lib/utils';

/**
 * Deterministic, AI-free edge discovery engine.
 * It deliberately separates descriptive evidence from actionable recommendations.
 */
export type DiscoveryTrade = {
  trade_date?: string | null;
  result?: string | null;
  pnl_amount?: number | null;
  r_multiple?: number | null;
  risk_percent?: number | null;
  session?: string | null;
  symbol?: string | null;
  direction?: string | null;
  entry_reason?: string | null;
  psychology_tags?: string[] | null;
  process_score?: number | null;
  rr_ratio?: number | null;
  entry_time?: string | null;
};

export type PatternDimension = 'session'|'symbol'|'direction'|'entry_reason'|'psychology'|'risk_band'|'day'|'hour';
export type PatternRow = {
  id: string;
  dimensions: {dimension: PatternDimension; value: string; label: string}[];
  trades: number;
  wins: number;
  winRate: number;
  pnl: number;
  avgR: number;
  avgProcess: number | null;
  profitFactor: number;
  expectancy: number;
  maxLoss: number;
  confidence: 'low'|'moderate'|'strong';
  qualityScore: number;
  status: 'edge'|'warning'|'neutral';
};

const n=(v:unknown)=>Number.isFinite(Number(v))?Number(v):0;
const labels:Record<string,string>={
  london:'لندن',new_york:'نیویورک',asian:'آسیا',sydney:'سیدنی',buy:'خرید',sell:'فروش',
  calm:'😌 آرام',confident:'💪 مطمئن',neutral:'😐 خنثی',anxious:'😟 نگران',fearful:'😨 ترس',
  greedy:'🤑 طمع',excited:'🤩 هیجان‌زده',angry:'😡 عصبانی',satisfied:'😊 راضی',frustrated:'😤 ناامید'
};
const label=(v:string)=>labels[v]||v.replace(/_/g,' ');

function fieldValues(t:DiscoveryTrade,d:PatternDimension): string[]{
  if(d==='psychology') return (t.psychology_tags||[]).filter(Boolean).map(String);
  if(d==='risk_band') { const r=n(t.risk_percent); return r<=0?[]:[r<=0.5?'≤ 0.5%':r<=1?'0.5% تا 1%':'> 1%']; }
  if(d==='day') { const x=getDayOfWeekFromDateInput(t.trade_date); return x===null?[]:[String(x)]; }
  if(d==='hour') { const x=getHourFromTradeTimestamp(t.entry_time, 'Asia/Tehran'); return x===null?[]:[String(x)]; }
  const v=t[d]; return v==null||v===''?[]:[String(v)];
}

function metrics(rows:DiscoveryTrade[]): Omit<PatternRow,'id'|'dimensions'|'qualityScore'|'confidence'|'status'> {
  const pnl=rows.reduce((s,t)=>s+n(t.pnl_amount),0);
  const wins=rows.filter(t=>n(t.pnl_amount)>0);
  const losses=rows.filter(t=>n(t.pnl_amount)<0);
  const grossW=wins.reduce((s,t)=>s+n(t.pnl_amount),0);
  const grossL=Math.abs(losses.reduce((s,t)=>s+n(t.pnl_amount),0));
  const rs=rows.filter(t=>t.r_multiple!=null).map(t=>n(t.r_multiple));
  const ps=rows.filter(t=>t.process_score!=null).map(t=>n(t.process_score));
  return {trades:rows.length,wins:wins.length,winRate:rows.length?wins.length/rows.length*100:0,pnl,avgR:rs.length?rs.reduce((a,b)=>a+b,0)/rs.length:0,avgProcess:ps.length?ps.reduce((a,b)=>a+b,0)/ps.length:null,profitFactor:grossL?grossW/grossL:(grossW>0?Infinity:0),expectancy:rows.length?pnl/rows.length:0,maxLoss:losses.length?Math.min(...losses.map(t=>n(t.pnl_amount))):0};
}

function evaluate(base:ReturnType<typeof metrics>, baseline:ReturnType<typeof metrics>): Pick<PatternRow,'confidence'|'qualityScore'|'status'> {
  // Evidence is weighted by sample size and effect size; no claim of statistical significance.
  const size=Math.min(1,base.trades/30);
  const edge=Math.max(-1,Math.min(1,(base.avgR-baseline.avgR)/0.8));
  const winEffect=Math.max(-1,Math.min(1,(base.winRate-baseline.winRate)/25));
  const processEffect=base.avgProcess==null||baseline.avgProcess==null?0:Math.max(-1,Math.min(1,(base.avgProcess-baseline.avgProcess)/20));
  const score=Math.round((50 + edge*25*size + winEffect*15*size + processEffect*10*size));
  const rawConfidence=sampleConfidence(base.trades);
  const confidence=rawConfidence==='high'?'strong':rawConfidence==='medium'?'moderate':'low';
  const status=base.trades>=5 && base.avgR>0 && base.winRate>=baseline.winRate-2?'edge':base.trades>=5&&base.avgR<0?'warning':'neutral';
  return {confidence,qualityScore:Math.max(0,Math.min(100,score)),status};
}

export function discoverPatterns(trades:DiscoveryTrade[], dimensions:PatternDimension[]=['session','symbol','direction','entry_reason','psychology','risk_band','day','hour']):PatternRow[]{
  const closed=trades.filter(t=>t.result!=='open' && (t.pnl_amount!=null || t.r_multiple!=null));
  const baseline=metrics(closed);
  const candidates:PatternRow[]=[];
  const singles=dimensions.flatMap(d=>{
    const map=new Map<string,DiscoveryTrade[]>();
    closed.forEach(t=>fieldValues(t,d).forEach(v=>{const a=map.get(v)||[];a.push(t);map.set(v,a);}));
    return [...map.entries()].map(([v,rows])=>({rows,dimensions:[{dimension:d,value:v,label:label(v)}]}));
  });
  const pairs: typeof singles=[];
  const pairDims=dimensions.filter(d=>['session','symbol','direction','entry_reason','psychology','risk_band'].includes(d));
  for(let i=0;i<pairDims.length;i++)for(let j=i+1;j<pairDims.length;j++){
    const a=pairDims[i],b=pairDims[j]; const map=new Map<string,DiscoveryTrade[]>();
    closed.forEach(t=>{const av=fieldValues(t,a),bv=fieldValues(t,b);av.forEach(x=>bv.forEach(y=>{const k=`${x}|||${y}`;const arr=map.get(k)||[];arr.push(t);map.set(k,arr);}));});
    for(const [k,rows] of map){if(rows.length<5)continue;const [x,y]=k.split('|||');pairs.push({rows,dimensions:[{dimension:a,value:x,label:label(x)},{dimension:b,value:y,label:label(y)}]});}
  }
  for(const c of [...singles,...pairs]){
    if(c.rows.length<5)continue;
    const m=metrics(c.rows); const ev=evaluate(m,baseline);
    candidates.push({...m,id:c.dimensions.map(d=>`${d.dimension}:${d.value}`).join('|'),dimensions:c.dimensions,...ev});
  }
  return candidates.sort((a,b)=>{const sa=(a.status==='edge'?1:a.status==='warning'?-1:0);const sb=(b.status==='edge'?1:b.status==='warning'?-1:0);return (sb-sa)||(b.qualityScore-a.qualityScore)||(b.trades-a.trades)});
}

export function discoverySummary(patterns:PatternRow[]){
  const edges=patterns.filter(p=>p.status==='edge');
  const warnings=patterns.filter(p=>p.status==='warning');
  return {patterns:patterns.length,edges:edges.length,warnings:warnings.length,strong:patterns.filter(p=>p.confidence==='strong').length,topEdges:edges.slice(0,5),topWarnings:warnings.slice(0,5)};
}
