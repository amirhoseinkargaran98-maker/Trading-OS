import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { buildPeriodReport, periodRange, shiftPeriod, type ReportPeriod } from '@/lib/reviewReports';
import { formatCurrency, toPersianDate } from '@/lib/utils';
import { ArrowRight, ArrowLeft, BarChart3, CalendarDays, CheckCircle2, ChevronLeft, ChevronRight, CircleAlert, Download, Gauge, RefreshCw, ShieldAlert, Sparkles, Target, TrendingDown, TrendingUp } from 'lucide-react';
import { BarChart, Bar, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell } from 'recharts';

const faPeriod: Record<ReportPeriod,string>={day:'روزانه',week:'هفتگی',month:'ماهانه'};
const fmt=(n:number)=>`${n>=0?'+':''}${n.toFixed(2)}`;

function Metric({label,value,sub,positive}: {label:string;value:string;sub?:string;positive?:boolean}){
  return <div className="glass-card p-4"><p className="text-xs text-dark-400">{label}</p><p className={`text-xl font-bold mt-1 ${positive===true?'text-success-400':positive===false?'text-danger-400':'text-white'}`}>{value}</p>{sub&&<p className="text-[11px] text-dark-500 mt-1">{sub}</p>}</div>
}

export default function Reports(){
  const {user,profile}=useAuth();
  const [period,setPeriod]=useState<ReportPeriod>('week');
  const [range,setRange]=useState(()=>periodRange('week'));
  const [trades,setTrades]=useState<any[]>([]);
  const [loading,setLoading]=useState(true);
  const [loadError,setLoadError]=useState<string|null>(null);
  const load=useCallback(async()=>{
    if(!user)return; setLoading(true); setLoadError(null);
    const accountId = getActiveAccountId();
    if (!accountId) { setTrades([]); setLoading(false); return; }
    const {data,error}=await supabase.from('trades').select('*').eq('user_id',user.id).eq('account_id', accountId).order('trade_date',{ascending:true}).order('entry_time',{ascending:true});
    if(error){ setTrades([]); setLoadError(`${error.message}${error.code?` · کد ${error.code}`:''}`); setLoading(false); return; }
    setTrades(data||[]);setLoading(false);
  },[user]);
  useEffect(()=>{
    load();
    const onAccountChanged = () => load();
    window.addEventListener('trading-os-active-account-changed', onAccountChanged);
    return () => window.removeEventListener('trading-os-active-account-changed', onAccountChanged);
  },[load]);
  const report=useMemo(()=>{
    try {
      return buildPeriodReport(Array.isArray(trades) ? trades : [], range);
    } catch (e) {
      console.error('Trading OS reports build failed:', e);
      return buildPeriodReport([], range);
    }
  },[trades,range]);
  const go=(dir:number)=>setRange(r=>shiftPeriod(r,dir));
  const today=()=>setRange(periodRange(period));
  const changePeriod=(p:ReportPeriod)=>{setPeriod(p);setRange(periodRange(p));};

  const exportJson=()=>{
    const payload=JSON.stringify({generatedAt:new Date().toISOString(),period:faPeriod[period],range,summary:report},null,2);
    const blob=new Blob([payload],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`trading-os-report-${period}-${range.from}.json`;a.click();URL.revokeObjectURL(url);
  };

  return <div className="page-container space-y-5" dir="rtl">
    <div className="flex items-center justify-between gap-3 flex-wrap">
      <div><div className="flex items-center gap-2"><div className="p-2 rounded-xl bg-gold-500/10 text-gold-400"><BarChart3 className="w-5 h-5"/></div><h1 className="text-xl font-bold text-white">مرکز گزارش‌های عملکرد</h1></div><p className="text-sm text-dark-400 mt-1">گزارش روزانه، هفتگی و ماهانه؛ کاملاً Rule-Based و بدون وابستگی به AI</p></div>
      <div className="flex gap-2"><button onClick={exportJson} className="btn-secondary"><Download className="w-4 h-4"/>خروجی گزارش</button><button onClick={load} className="btn-secondary p-2"><RefreshCw className="w-4 h-4"/></button></div>
    </div>

    <div className="glass-card p-2 flex items-center justify-between gap-2 flex-wrap">
      <div className="flex gap-1">{(['day','week','month'] as ReportPeriod[]).map(p=><button key={p} onClick={()=>changePeriod(p)} className={`px-4 py-2 rounded-lg text-sm ${period===p?'bg-gold-500/15 text-gold-300 border border-gold-500/20':'text-dark-400 hover:text-white'}`}>{faPeriod[p]}</button>)}</div>
      <div className="flex items-center gap-1"><button onClick={()=>go(-1)} className="p-2 rounded-lg hover:bg-white/5"><ChevronRight className="w-4 h-4"/></button><div className="min-w-[180px] text-center text-sm text-white"><CalendarDays className="w-4 h-4 inline ml-1 text-gold-400"/>{toPersianDate(range.from)} تا {toPersianDate(range.to)}</div><button onClick={()=>go(1)} className="p-2 rounded-lg hover:bg-white/5"><ChevronLeft className="w-4 h-4"/></button><button onClick={today} className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-dark-300 hover:text-white">امروز</button></div>
    </div>

    {loadError ? <div className="glass-card p-6 border border-danger-500/20 bg-danger-500/[0.04]"><div className="flex items-start gap-3"><ShieldAlert className="w-5 h-5 text-danger-400 shrink-0"/><div><p className="font-semibold text-danger-300">گزارش‌ها در دسترس نیستند</p><p className="text-xs text-dark-400 mt-1">{loadError}</p><button onClick={load} className="btn-secondary text-xs mt-3">تلاش مجدد</button></div></div></div> : loading?<div className="glass-card p-10 text-center text-dark-400">در حال ساخت گزارش...</div>:<>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Metric label="خالص عملکرد" value={formatCurrency(report.pnl)} positive={report.pnl>0} sub={`${report.trades.length} معامله بسته‌شده`}/>
        <Metric label="Win Rate" value={`${report.winRate.toFixed(1)}٪`} positive={report.winRate>=50}/>
        <Metric label="Expectancy" value={formatCurrency(report.expectancy)} positive={report.expectancy>0} sub="میانگین نتیجه هر معامله"/>
        <Metric label="میانگین R" value={`${fmt(report.avgR)}R`} positive={report.avgR>0}/>
        <Metric label="Profit Factor" value={Number.isFinite(report.profitFactor)?report.profitFactor.toFixed(2):'∞'} positive={report.profitFactor>=1}/>
        <Metric label="Process Score" value={report.trades.length && report.processCoverage>0?`${report.processScore.toFixed(0)}/100`:'—'} positive={report.processScore>=80}/>
        <Metric label="Max Drawdown" value={formatCurrency(-report.maxDD)} positive={false} sub="در محدوده گزارش"/>
        <Metric label="Review Discipline" value={report.trades.length?`${Math.round(report.reviewed/report.trades.length*100)}٪`:'—'} positive={report.trades.length?report.reviewed/report.trades.length>=.8:false}/>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 glass-card p-5"><div className="flex justify-between items-center mb-4"><div><h2 className="font-bold text-white">منحنی عملکرد دوره</h2><p className="text-xs text-dark-500">تغییر تجمعی P&L</p></div><Gauge className="w-5 h-5 text-gold-400"/></div><div className="h-64">{report.equityCurve.length?<ResponsiveContainer width="100%" height="100%"><LineChart data={report.equityCurve}><CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,.06)"/><XAxis dataKey="date" hide/><YAxis hide/><Tooltip formatter={(v:any)=>formatCurrency(Number(v))}/><Line type="monotone" dataKey="equity" stroke="#d4a84f" strokeWidth={2} dot={false}/></LineChart></ResponsiveContainer>:<Empty/>}</div></div>
        <div className="glass-card p-5"><h2 className="font-bold text-white mb-3">خلاصه اجرایی</h2><div className="space-y-3"><Row icon={report.pnl>=0?<TrendingUp/>:<TrendingDown/>} text={report.pnl>=0?'دوره با سود بسته شده است.':'دوره با زیان بسته شده است.'} tone={report.pnl>=0?'good':'bad'}/><Row icon={<Target/>} text={`رشته برد: ${report.bestWinStreak} · رشته باخت: ${report.bestLossStreak}`} /><Row icon={<ShieldAlert/>} text={`ریسک ثبت‌شده: ${report.riskSum.toFixed(2)}٪`} /><Row icon={<CheckCircle2/>} text={`مرور کامل: ${report.reviewed} از ${report.trades.length}`} /></div></div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <GroupCard title="عملکرد بر اساس سشن" rows={report.sessions}/><GroupCard title="عملکرد بر اساس ستاپ" rows={report.setups}/>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="glass-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div><h2 className="font-bold text-white">روند روزانه</h2><p className="text-xs text-dark-500">P&amp;L، R و کیفیت فرآیند در طول بازه</p></div>
            <TrendingUp className="w-5 h-5 text-gold-400"/>
          </div>
          <div className="h-60">{report.dailySeries.length ? <ResponsiveContainer width="100%" height="100%"><AreaChart data={report.dailySeries}><defs><linearGradient id="pnlFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#d4a84f" stopOpacity={.28}/><stop offset="100%" stopColor="#d4a84f" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,.05)"/><XAxis dataKey="date" hide/><YAxis hide/><Tooltip/><Area type="monotone" dataKey="pnl" stroke="#d4a84f" fill="url(#pnlFill)" strokeWidth={2}/><Line type="monotone" dataKey="avgProcess" stroke="#7dd3fc" strokeWidth={2} dot={false}/></AreaChart></ResponsiveContainer> : <Empty/>}</div>
        </div>
        <div className="glass-card p-5">
          <h2 className="font-bold text-white mb-1">تشخیص دوره</h2>
          <p className="text-xs text-dark-500 mb-4">سه محور مستقل؛ عددها تشخیص آماری هستند، نه حکم قطعی.</p>
          <ScoreBar label="استراتژی" value={report.strategyScore}/>
          <ScoreBar label="اجرا" value={report.executionScore}/>
          <ScoreBar label="روانشناسی" value={report.psychologyScore}/>
          <div className="mt-4 p-3 rounded-xl border border-gold-500/20 bg-gold-500/5"><p className="text-[11px] text-gold-400">محور نیازمند توجه</p><p className="text-base font-bold text-white mt-1">{report.primaryAxis}</p></div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="glass-card p-5"><p className="text-xs text-dark-500">بهترین Edge قابل اتکا</p>{report.bestEdge ? <><p className="text-xl font-bold text-success-400 mt-2">{report.bestEdge.key}</p><p className="text-xs text-dark-400 mt-1">{report.bestEdge.trades} معامله · {report.bestEdge.avgR.toFixed(2)}R میانگین · {report.bestEdge.winRate.toFixed(0)}٪ برد</p><span className="inline-flex mt-3 px-2 py-1 rounded-lg bg-success-500/10 text-success-300 text-[11px]">نمونه حداقل ۵ معامله</span></> : <p className="text-sm text-dark-400 mt-3">برای اعلام Edge هنوز نمونه کافی نداریم.</p>}</div>
        <div className="glass-card p-5"><p className="text-xs text-dark-500">ضعیف‌ترین Edge قابل مشاهده</p>{report.worstEdge ? <><p className="text-xl font-bold text-danger-400 mt-2">{report.worstEdge.key}</p><p className="text-xs text-dark-400 mt-1">{report.worstEdge.trades} معامله · {report.worstEdge.avgR.toFixed(2)}R میانگین · {report.worstEdge.winRate.toFixed(0)}٪ برد</p><span className="inline-flex mt-3 px-2 py-1 rounded-lg bg-danger-500/10 text-danger-300 text-[11px]">نیازمند بررسی، نه حذف فوری</span></> : <p className="text-sm text-dark-400 mt-3">نمونه کافی برای مقایسه نداریم.</p>}</div>
      </div>

      <div className="glass-card p-5">
        <div className="flex items-center justify-between gap-3 flex-wrap"><div><h2 className="font-bold text-white">پوشش و کیفیت داده</h2><p className="text-xs text-dark-500">قبل از اعتماد به گزارش، کیفیت ثبت معامله را ببین.</p></div><div className="flex gap-2"><MiniStat label="Review" value={`${Math.round(report.reviewCoverage*100)}٪`}/><MiniStat label="Process Score" value={`${Math.round(report.processCoverage*100)}٪`}/></div></div>
        <div className="mt-4 h-2 rounded-full bg-white/5 overflow-hidden"><div className="h-full bg-gold-500 rounded-full" style={{width:`${Math.round(Math.min(1,(report.reviewCoverage+report.processCoverage)/2)*100)}%`}}/></div>
      </div>

      <div className="glass-card p-5"><div className="flex items-center gap-2 mb-4"><Sparkles className="w-5 h-5 text-gold-400"/><div><h2 className="font-bold text-white">اقدامات پیشنهادی برای دوره بعد</h2><p className="text-xs text-dark-500">این پیشنهادها از قوانین آماری سیستم تولید شده‌اند؛ نه از AI.</p></div></div><div className="grid md:grid-cols-2 gap-3">{report.actions.slice(0,6).map((a,i)=><div key={i} className="p-3 rounded-xl bg-white/[.03] border border-white/5 text-sm text-dark-200 flex gap-2"><CircleAlert className="w-4 h-4 text-gold-400 shrink-0 mt-0.5"/>{a}</div>)}{!report.actions.length&&<div className="text-sm text-dark-400">داده کافی برای هشدار یا اقدام اصلاحی وجود ندارد؛ همین انضباط را حفظ کن.</div>}</div></div>

      <div className="glass-card p-5"><h2 className="font-bold text-white mb-4">چه چیزی بیشترین اثر را داشت؟</h2><div className="grid md:grid-cols-4 gap-3">{report.highlights.map(h=><div key={h.label} className="rounded-xl border border-white/5 bg-white/[.02] p-4"><p className="text-xs text-dark-500">{h.label}</p><p className="text-base font-semibold text-gold-300 mt-2 truncate">{h.value}</p><p className="text-xs text-dark-400 mt-1">{h.detail}</p></div>)}</div></div>
    </>}
  </div>
}

function Row({icon,text,tone}:{icon:ReactNode;text:string;tone?:'good'|'bad'}){return <div className="flex items-center gap-2 text-sm text-dark-300"><span className={`w-4 h-4 shrink-0 flex items-center justify-center ${tone==='good'?'text-success-400':tone==='bad'?'text-danger-400':'text-gold-400'}`}>{icon}</span><span>{text}</span></div>}
function ScoreBar({label,value}:{label:string;value:number}){return <div className="mb-4"><div className="flex justify-between text-xs mb-1"><span className="text-dark-300">{label}</span><span className="text-white font-semibold">{Math.round(value)}</span></div><div className="h-2 rounded-full bg-white/5 overflow-hidden"><div className="h-full rounded-full bg-gold-500" style={{width:`${Math.max(0,Math.min(100,value))}%`}}/></div></div>}
function MiniStat({label,value}:{label:string;value:string}){return <div className="px-3 py-2 rounded-xl bg-white/[.03] border border-white/5"><p className="text-[10px] text-dark-500">{label}</p><p className="text-sm text-white font-semibold mt-0.5">{value}</p></div>}
function Empty(){return <div className="h-full flex items-center justify-center text-sm text-dark-500">داده‌ای برای نمایش وجود ندارد.</div>}
function GroupCard({title,rows}:{title:string;rows:Array<{key:string;trades:number;pnl:number;winRate:number;avgR:number}>}){return <div className="glass-card p-5"><h2 className="font-bold text-white mb-4">{title}</h2>{rows.length?<div className="space-y-2">{rows.slice(0,6).map(r=><div key={r.key} className="grid grid-cols-[1fr_auto_auto] gap-3 items-center p-3 rounded-xl bg-white/[.02]"><div><p className="text-sm text-white truncate">{r.key}</p><p className="text-xs text-dark-500">{r.trades} معامله · Win Rate {r.winRate.toFixed(0)}٪</p></div><span className="text-xs text-dark-400">{r.avgR.toFixed(2)}R</span><span className={`text-sm font-semibold ${r.pnl>=0?'text-success-400':'text-danger-400'}`}>{formatCurrency(r.pnl)}</span></div>)}</div>:<Empty/>}</div>}