import { useEffect, useState, useCallback } from 'react';
import { ShieldCheck, ShieldAlert, ShieldX } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { toGregorianDateInput } from '@/lib/utils';
import { evaluateRiskStatus, RISK_STATUS_LABEL, type RiskStatus } from '@/lib/riskEngine';

const ICONS: Record<RiskStatus, any> = { ready: ShieldCheck, caution: ShieldAlert, locked: ShieldX };
const STYLES: Record<RiskStatus, string> = {
  ready: 'bg-success-500/10 text-success-400 border-success-500/25',
  caution: 'bg-gold-500/10 text-gold-400 border-gold-500/25',
  locked: 'bg-danger-500/10 text-danger-400 border-danger-500/25',
};

export default function TradingStatusBadge() {
  const { user } = useAuth();
  const [status, setStatus] = useState<RiskStatus | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    const today = toGregorianDateInput(new Date());

    const [{ data: account }, { data: riskSettings }, { data: todayTrades }, { data: recentTrades }] = await Promise.all([
      supabase.from('accounts').select('current_balance').eq('user_id', user.id).eq('id', getActiveAccountId()).maybeSingle(),
      supabase.from('risk_settings').select('*').eq('user_id', user.id).eq('account_id', getActiveAccountId()).eq('is_active', true).maybeSingle(),
      supabase.from('trades').select('pnl_amount').eq('user_id', user.id).eq('account_id', getActiveAccountId()).eq('trade_date', today),
      supabase.from('trades').select('result').eq('user_id', user.id).eq('account_id', getActiveAccountId()).not('result', 'eq', 'open').order('trade_date', { ascending: false }).order('created_at', { ascending: false }).limit(10),
    ]);

    const balance = account?.current_balance || 0;
    const todayPnl = (todayTrades || []).reduce((s, t) => s + (Number(t.pnl_amount) || 0), 0);
    const todayPnlPercent = balance > 0 ? (todayPnl / balance) * 100 : 0;

    let consecutiveLosses = 0;
    for (const t of recentTrades || []) {
      if (t.result === 'loss') consecutiveLosses += 1;
      else break;
    }

    const result = evaluateRiskStatus({
      isActive: riskSettings?.is_active ?? false,
      todayPnlPercent,
      dailyMaxLossPercent: riskSettings?.daily_max_loss || 0,
      dailyProfitTargetPercent: riskSettings?.daily_profit_target || 0,
      tradesToday: (todayTrades || []).length,
      maxTradesPerDay: riskSettings?.max_trades_per_day || 0,
      consecutiveLosses,
      maxConsecutiveLosses: riskSettings?.max_consecutive_losses || 0,
    });
    setStatus(result.status);
  }, [user]);

  useEffect(() => {
    load();
    const onAccountChanged = () => load();
    window.addEventListener('trading-os-active-account-changed', onAccountChanged);
    return () => window.removeEventListener('trading-os-active-account-changed', onAccountChanged);
  }, [load]);

  if (!status) return null;
  const Icon = ICONS[status];

  return (
    <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold flex-shrink-0 ${STYLES[status]}`}>
      <Icon className="w-3.5 h-3.5" />
      {RISK_STATUS_LABEL[status]}
    </div>
  );
}