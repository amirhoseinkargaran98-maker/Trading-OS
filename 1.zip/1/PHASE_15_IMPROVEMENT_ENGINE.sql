-- PHASE 15 — Improvement Engine / Action Tracking
-- Run after COMPLETE_DATABASE_SETUP.sql. No fake data is inserted.

CREATE TABLE IF NOT EXISTS improvement_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  reason text,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  target_trades integer NOT NULL DEFAULT 10 CHECK (target_trades > 0),
  current_progress integer NOT NULL DEFAULT 0 CHECK (current_progress >= 0),
  success_criteria text,
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','COMPLETED','FAILED','PAUSED')),
  result text CHECK (result IS NULL OR result IN ('IMPROVED','NOT_IMPROVED','INCONCLUSIVE')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT improvement_progress_not_over_target CHECK (current_progress <= target_trades)
);

CREATE INDEX IF NOT EXISTS improvement_actions_user_status_idx ON improvement_actions(user_id, status);
CREATE INDEX IF NOT EXISTS improvement_actions_user_created_idx ON improvement_actions(user_id, created_at DESC);

ALTER TABLE improvement_actions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_improvement_actions" ON improvement_actions;
CREATE POLICY "select_own_improvement_actions" ON improvement_actions FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_improvement_actions" ON improvement_actions;
CREATE POLICY "insert_own_improvement_actions" ON improvement_actions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_improvement_actions" ON improvement_actions;
CREATE POLICY "update_own_improvement_actions" ON improvement_actions FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_improvement_actions" ON improvement_actions;
CREATE POLICY "delete_own_improvement_actions" ON improvement_actions FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION set_improvement_actions_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
DROP TRIGGER IF EXISTS improvement_actions_updated_at ON improvement_actions;
CREATE TRIGGER improvement_actions_updated_at BEFORE UPDATE ON improvement_actions FOR EACH ROW EXECUTE FUNCTION set_improvement_actions_updated_at();
