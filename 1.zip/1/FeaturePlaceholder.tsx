import { ArrowRight, Construction } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

type FeaturePlaceholderProps = { title: string; description: string };

export default function FeaturePlaceholder({ title, description }: FeaturePlaceholderProps) {
  const navigate = useNavigate();

  return (
    <div className="page-container flex items-center justify-center min-h-full" dir="rtl">
      <div className="max-w-md text-center rounded-2xl border border-white/10 bg-dark-900/70 p-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gold-500/10 text-gold-400">
          <Construction className="h-7 w-7" />
        </div>
        <h1 className="text-xl font-bold text-white mb-2">{title}</h1>
        <p className="text-sm leading-7 text-dark-400 mb-6">{description}</p>
        <button type="button" onClick={() => navigate('/')} className="btn-secondary mx-auto">
          <ArrowRight className="w-4 h-4" /> بازگشت به داشبورد
        </button>
      </div>
    </div>
  );
}
