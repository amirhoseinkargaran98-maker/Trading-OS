import { useEffect, useState } from 'react';
import { Clock3, Zap, X, Check, ChevronLeft, ChevronRight } from 'lucide-react';

type Props = { value?: string; onChange: (value: string) => void; onBlur?: () => void; placeholder?: string };
function parseHM(value?: string): { h:number; m:number } | null { if(!value) return null; const x=value.match(/^(\d{1,2}):(\d{2})$/); if(!x) return null; const h=Number(x[1]),m=Number(x[2]); return h<24&&m<60?{h,m}:null; }
const pad=(n:number)=>String(n).padStart(2,'0');

export default function TimeScrollPicker({value,onChange,onBlur,placeholder}:Props){
 const parsed=parseHM(value); const now=new Date();
 const [open,setOpen]=useState(false); const [draft,setDraft]=useState(parsed||{h:now.getHours(),m:now.getMinutes()}); const [step,setStep]=useState<'hour'|'minute'>('hour');
 const text=parsed?`${pad(parsed.h)}:${pad(parsed.m)}`:'';
 useEffect(()=>{if(open){const d=parseHM(value)||{h:new Date().getHours(),m:new Date().getMinutes()};setDraft(d);setStep('hour');}},[open,value]);
 const close=()=>{setOpen(false);onBlur?.()};
 const confirm=()=>{onChange(`${pad(draft.h)}:${pad(draft.m)}`);close()};
 const setNow=()=>{const d=new Date(); const n={h:d.getHours(),m:d.getMinutes()};setDraft(n);onChange(`${pad(n.h)}:${pad(n.m)}`);close()};
 const chooseHour=(h:number)=>{setDraft(d=>({...d,h}));setStep('minute')};
 const chooseMinute=(m:number)=>setDraft(d=>({...d,m}));
 const minuteChoices=Array.from({length:60},(_,i)=>i);
 return <div className="relative">
  <button type="button" onClick={()=>setOpen(true)} className="input-field w-full flex items-center justify-between gap-2">
   <span className={text?'text-white number-ltr':'text-dark-500'}>{text||placeholder||'انتخاب ساعت'}</span><Clock3 className="w-4 h-4 text-gold-400 flex-shrink-0"/>
  </button>
  {open&&<div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 sm:p-6" dir="rtl">
   <button type="button" aria-label="بستن انتخاب زمان" onClick={close} className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
   <div className="relative z-10 w-full max-w-[390px] max-h-[calc(100vh-2rem)] overflow-y-auto rounded-3xl border border-white/10 bg-dark-900/98 shadow-2xl shadow-black/60 p-3 sm:p-4 animate-in fade-in zoom-in-95 duration-150">
   <div className="flex items-center justify-between mb-3"><div><h3 className="text-sm font-bold text-white">انتخاب زمان</h3><p className="text-[10px] text-dark-500 mt-0.5">فرمت ۲۴ ساعته • دقیق تا دقیقه</p></div><button type="button" onClick={close} className="p-1.5 rounded-lg text-dark-400 hover:text-white hover:bg-white/5"><X className="w-4 h-4"/></button></div>
   <div className="rounded-xl border border-gold-500/20 bg-gradient-to-br from-gold-500/10 to-transparent p-3 mb-3">
    <div className="flex items-center justify-between gap-3"><div className="text-3xl font-black text-white number-ltr tracking-tight">{pad(draft.h)}:{pad(draft.m)}</div><div className="text-[10px] text-gold-300">{step==='hour'?'ساعت را انتخاب کنید':'دقیقه را انتخاب کنید'}</div></div>
   </div>
   <div className="flex items-center gap-1 mb-2"><button type="button" onClick={()=>setStep('hour')} className={`flex-1 rounded-lg py-1.5 text-[11px] ${step==='hour'?'bg-gold-500/15 text-gold-300 border border-gold-500/25':'bg-white/5 text-dark-400'}`}>ساعت</button><button type="button" onClick={()=>setStep('minute')} className={`flex-1 rounded-lg py-1.5 text-[11px] ${step==='minute'?'bg-gold-500/15 text-gold-300 border border-gold-500/25':'bg-white/5 text-dark-400'}`}>دقیقه</button></div>
   {step==='hour'?<div className="grid grid-cols-6 gap-1.5 max-h-52 overflow-y-auto pr-0.5">{Array.from({length:24},(_,h)=><button key={h} type="button" onClick={()=>chooseHour(h)} className={`rounded-lg py-2.5 text-sm number-ltr transition ${draft.h===h?'bg-gold-500 text-dark-950 font-bold shadow-md shadow-gold-500/15':'bg-white/[0.04] text-dark-200 hover:bg-white/10'}`}>{pad(h)}</button>)}</div>:<>
    <div className="grid grid-cols-6 gap-1 mb-2">{[0,5,10,15,20,25,30,35,40,45,50,55].map(m=><button key={m} type="button" onClick={()=>chooseMinute(m)} className={`rounded-md py-1.5 text-[11px] number-ltr ${draft.m===m?'bg-gold-500 text-dark-950 font-bold':'text-dark-300 hover:bg-white/10'}`}>{pad(m)}</button>)}</div>
    <div className="grid grid-cols-10 gap-1 max-h-36 overflow-y-auto pr-0.5">{minuteChoices.map(m=><button key={m} type="button" onClick={()=>chooseMinute(m)} className={`rounded-md py-1.5 text-[10px] number-ltr ${draft.m===m?'bg-gold-500 text-dark-950 font-bold':'text-dark-300 hover:bg-white/10'}`}>{pad(m)}</button>)}</div>
   </>}
   <div className="flex gap-2 mt-3"><button type="button" onClick={setNow} className="flex-1 rounded-lg py-2 text-xs bg-gold-500/10 text-gold-300 border border-gold-500/20 hover:bg-gold-500/15"><Zap className="inline w-3.5 h-3.5 ml-1"/>اکنون</button><button type="button" onClick={confirm} className="flex-[1.5] btn-primary py-2 text-xs"><Check className="inline w-3.5 h-3.5 ml-1"/>تأیید</button></div>
  </div></div>}
 </div>;
}
