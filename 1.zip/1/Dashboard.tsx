import { useEffect, useState, useCallback } from 'react';
import {
  TrendingUp, TrendingDown, DollarSign, Target, Activity,
  BarChart2, Award, AlertTriangle, Calendar, Zap, RefreshCw, Gauge, Scale, Brain, Clock3
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell, LineChart, Line, PieChart, Pie,
  RadialBarChart, RadialBar, PolarAngleAxis
} from 'recharts';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { getActiveAccountId, setActiveAccountId } from '@/lib/activeAccount';
import BehaviorAlerts from '@/components/BehaviorAlerts';
import CoachCard from '@/components/ai/CoachCard';
import TradingStatusBadge from '@/components/TradingStatusBadge';
import { calculatePerformanceProfile, monthlyPerformance, streakInfo } from '@/lib/performanceAnalytics';
import {
  calculateWinRate, calculateProfitFactor, calculateAveragePlannedRR, calculateEquityCurve,
} from '@/lib/tradingEngine';
import {
  formatCurrency, formatPercent, toPersianDate, getPersianDayName,
  getSessionLabel, getDayName, toGregorianDateInput, addCalendarDays, parseDateOnly, getDayOfWeekFromDateInput
} from '@/lib/utils';

type Stats = {
  currentCapital: number;
  initialCapital: number;
  todayPnl: number;
  weekPnl: number;
  monthPnl: number;
  totalPnl: number;
  winRate: number;
  profitFactor: number;
  avgRR: number;
  maxDrawdown: number;
  totalTrades: number;
  openTrades: number;
  wins: number;
  losses: number;
};

type EquityPoint = { date: string; equity: number; pnl: number };
type DayPerf = { day: string; pnl: number; trades: number; winRate: number };
type SessionPerf = { session: string; pnl: number; wins: number; losses: number; winRate: number };
type SymbolPerf = { symbol: string; pnl: number; trades: number; winRate: number };

function initialCapitalForMetrics(v: number | null | undefined) { return v ?? 0; }

const STAT_SKELETON = Array(6).fill(null);

function KpiCard({ title, value, subtitle, icon: Icon, color = 'gold', trend }: {
  title: string;
  value: string;
  subtitle?: string;
  icon: React.ElementType;
  color?: 'gold' | 'green' | 'red' | 'blue';
  trend?: 'up' | 'down' | 'neutral';
}) {
  const colorMap = {
    gold: 'text-gold-400 bg-gold-500/10',
    green: 'text-success-400 bg-success-500/10',
    red: 'text-danger-400 bg-danger-500/10',
    blue: 'text-blue-400 bg-blue-500/10',
  };

  return (
    <div className="kpi-card glass-card-hover">
      <div className="flex items-start justify-between">
        <p className="text-xs font-medium text-dark-400">{title}</p>
        <div className={`p-1.5 rounded-lg ${colorMap[color]}`}>
          <Icon className="w-3.5 h-3.5" />
        </div>
      </div>
      <p className={`text-xl font-bold mt-1 number-ltr ${
        trend === 'up' ? 'text-success-400' :
        trend === 'down' ? 'text-danger-400' : 'text-white'
      }`}>
        {value}
      </p>
      {subtitle && <p className="text-xs text-dark-500 mt-0.5">{subtitle}</p>}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const v = payload[0].value;
    return (
      <div className="glass-card p-2.5 text-xs min-w-[120px]">
        <p className="text-dark-400 mb-1">{label}</p>
        <p className={v >= 0 ? 'text-success-400 font-semibold' : 'text-danger-400 font-semibold'}>
          {formatCurrency(v)}
        </p>
      </div>
    );
  }
  return null;
};

export default function Dashboard() {
  const { user, profile } = useAuth();
  const [stats, setStats] = useState<Stats | null>(null);
  const [equity, setEquity] = useState<EquityPoint[]>([]);
  const [dayPerf, setDayPerf] = useState<DayPerf[]>([]);
  const [sessionPerf, setSessionPerf] = useState<SessionPerf[]>([]);
  const [symbolPerf, setSymbolPerf] = useState<SymbolPerf[]>([]);
  const [bestTrades, setBestTrades] = useState<any[]>([]);
  const [worstTrades, setWorstTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [profileMetrics, setProfileMetrics] = useState<any | null>(null);
  const [monthlyPerf, setMonthlyPerf] = useState<any[]>([]);
  const [streaks, setStreaks] = useState({bestWinStreak:0,bestLossStreak:0});
  const [accounts, setAccounts] = useState<{id:string;name:string;broker:string|null;initial_balance:number;current_balance:number}[]>([]);
  const [activeAccountId, setActiveAccountIdState] = useState<string | null>(() => getActiveAccountId());

  const loadData = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    const { data: accountRows } = await supabase
      .from('accounts')
      .select('id,name,broker,initial_balance,current_balance')
      .eq('user_id', user.id)
      .eq('is_active', true)
      .order('created_at', { ascending: true });

    const availableAccounts = accountRows || [];
    setAccounts(availableAccounts);

    let selectedId = activeAccountId;
    if (!selectedId || !availableAccounts.some(a => a.id === selectedId)) {
      selectedId = availableAccounts[0]?.id || null;
      if (selectedId) {
        setActiveAccountId(selectedId);
        setActiveAccountIdState(selectedId);
      }
    }

    let tradeQuery = supabase
      .from('trades')
      .select('*')
      .eq('user_id', user.id);
    if (selectedId) tradeQuery = tradeQuery.eq('account_id', selectedId);
    const { data: trades } = await tradeQuery
      .not('result', 'eq', 'open')
      .order('trade_date', { ascending: true })
      .order('entry_time', { ascending: true });

    if (!trades) { setLoading(false); return; }

    const now = new Date();
    const today = toGregorianDateInput(now);
    const weekStart = toGregorianDateInput(addCalendarDays(now, -now.getDay()));
    const monthStart = toGregorianDateInput(new Date(now.getFullYear(), now.getMonth(), 1));

    const closed = trades.filter(t => t.pnl_amount !== null);
    setProfileMetrics(calculatePerformanceProfile(closed, initialCapitalForMetrics(profile?.initial_capital)));
    setMonthlyPerf(monthlyPerformance(closed));
    setStreaks(streakInfo(closed));
    const totalTrades = closed.length;
    const wins = closed.filter(t => t.result === 'win').length;
    const losses = closed.filter(t => t.result === 'loss').length;
    const winRate = calculateWinRate(closed);

    const totalPnl = closed.reduce((sum, t) => sum + (t.pnl_amount || 0), 0);
    const todayPnl = closed.filter(t => t.trade_date === today).reduce((sum, t) => sum + (t.pnl_amount || 0), 0);
    const weekPnl = closed.filter(t => t.trade_date >= weekStart).reduce((sum, t) => sum + (t.pnl_amount || 0), 0);
    const monthPnl = closed.filter(t => t.trade_date >= monthStart).reduce((sum, t) => sum + (t.pnl_amount || 0), 0);

    const profitFactor = calculateProfitFactor(closed);
    const avgRR = calculateAveragePlannedRR(closed);

    // Drawdown — single definition, shared with Monthly Report
    const selectedAccount = availableAccounts.find(a => a.id === selectedId);
    const initialCap = selectedAccount?.initial_balance ?? profile?.initial_capital ?? 0;
    const { maxDrawdownPercent: maxDD } = calculateEquityCurve(closed, initialCap);

    setStats({
      currentCapital: selectedAccount?.current_balance ?? (initialCap + totalPnl),
      initialCapital: initialCap,
      todayPnl, weekPnl, monthPnl, totalPnl,
      winRate, profitFactor, avgRR, maxDrawdown: maxDD,
      totalTrades,
      openTrades: trades.filter(t => t.result === 'open').length,
      wins, losses,
    });

    // Equity curve
    const equityData: EquityPoint[] = [];
    let cap = initialCap;
    for (const t of closed) {
      cap += t.pnl_amount || 0;
      equityData.push({
        date: toPersianDate(t.trade_date),
        equity: Math.round(cap * 100) / 100,
        pnl: t.pnl_amount || 0,
      });
    }
    setEquity(equityData.slice(-60));

    // Day performance
    const dayMap: Record<number, { pnl: number; wins: number; total: number }> = {};
    for (const t of closed) {
      const day = getDayOfWeekFromDateInput(t.trade_date);
      if (day === null) continue;
      if (!dayMap[day]) dayMap[day] = { pnl: 0, wins: 0, total: 0 };
      dayMap[day].pnl += t.pnl_amount || 0;
      dayMap[day].total++;
      if (t.result === 'win') dayMap[day].wins++;
    }
    setDayPerf(
      [0,1,2,3,4].map(d => ({
        day: getDayName(d),
        pnl: dayMap[d]?.pnl || 0,
        trades: dayMap[d]?.total || 0,
        winRate: dayMap[d]?.total ? (dayMap[d].wins / dayMap[d].total) * 100 : 0,
      }))
    );

    // Session performance
    const sessions = ['london', 'new_york', 'asian', 'sydney'];
    setSessionPerf(sessions.map(s => {
      const st = closed.filter(t => t.session === s);
      const sw = st.filter(t => t.result === 'win').length;
      return {
        session: getSessionLabel(s),
        pnl: st.reduce((sum, t) => sum + (t.pnl_amount || 0), 0),
        wins: sw, losses: st.length - sw,
        winRate: st.length > 0 ? (sw / st.length) * 100 : 0,
      };
    }));

    // Symbol performance
    const symMap: Record<string, { pnl: number; wins: number; total: number }> = {};
    for (const t of closed) {
      if (!symMap[t.symbol]) symMap[t.symbol] = { pnl: 0, wins: 0, total: 0 };
      symMap[t.symbol].pnl += t.pnl_amount || 0;
      symMap[t.symbol].total++;
      if (t.result === 'win') symMap[t.symbol].wins++;
    }
    setSymbolPerf(
      Object.entries(symMap)
        .map(([sym, v]) => ({
          symbol: sym,
          pnl: v.pnl,
          trades: v.total,
          winRate: v.total > 0 ? (v.wins / v.total) * 100 : 0,
        }))
        .sort((a, b) => b.pnl - a.pnl)
        .slice(0, 8)
    );

    // Best/Worst trades
    const sorted = [...closed].sort((a, b) => (b.pnl_amount || 0) - (a.pnl_amount || 0));
    setBestTrades(sorted.slice(0, 5));
    setWorstTrades(sorted.slice(-5).reverse());

    setLoading(false);
  }, [user, profile, activeAccountId]);

  useEffect(() => { loadData(); }, [loadData]);

  const pnlTrend = (v: number) => v > 0 ? 'up' : v < 0 ? 'down' : 'neutral';

  return (
    <div className="page-container" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-end mb-3">
        <div className="flex items-center gap-2 rounded-xl border border-gold-500/20 bg-gold-500/[.05] px-3 py-2">
          <span className="text-xs text-dark-400">حساب اصلی تحلیل</span>
          <select
            value={activeAccountId || ''}
            onChange={(e) => {
              const id = e.target.value || null;
              if (!id) return;
              setActiveAccountId(id);
              setActiveAccountIdState(id);
            }}
            className="bg-transparent text-sm text-white outline-none min-w-[180px]"
          >
            {accounts.map(a => <option key={a.id} value={a.id} className="bg-dark-900">{a.name}{a.broker ? ` — ${a.broker}` : ''}</option>)}
          </select>
        </div>
      </div>

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-white">
            سلام، {profile?.display_name || 'تریدر'} 👋
          </h1>
          <p className="text-sm text-dark-400 mt-0.5">{toPersianDate(new Date())} — {getPersianDayName(new Date())}</p>
        </div>
        <div className="flex items-center gap-2">
          <TradingStatusBadge />
          <button
            onClick={loadData}
            className="btn-secondary p-2 !px-2"
            title="به‌روزرسانی"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Behavioral Alerts */}
      <BehaviorAlerts />

      {/* AI Coach Card */}
      <CoachCard />

      {/* Win/Loss donut + Capital gauge */}
      {!loading && stats && stats.totalTrades > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="glass-card p-4 flex items-center gap-4">
            <div className="relative flex-shrink-0" style={{ width: 130, height: 130 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[{ name: 'برد', value: stats.wins }, { name: 'باخت', value: stats.losses }]}
                    dataKey="value"
                    innerRadius={42}
                    outerRadius={62}
                    startAngle={90}
                    endAngle={-270}
                    paddingAngle={2}
                    stroke="none"
                  >
                    <Cell fill="#22c55e" />
                    <Cell fill="#ef4444" />
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold text-white number-ltr">{stats.winRate.toFixed(0)}%</span>
                <span className="text-[10px] text-dark-400">وین‌ریت</span>
              </div>
            </div>
            <div className="flex-1 space-y-2">
              <h2 className="section-title mb-2"><Target className="w-4 h-4 text-gold-400" />توزیع سود و ضرر</h2>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 text-dark-300"><span className="w-2.5 h-2.5 rounded-full bg-success-500" /> برد</span>
                <span className="text-success-400 font-semibold number-ltr">{stats.wins} معامله</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 text-dark-300"><span className="w-2.5 h-2.5 rounded-full bg-danger-500" /> باخت</span>
                <span className="text-danger-400 font-semibold number-ltr">{stats.losses} معامله</span>
              </div>
              <div className="flex items-center justify-between text-sm pt-1 border-t border-white/5">
                <span className="text-dark-400">مجموع</span>
                <span className="text-white font-semibold number-ltr">{stats.totalTrades} معامله</span>
              </div>
            </div>
          </div>

          <div className="glass-card p-4 flex items-center gap-4">
            <div className="relative flex-shrink-0" style={{ width: 130, height: 130 }}>
              <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart
                  data={[{ value: Math.min(100, Math.max(0, ((stats.currentCapital - stats.initialCapital) / stats.initialCapital) * 100 + 50)) }]}
                  innerRadius={52} outerRadius={62} startAngle={90} endAngle={-270}
                >
                  <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
                  <RadialBar dataKey="value" fill="#f59e0b" cornerRadius={8} background={{ fill: 'rgba(255,255,255,0.05)' }} />
                </RadialBarChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={`text-lg font-bold number-ltr ${stats.currentCapital >= stats.initialCapital ? 'profit-text' : 'loss-text'}`}>
                  {(((stats.currentCapital - stats.initialCapital) / stats.initialCapital) * 100).toFixed(1)}%
                </span>
                <span className="text-[10px] text-dark-400">رشد سرمایه</span>
              </div>
            </div>
            <div className="flex-1 space-y-2">
              <h2 className="section-title mb-2"><DollarSign className="w-4 h-4 text-gold-400" />مدیریت سرمایه</h2>
              <div className="flex items-center justify-between text-sm">
                <span className="text-dark-400">سرمایه اولیه</span>
                <span className="text-white number-ltr">{formatCurrency(stats.initialCapital)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-dark-400">سرمایه فعلی</span>
                <span className="text-white font-semibold number-ltr">{formatCurrency(stats.currentCapital)}</span>
              </div>
              <div className="flex items-center justify-between text-sm pt-1 border-t border-white/5">
                <span className="text-dark-400">حداکثر افت سرمایه</span>
                <span className={`font-semibold number-ltr ${stats.maxDrawdown > 10 ? 'text-danger-400' : 'text-gold-400'}`}>{stats.maxDrawdown.toFixed(2)}%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* KPI Cards */}
      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
          {STAT_SKELETON.map((_, i) => (
            <div key={i} className="kpi-card animate-pulse">
              <div className="h-3 bg-dark-700 rounded w-2/3 mb-2" />
              <div className="h-6 bg-dark-700 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : stats ? (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
            <KpiCard
              title="سرمایه فعلی" icon={DollarSign} color="gold"
              value={`$${stats.currentCapital.toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
              subtitle={`سرمایه اولیه: $${stats.initialCapital.toLocaleString()}`}
            />
            <KpiCard
              title="سود/ضرر امروز" icon={Calendar} color={stats.todayPnl >= 0 ? 'green' : 'red'}
              value={formatCurrency(stats.todayPnl)} trend={pnlTrend(stats.todayPnl)}
            />
            <KpiCard
              title="سود/ضرر این هفته" icon={Activity} color={stats.weekPnl >= 0 ? 'green' : 'red'}
              value={formatCurrency(stats.weekPnl)} trend={pnlTrend(stats.weekPnl)}
            />
            <KpiCard
              title="سود/ضرر این ماه" icon={BarChart2} color={stats.monthPnl >= 0 ? 'green' : 'red'}
              value={formatCurrency(stats.monthPnl)} trend={pnlTrend(stats.monthPnl)}
            />
            <KpiCard
              title="سود/ضرر کل" icon={TrendingUp} color={stats.totalPnl >= 0 ? 'green' : 'red'}
              value={formatCurrency(stats.totalPnl)} trend={pnlTrend(stats.totalPnl)}
              subtitle={formatPercent((stats.totalPnl / stats.initialCapital) * 100)}
            />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
            <KpiCard
              title="Win Rate" icon={Target} color="gold"
              value={`${stats.winRate.toFixed(1)}%`}
              subtitle={`${stats.totalTrades} معامله`}
            />
            <KpiCard
              title="Profit Factor" icon={Zap} color={stats.profitFactor >= 1.5 ? 'green' : stats.profitFactor >= 1 ? 'gold' : 'red'}
              value={stats.profitFactor >= 999 ? '∞' : stats.profitFactor.toFixed(2)}
            />
            <KpiCard
              title="میانگین R:R" icon={Award} color="blue"
              value={`${stats.avgRR.toFixed(2)}R`}
            />
            <KpiCard
              title="Max Drawdown" icon={AlertTriangle} color={stats.maxDrawdown > 10 ? 'red' : 'gold'}
              value={`${stats.maxDrawdown.toFixed(2)}%`}
              trend="down"
            />
            <KpiCard
              title="کل معاملات" icon={BarChart2} color="blue"
              value={stats.totalTrades.toString()}
              subtitle={stats.openTrades > 0 ? `${stats.openTrades} باز` : undefined}
            />
          </div>
        </>
      ) : (
        <div className="glass-card p-8 text-center text-dark-400">
          <TrendingUp className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>هنوز معامله‌ای ثبت نشده است. اولین معامله خود را ثبت کنید.</p>
        </div>
      )}

      {/* Charts row */}
      {equity.length > 0 && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          {/* Equity Curve */}
          <div className="glass-card p-4">
            <h2 className="section-title">
              <TrendingUp className="w-4 h-4 text-gold-400" />
              منحنی سرمایه
            </h2>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={equity}>
                <defs>
                  <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="date" tick={{ fill: '#6c757d', fontSize: 10 }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fill: '#6c757d', fontSize: 10 }} tickLine={false} axisLine={false} tickFormatter={v => `$${(v/1000).toFixed(1)}K`} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="equity" stroke="#f59e0b" strokeWidth={2} fill="url(#eqGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* P&L Bar Chart */}
          <div className="glass-card p-4">
            <h2 className="section-title">
              <BarChart2 className="w-4 h-4 text-gold-400" />
              سود و ضرر — آخرین معاملات
            </h2>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={equity.slice(-20)}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="date" tick={{ fill: '#6c757d', fontSize: 9 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: '#6c757d', fontSize: 10 }} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="pnl" radius={[3, 3, 0, 0]}>
                  {equity.slice(-20).map((entry, index) => (
                    <Cell key={index} fill={entry.pnl >= 0 ? '#22c55e' : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Analysis row */}
      {(sessionPerf.some(s => s.pnl !== 0) || symbolPerf.length > 0 || dayPerf.some(d => d.pnl !== 0)) && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {/* Session Analysis */}
          <div className="glass-card p-4">
            <h2 className="section-title">
              <Activity className="w-4 h-4 text-gold-400" />
              تحلیل سشن
            </h2>
            <div className="space-y-3">
              {sessionPerf.map(s => (
                <div key={s.session} className="flex items-center gap-3">
                  <span className="text-sm text-dark-300 w-20 flex-shrink-0">{s.session}</span>
                  <div className="flex-1 bg-dark-900 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${s.pnl >= 0 ? 'bg-success-500' : 'bg-danger-500'}`}
                      style={{ width: `${Math.min(Math.abs(s.winRate), 100)}%` }}
                    />
                  </div>
                  <span className={`text-xs font-semibold w-16 text-left number-ltr ${s.pnl >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                    {formatCurrency(s.pnl)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Symbol Analysis */}
          <div className="glass-card p-4">
            <h2 className="section-title">
              <BarChart2 className="w-4 h-4 text-gold-400" />
              تحلیل نماد
            </h2>
            <div className="space-y-2.5">
              {symbolPerf.slice(0, 5).map(s => (
                <div key={s.symbol} className="flex items-center gap-2">
                  <span className="text-xs font-mono text-white bg-dark-700 px-1.5 py-0.5 rounded w-20 text-center">{s.symbol}</span>
                  <div className="flex-1 bg-dark-900 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${s.pnl >= 0 ? 'bg-success-500' : 'bg-danger-500'}`}
                      style={{ width: `${Math.min(Math.abs(s.winRate), 100)}%` }}
                    />
                  </div>
                  <span className={`text-xs w-14 text-left number-ltr ${s.pnl >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                    {formatCurrency(s.pnl)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Day Analysis */}
          <div className="glass-card p-4">
            <h2 className="section-title">
              <Calendar className="w-4 h-4 text-gold-400" />
              تحلیل روزهای هفته
            </h2>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={dayPerf}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="day" tick={{ fill: '#6c757d', fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: '#6c757d', fontSize: 9 }} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="pnl" radius={[3, 3, 0, 0]}>
                  {dayPerf.map((entry, i) => (
                    <Cell key={i} fill={entry.pnl >= 0 ? '#22c55e' : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Performance Command Center */}
      {profileMetrics && stats && stats.totalTrades > 0 && (
        <>
          <div className="glass-card p-4">
            <div className="flex items-center justify-between gap-3 mb-4">
              <div>
                <h2 className="section-title mb-1"><Gauge className="w-4 h-4 text-gold-400" />مرکز فرماندهی عملکرد</h2>
                <p className="text-xs text-dark-500">این بخش کیفیت سیستم معاملاتی را از نتیجه‌ی صرفِ سود و ضرر جدا می‌کند.</p>
              </div>
              <span className="text-[11px] px-2 py-1 rounded-full bg-gold-500/10 text-gold-300">بدون AI</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-2.5">
              {[
                ['Expectancy', formatCurrency(profileMetrics.expectancy), 'متوسط نتیجه هر معامله', profileMetrics.expectancy >= 0 ? 'text-success-400':'text-danger-400'],
                ['Avg Win', formatCurrency(profileMetrics.avgWin), 'میانگین برد', 'text-success-400'],
                ['Avg Loss', formatCurrency(-profileMetrics.avgLoss), 'میانگین باخت', 'text-danger-400'],
                ['Payoff', profileMetrics.payoff ? profileMetrics.payoff.toFixed(2)+'x':'—', 'برد / باخت', 'text-gold-300'],
                ['Avg R', profileMetrics.avgR.toFixed(2)+'R', 'میانگین R', profileMetrics.avgR>=0?'text-success-400':'text-danger-400'],
                ['Max DD', profileMetrics.maxDD.toFixed(2)+'%', 'افت از قله', 'text-danger-300'],
                ['Best Streak', String(streaks.bestWinStreak), 'برد متوالی', 'text-success-400'],
                ['Worst Streak', String(streaks.bestLossStreak), 'باخت متوالی', 'text-danger-400'],
              ].map(([title,value,sub,color]) => (
                <div key={title} className="rounded-xl border border-white/5 bg-dark-900/50 p-3">
                  <p className="text-[10px] text-dark-500">{title}</p>
                  <p className={`text-base font-bold number-ltr mt-1 ${color}`}>{value}</p>
                  <p className="text-[10px] text-dark-500 mt-0.5">{sub}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <div className="glass-card p-4">
              <h2 className="section-title"><Scale className="w-4 h-4 text-gold-400" />کیفیت ریسک و بازده</h2>
              <div className="space-y-3 mt-3">
                <div className="flex justify-between text-sm"><span className="text-dark-400">Profit Factor</span><b className="number-ltr text-white">{profileMetrics.profitFactor === Infinity ? '∞' : profileMetrics.profitFactor.toFixed(2)}</b></div>
                <div className="h-2 rounded-full bg-dark-800 overflow-hidden"><div className="h-full bg-gold-500 rounded-full" style={{width:`${Math.min(100, profileMetrics.profitFactor===Infinity?100:profileMetrics.profitFactor/2*100)}%`}} /></div>
                <div className="flex justify-between text-sm"><span className="text-dark-400">مجموع درصد ریسک ثبت‌شده</span><b className="number-ltr text-white">{profileMetrics.totalRisk.toFixed(2)}%</b></div>
                <div className="flex justify-between text-sm"><span className="text-dark-400">ریسک بیشینه فعلی</span><b className="number-ltr text-white">{stats.maxDrawdown.toFixed(2)}%</b></div>
                <div className="flex justify-between text-sm"><span className="text-dark-400">وضعیت</span><span className={profileMetrics.expectancy>=0 && profileMetrics.maxDD<10 ? 'text-success-400':'text-warning-400'}>{profileMetrics.expectancy>=0 && profileMetrics.maxDD<10 ? '🟢 ساختار قابل قبول':'🟡 نیازمند بازبینی'}</span></div>
              </div>
            </div>
            <div className="glass-card p-4">
              <h2 className="section-title"><Clock3 className="w-4 h-4 text-gold-400" />روند ماهانه</h2>
              <ResponsiveContainer width="100%" height={190}>
                <BarChart data={monthlyPerf.slice(-12)}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="month" tick={{fill:'#6c757d',fontSize:9}} tickLine={false} axisLine={false}/>
                  <YAxis tick={{fill:'#6c757d',fontSize:9}} tickLine={false} axisLine={false}/>
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="pnl" radius={[4,4,0,0]}>{monthlyPerf.slice(-12).map((e,i)=><Cell key={i} fill={e.pnl>=0?'#22c55e':'#ef4444'}/>)}</Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass-card p-4">
            <h2 className="section-title"><Brain className="w-4 h-4 text-gold-400" />داشبورد تصمیم‌گیری</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
              <div className="rounded-xl bg-success-500/5 border border-success-500/10 p-3"><p className="text-xs text-success-300">قوی‌ترین بخش</p><p className="text-sm text-white mt-1">{symbolPerf[0]?.symbol || 'با داده بیشتر مشخص می‌شود'}</p><p className="text-[10px] text-dark-500 mt-1">بیشترین P&L بین نمادها</p></div>
              <div className="rounded-xl bg-gold-500/5 border border-gold-500/10 p-3"><p className="text-xs text-gold-300">تمرکز بعدی</p><p className="text-sm text-white mt-1">Process Score + Psychology</p><p className="text-[10px] text-dark-500 mt-1">نتیجه را از کیفیت اجرا جدا کن.</p></div>
              <div className="rounded-xl bg-danger-500/5 border border-danger-500/10 p-3"><p className="text-xs text-danger-300">هشدار</p><p className="text-sm text-white mt-1">{streaks.bestLossStreak >= 3 ? 'رشته باخت متوالی ۳+ معامله':'فعلاً هشدار بحرانی دیده نشد'}</p><p className="text-[10px] text-dark-500 mt-1">برای بررسی رفتار پس از چند باخت متوالی.</p></div>
            </div>
          </div>
        </>
      )}

      {/* Best / Worst trades */}
      {(bestTrades.length > 0 || worstTrades.length > 0) && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <TradeTable title="بهترین معاملات" trades={bestTrades} icon={<TrendingUp className="w-4 h-4 text-success-400" />} />
          <TradeTable title="بدترین معاملات" trades={worstTrades} icon={<TrendingDown className="w-4 h-4 text-danger-400" />} />
        </div>
      )}

      {!loading && stats?.totalTrades === 0 && (
        <div className="glass-card p-12 text-center">
          <TrendingUp className="w-16 h-16 mx-auto mb-4 text-gold-500/30" />
          <h3 className="text-lg font-semibold text-white mb-2">هنوز معامله‌ای ثبت نشده</h3>
          <p className="text-dark-400 text-sm mb-4">اولین معامله خود را ثبت کنید تا داشبورد شما فعال شود.</p>
          <a href="/trade/new" className="btn-primary inline-flex items-center gap-2">
            <Zap className="w-4 h-4" />
            ثبت اولین معامله
          </a>
        </div>
      )}
    </div>
  );
}

function TradeTable({ title, trades, icon }: { title: string; trades: any[]; icon: React.ReactNode }) {
  if (trades.length === 0) return null;
  return (
    <div className="glass-card p-4">
      <h2 className="section-title">{icon}{title}</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-right">
              <th className="table-th">نماد</th>
              <th className="table-th">تاریخ</th>
              <th className="table-th">جهت</th>
              <th className="table-th">P&L</th>
              <th className="table-th">R:R</th>
            </tr>
          </thead>
          <tbody>
            {trades.map(t => (
              <tr key={t.id} className="table-row-hover">
                <td className="table-td font-mono text-gold-400">{t.symbol}</td>
                <td className="table-td text-dark-300 text-xs">{toPersianDate(t.trade_date)}</td>
                <td className="table-td">
                  <span className={t.direction === 'buy' ? 'text-success-400' : 'text-danger-400'}>
                    {t.direction === 'buy' ? '▲ خرید' : '▼ فروش'}
                  </span>
                </td>
                <td className={`table-td font-semibold number-ltr ${t.pnl_amount >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                  {formatCurrency(t.pnl_amount)}
                </td>
                <td className="table-td text-dark-300 number-ltr">{t.rr_ratio ? `${t.rr_ratio.toFixed(2)}R` : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
