-- Full user-owned reset: removes trades and resets the selected account/profile to zero.
CREATE OR REPLACE FUNCTION public.reset_account_fresh(p_account_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  DELETE FROM public.trades WHERE user_id = auth.uid() AND (account_id = p_account_id OR account_id IS NULL);
  UPDATE public.accounts SET initial_balance=0,current_balance=0,updated_at=now()
    WHERE id=p_account_id AND user_id=auth.uid();
  UPDATE public.profiles SET initial_capital=0,current_capital=0,updated_at=now() WHERE id=auth.uid();
END;
$$;
REVOKE ALL ON FUNCTION public.reset_account_fresh(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.reset_account_fresh(uuid) TO authenticated;
