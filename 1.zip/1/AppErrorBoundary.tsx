import { Component, type ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

type Props = { children: ReactNode };
type State = { error: Error | null };

export default class AppErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: { componentStack: string }) {
    console.error('Trading OS crashed:', error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;

    return (
      <div dir="rtl" className="min-h-screen bg-dark-950 flex items-center justify-center p-6">
        <div className="max-w-md w-full glass-card p-6 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-danger-500/10 border border-danger-500/20 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-7 h-7 text-danger-400" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">مشکلی پیش اومد</h1>
            <p className="text-sm text-dark-400 mt-2 leading-6">
              اپلیکیشن با یک خطا مواجه شد. معمولاً یک بار رفرش کردن مشکل رو حل می‌کنه.
              اگر ادامه داشت، احتمالاً فایل <code className="text-gold-400">.env</code> یا دیتابیس Supabase هنوز کامل تنظیم نشده.
            </p>
          </div>
          {this.state.error.message && (
            <p className="text-xs text-dark-500 bg-dark-900/60 rounded-lg p-2.5 font-mono break-words text-left" dir="ltr">
              {this.state.error.message}
            </p>
          )}
          <button
            onClick={() => window.location.reload()}
            className="btn-primary w-full flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-4 h-4" /> رفرش صفحه
          </button>
        </div>
      </div>
    );
  }
}
