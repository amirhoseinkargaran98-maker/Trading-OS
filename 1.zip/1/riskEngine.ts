/**
 * RISK ENGINE — single source of truth for "can this trader take another
 * trade right now?" Fully independent of AI: this must keep working even if
 * the AI Coach is disabled or the API key is missing, because this is the
 * layer that actually protects the account.
 *
 * Pure functions only — no React, no Supabase. UI layers (RiskManagement
 * page, Dashboard status pill, PreTradeCoach) call `evaluateRiskStatus` and
 * just render the result.
 */

export type RiskStatus = 'ready' | 'caution' | 'locked';

export type RiskReason = {
  code:
    | 'daily_loss_hit' | 'daily_loss_near'
    | 'max_trades_hit' | 'max_trades_near'
    | 'consecutive_losses_hit' | 'consecutive_losses_near'
    | 'drawdown_hit' | 'drawdown_near'
    | 'daily_target_hit';
  message: string;
};

export type RiskCheckResult = {
  status: RiskStatus;
  blockers: RiskReason[];
  warnings: RiskReason[];
  /** Informational only — never blocks (e.g. "hit today's profit target"). */
  notices: RiskReason[];
};

/** How close to a hard limit counts as CAUTION (80% by default). */
const CAUTION_THRESHOLD = 0.8;

export function evaluateRiskStatus(input: {
  isActive: boolean;
  todayPnlPercent: number;
  dailyMaxLossPercent: number;
  dailyProfitTargetPercent: number;
  tradesToday: number;
  maxTradesPerDay: number;
  consecutiveLosses: number;
  maxConsecutiveLosses: number;
  currentDrawdownPercent?: number;
  maxDrawdownPercent?: number;
}): RiskCheckResult {
  if (!input.isActive) {
    return { status: 'ready', blockers: [], warnings: [], notices: [] };
  }

  const blockers: RiskReason[] = [];
  const warnings: RiskReason[] = [];
  const notices: RiskReason[] = [];

  // Daily max loss
  const lossUsedRatio = input.dailyMaxLossPercent > 0
    ? Math.abs(Math.min(0, input.todayPnlPercent)) / input.dailyMaxLossPercent
    : 0;
  if (lossUsedRatio >= 1) {
    blockers.push({ code: 'daily_loss_hit', message: 'به سقف ضرر روزانه رسیده‌ای.' });
  } else if (lossUsedRatio >= CAUTION_THRESHOLD) {
    warnings.push({ code: 'daily_loss_near', message: 'به سقف ضرر روزانه نزدیک شده‌ای.' });
  }

  // Max trades per day
  const tradesRatio = input.maxTradesPerDay > 0 ? input.tradesToday / input.maxTradesPerDay : 0;
  if (tradesRatio >= 1) {
    blockers.push({ code: 'max_trades_hit', message: 'به سقف تعداد معاملات امروز رسیده‌ای.' });
  } else if (tradesRatio >= CAUTION_THRESHOLD) {
    warnings.push({ code: 'max_trades_near', message: 'به سقف تعداد معاملات امروز نزدیک شده‌ای.' });
  }

  // Consecutive losses
  if (input.maxConsecutiveLosses > 0) {
    if (input.consecutiveLosses >= input.maxConsecutiveLosses) {
      blockers.push({ code: 'consecutive_losses_hit', message: 'به سقف باخت‌های متوالی مجاز رسیده‌ای.' });
    } else if (input.consecutiveLosses >= input.maxConsecutiveLosses - 1) {
      warnings.push({ code: 'consecutive_losses_near', message: 'یک باخت دیگر به سقف باخت‌های متوالی می‌رسی.' });
    }
  }

  // Drawdown (optional — used for prop-firm style hard caps)
  if (input.maxDrawdownPercent && input.currentDrawdownPercent !== undefined) {
    const ddRatio = input.currentDrawdownPercent / input.maxDrawdownPercent;
    if (ddRatio >= 1) {
      blockers.push({ code: 'drawdown_hit', message: 'به حداکثر افت سرمایه‌ی مجاز رسیده‌ای.' });
    } else if (ddRatio >= CAUTION_THRESHOLD) {
      warnings.push({ code: 'drawdown_near', message: 'به حداکثر افت سرمایه‌ی مجاز نزدیک شده‌ای.' });
    }
  }

  // Daily profit target — informational only, never blocks
  if (input.dailyProfitTargetPercent > 0 && input.todayPnlPercent >= input.dailyProfitTargetPercent) {
    notices.push({ code: 'daily_target_hit', message: 'به هدف سود روزانه رسیده‌ای — معامله‌ی بیشتر ریسک اضافه‌ست، نه فرصت اضافه.' });
  }

  const status: RiskStatus = blockers.length > 0 ? 'locked' : warnings.length > 0 ? 'caution' : 'ready';
  return { status, blockers, warnings, notices };
}


export type ExecutionRiskBand = { key:'half_percent'|'one_percent'|'transition'|'under'|'over'; label:string; minAmount:number; maxAmount:number; minPercent:number; maxPercent:number; tone:'success'|'warning'|'danger'; blocks:boolean; };
export function getExecutionRiskBand(capital:number, actualRiskAmount:number|null|undefined):ExecutionRiskBand {
  const c=Math.max(0,Number(capital)||0), amount=Number(actualRiskAmount), halfMin=c*.005, halfMax=c*.006, oneMin=c*.009, oneMax=c*.011;
  if(!Number.isFinite(amount)||c<=0)return {key:'transition',label:'نیازمند بررسی',minAmount:halfMin,maxAmount:oneMax,minPercent:.5,maxPercent:1.1,tone:'warning',blocks:false};
  const pct=amount/c*100;
  if(amount>=halfMin&&amount<=halfMax)return {key:'half_percent',label:'باند استاندارد ۰٫۵٪',minAmount:halfMin,maxAmount:halfMax,minPercent:.5,maxPercent:.6,tone:'success',blocks:false};
  if(amount>=oneMin&&amount<=oneMax)return {key:'one_percent',label:'باند استاندارد ۱٪',minAmount:oneMin,maxAmount:oneMax,minPercent:.9,maxPercent:1.1,tone:'success',blocks:false};
  if(amount>oneMax)return {key:'over',label:`ریسک بیش از سقف ۱٫۱٪ (${pct.toFixed(2)}٪)`,minAmount:oneMin,maxAmount:oneMax,minPercent:.9,maxPercent:1.1,tone:'danger',blocks:true};
  return {key:amount<halfMin?'under':'transition',label:amount<halfMin?'ریسک کمتر از باند ۰٫۵٪':'ریسک بین دو باند استاندارد',minAmount:halfMin,maxAmount:oneMax,minPercent:.5,maxPercent:1.1,tone:'warning',blocks:false};
}

export const RISK_STATUS_LABEL: Record<RiskStatus, string> = {
  ready: 'آماده معامله',
  caution: 'با احتیاط',
  locked: 'قفل — معامله متوقف',
};

export type NoTradeWindow = {
  label: string;
  day_of_week: number | null; // 0=Sunday..6=Saturday, null = every day
  start_time: string; // 'HH:MM' or 'HH:MM:SS'
  end_time: string;
  is_active: boolean;
};

/**
 * Checks whether `now` falls inside any active recurring no-trade window.
 * Handles windows that cross midnight (e.g. 23:30-00:15). Returns the first
 * matching window's label, or null if the trader is clear to trade.
 */
export function checkNoTradeWindow(windows: NoTradeWindow[], now: Date = new Date()): string | null {
  const day = now.getDay();
  const minutesNow = now.getHours() * 60 + now.getMinutes();

  for (const w of windows) {
    if (!w.is_active) continue;
    if (w.day_of_week !== null && w.day_of_week !== day) continue;

    const [sh, sm] = w.start_time.split(':').map(Number);
    const [eh, em] = w.end_time.split(':').map(Number);
    const start = sh * 60 + sm;
    const end = eh * 60 + em;

    const inWindow = start <= end
      ? minutesNow >= start && minutesNow <= end
      : minutesNow >= start || minutesNow <= end; // crosses midnight

    if (inWindow) return w.label;
  }
  return null;
}
