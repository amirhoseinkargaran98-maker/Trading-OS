import { sampleConfidence } from '@/lib/tradingEngine';

export type EdgeTrade = {
  strategy_id?: string | null;
  setup_id?: string | null;
  result?: string | null;
  pnl_amount?: number | null;
  r_multiple?: number | null;
  process_score?: number | null;
  risk_percent?: number | null;
  session?: string | null;
  symbol?: string | null;
  direction?: string | null;
  entry_time?: string | null;
  strategies?: { name?: string | null } | null;
  setups?: { name?: string | null } | null;
};

export type EdgeRow = {
  id: string;
  name: string;
  kind: 'strategy' | 'setup';
  trades: number;
  wins: number;
  winRate: number;
  pnl: number;
  avgR: number;
  expectancy: number;
  profitFactor: number;
  avgProcess: number | null;
  avgRisk: number | null;
  bestSession: string | null;
  bestSymbol: string | null;
  bestDirection: string | null;
  confidence: 'low' | 'medium' | 'high';
  quality: number;
  status: 'edge' | 'watch' | 'weak' | 'insufficient';
};

const n = (v: unknown) => Number.isFinite(Number(v)) ? Number(v) : 0;
const sessionLabel: Record<string,string> = { london:'لندن', new_york:'نیویورک', asian:'آسیا', sydney:'سیدنی' };
const directionLabel: Record<string,string> = { buy:'خرید', sell:'فروش' };
const label = (v: string | null) => v ? (sessionLabel[v] || directionLabel[v] || v.replace(/_/g,' ')) : '—';

function groupBest(rows: EdgeTrade[], field: 'session'|'symbol'|'direction') {
  const map = new Map<string, { pnl:number; count:number }>();
  rows.forEach(t => {
    const value = t[field];
    if (!value) return;
    const key = String(value);
    const x = map.get(key) || { pnl:0, count:0 };
    x.pnl += n(t.pnl_amount);
    x.count += 1;
    map.set(key,x);
  });
  return [...map.entries()].sort((a,b) => (b[1].pnl-a[1].pnl) || (b[1].count-a[1].count))[0]?.[0] || null;
}

function metrics(rows: EdgeTrade[]) {
  const wins = rows.filter(t => n(t.pnl_amount) > 0);
  const losses = rows.filter(t => n(t.pnl_amount) < 0);
  const grossWin = wins.reduce((s,t)=>s+n(t.pnl_amount),0);
  const grossLoss = Math.abs(losses.reduce((s,t)=>s+n(t.pnl_amount),0));
  const pnl = rows.reduce((s,t)=>s+n(t.pnl_amount),0);
  const rs = rows.filter(t=>t.r_multiple != null).map(t=>n(t.r_multiple));
  const ps = rows.filter(t=>t.process_score != null).map(t=>n(t.process_score));
  const risks = rows.filter(t=>t.risk_percent != null).map(t=>n(t.risk_percent));
  return {
    trades: rows.length,
    wins: wins.length,
    winRate: rows.length ? wins.length/rows.length*100 : 0,
    pnl,
    avgR: rs.length ? rs.reduce((a,b)=>a+b,0)/rs.length : 0,
    expectancy: rows.length ? pnl/rows.length : 0,
    profitFactor: grossLoss ? grossWin/grossLoss : grossWin > 0 ? Infinity : 0,
    avgProcess: ps.length ? ps.reduce((a,b)=>a+b,0)/ps.length : null,
    avgRisk: risks.length ? risks.reduce((a,b)=>a+b,0)/risks.length : null,
  };
}

function score(m: ReturnType<typeof metrics>, baseline: ReturnType<typeof metrics>) {
  if (m.trades < 5) return 50;
  const size = Math.min(1, m.trades/30);
  const rEffect = Math.max(-1, Math.min(1, (m.avgR-baseline.avgR)/0.8));
  const winEffect = Math.max(-1, Math.min(1, (m.winRate-baseline.winRate)/25));
  const processEffect = m.avgProcess == null || baseline.avgProcess == null ? 0 : Math.max(-1, Math.min(1,(m.avgProcess-baseline.avgProcess)/20));
  return Math.round(Math.max(0, Math.min(100, 50 + size*(rEffect*25 + winEffect*15 + processEffect*10))));
}

export function buildEdgeRows(trades: EdgeTrade[], kind: 'strategy'|'setup'): EdgeRow[] {
  const closed = trades.filter(t => t.result !== 'open' && (t.pnl_amount != null || t.r_multiple != null));
  const baseline = metrics(closed);
  const map = new Map<string, EdgeTrade[]>();
  closed.forEach(t => {
    const id = kind === 'strategy' ? t.strategy_id : t.setup_id;
    if (!id) return;
    const arr = map.get(id) || [];
    arr.push(t);
    map.set(id, arr);
  });
  return [...map.entries()].map(([id, rows]) => {
    const m = metrics(rows);
    const confidence = sampleConfidence(m.trades);
    const quality = score(m, baseline);
    let status: EdgeRow['status'] = 'insufficient';
    if (m.trades >= 5) status = m.avgR > 0 && quality >= 58 ? 'edge' : m.avgR < 0 && quality <= 45 ? 'weak' : 'watch';
    const name = kind === 'strategy' ? (rows[0].strategies?.name || 'استراتژی بدون نام') : (rows[0].setups?.name || 'ستاپ بدون نام');
    return {
      id, name, kind, ...m,
      bestSession: groupBest(rows,'session'),
      bestSymbol: groupBest(rows,'symbol'),
      bestDirection: groupBest(rows,'direction'),
      confidence, quality, status,
    };
  }).sort((a,b) => b.quality-a.quality || b.trades-a.trades);
}

export function edgeSummary(rows: EdgeRow[]) {
  return {
    total: rows.length,
    actionable: rows.filter(x=>x.status==='edge').length,
    watch: rows.filter(x=>x.status==='watch').length,
    weak: rows.filter(x=>x.status==='weak').length,
    insufficient: rows.filter(x=>x.status==='insufficient').length,
    strongest: rows.filter(x=>x.status==='edge' && x.confidence !== 'low').slice(0,3),
  };
}
