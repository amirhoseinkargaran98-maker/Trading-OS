import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Shield, AlertTriangle, CheckCircle2, TrendingDown, TrendingUp,
  Percent, Hash, XCircle, Save
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency, toGregorianDateInput } from '@/lib/utils';
import { evaluateRiskStatus, RISK_STATUS_LABEL } from '@/lib/riskEngine';
import NoTradeWindowsManager from '@/components/NoTradeWindowsManager';

type Account = { id: string; name: string; broker: string | null; current_balance: number };

type RiskSettings = {
  id: string;
  account_id: string | null;
  max_risk_per_trade: number;
  daily_max_loss: number;
  daily_profit_target: number;
  max_trades_per_day: number;
  max_consecutive_losses: number;
  is_active: boolean;
};

type TradeLite = { result: string | null; pnl_amount: number | null; trade_date: string; created_at: string; account_id: string | null };

export default function RiskManagement() {
  const { user, profile } = useAuth();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<string | null>(null);
  const [settings, setSettings] = useState<RiskSettings | null>(null);
  const [todayTrades, setTodayTrades] = useState<TradeLite[]>([]);
  const [recentTrades, setRecentTrades] = useState<TradeLite[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    max_risk_per_trade: 1,
    daily_max_loss: 2,
    daily_profit_target: 3,
    max_trades_per_day: 5,
    max_consecutive_losses: 3,
    is_active: true,
  });

  const loadAccounts = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('accounts').select('id, name, broker, current_balance').eq('user_id', user.id).order('created_at');
    setAccounts(data || []);
    if (data && data.length > 0 && !selectedAccount) {
      const active = getActiveAccountId();
      setSelectedAccount(active && data.some(a => a.id === active) ? active : data[0].id);
    }
  }, [user, selectedAccount]);

  useEffect(() => { loadAccounts(); }, [loadAccounts]);

  const loadSettingsAndTrades = useCallback(async () => {
    if (!user || !selectedAccount) return;
    setLoading(true);

    let { data: rs } = await supabase
      .from('risk_settings')
      .select('*')
      .eq('user_id', user.id)
      .eq('account_id', selectedAccount)
      .maybeSingle();

    if (!rs) {
      const { data: created } = await supabase
        .from('risk_settings')
        .insert({ user_id: user.id, account_id: selectedAccount })
        .select('*')
        .maybeSingle();
      rs = created;
    }

    if (rs) {
      setSettings(rs);
      setForm({
        max_risk_per_trade: rs.max_risk_per_trade,
        daily_max_loss: rs.daily_max_loss,
        daily_profit_target: rs.daily_profit_target,
        max_trades_per_day: rs.max_trades_per_day,
        max_consecutive_losses: rs.max_consecutive_losses,
        is_active: rs.is_active,
      });
    }

    const today = toGregorianDateInput(new Date());
    const { data: todayData } = await supabase
      .from('trades')
      .select('result, pnl_amount, trade_date, created_at, account_id')
      .eq('user_id', user.id)
      .eq('account_id', selectedAccount)
      .eq('trade_date', today);
    setTodayTrades(todayData || []);

    const { data: recentData } = await supabase
      .from('trades')
      .select('result, pnl_amount, trade_date, created_at, account_id')
      .eq('user_id', user.id)
      .eq('account_id', selectedAccount)
      .not('result', 'eq', 'open')
      .order('trade_date', { ascending: false })
      .order('created_at', { ascending: false })
      .limit(15);
    setRecentTrades(recentData || []);

    setLoading(false);
  }, [user, selectedAccount]);

  useEffect(() => { loadSettingsAndTrades(); }, [loadSettingsAndTrades]);

  const handleSave = async () => {
    if (!user || !settings) return;
    setSaving(true);
    await supabase.from('risk_settings').update({
      max_risk_per_trade: form.max_risk_per_trade,
      daily_max_loss: form.daily_max_loss,
      daily_profit_target: form.daily_profit_target,
      max_trades_per_day: form.max_trades_per_day,
      max_consecutive_losses: form.max_consecutive_losses,
      is_active: form.is_active,
    }).eq('id', settings.id).eq('user_id', user.id);
    setSaving(false);
    loadSettingsAndTrades();
  };

  const account = accounts.find(a => a.id === selectedAccount);
  const balance = account?.current_balance || profile?.current_capital || 0;

  const dailyPnl = useMemo(() => todayTrades.reduce((sum, t) => sum + (Number(t.pnl_amount) || 0), 0), [todayTrades]);
  const dailyPnlPercent = balance > 0 ? (dailyPnl / balance) * 100 : 0;
  const tradesCountToday = todayTrades.length;

  const consecutiveLosses = useMemo(() => {
    let count = 0;
    for (const t of recentTrades) {
      if (t.result === 'loss') count += 1;
      else break;
    }
    return count;
  }, [recentTrades]);

  const risk = evaluateRiskStatus({
    isActive: form.is_active,
    todayPnlPercent: dailyPnlPercent,
    dailyMaxLossPercent: form.daily_max_loss,
    dailyProfitTargetPercent: form.daily_profit_target,
    tradesToday: tradesCountToday,
    maxTradesPerDay: form.max_trades_per_day,
    consecutiveLosses,
    maxConsecutiveLosses: form.max_consecutive_losses,
  });
  const maxLossHit = risk.blockers.some(b => b.code === 'daily_loss_hit');
  const tradesLimitHit = risk.blockers.some(b => b.code === 'max_trades_hit');
  const consecutiveLimitHit = risk.blockers.some(b => b.code === 'consecutive_losses_hit');
  const profitTargetHit = risk.notices.some(n => n.code === 'daily_target_hit');

  const riskAmountPerTrade = (balance * form.max_risk_per_trade) / 100;

  if (loading && !settings) {
    return (
      <div className="page-container flex items-center justify-center min-h-[60vh]" dir="rtl">
        <div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const statusStyles: Record<string, string> = {
    ready: 'border-success-500/20 bg-success-500/5',
    caution: 'border-gold-500/30 bg-gold-500/5',
    locked: 'border-danger-500/30 bg-danger-500/5',
  };
  const statusTextStyles: Record<string, string> = {
    ready: 'text-success-400',
    caution: 'text-gold-400',
    locked: 'text-danger-400',
  };
  const statusIcon = risk.status === 'ready' ? CheckCircle2 : AlertTriangle;
  const StatusIcon = statusIcon;
  const allMessages = [...risk.blockers, ...risk.warnings, ...risk.notices].map(r => r.message);

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-bold text-white">مدیریت ریسک</h1>
        </div>
        {accounts.length > 1 && (
          <select value={selectedAccount || ''} onChange={e => setSelectedAccount(e.target.value)} className="select-field w-auto">
            {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        )}
      </div>

      {accounts.length === 0 ? (
        <div className="glass-card p-10 text-center">
          <p className="text-dark-400 text-sm">ابتدا باید یک حساب معاملاتی داشته باشید.</p>
        </div>
      ) : (
        <>
          {/* Status banner */}
          <div className={`glass-card p-4 flex items-center gap-3 border ${statusStyles[risk.status]}`}>
            <StatusIcon className={`w-6 h-6 flex-shrink-0 ${statusTextStyles[risk.status]}`} />
            <div>
              <p className={`text-sm font-semibold ${statusTextStyles[risk.status]}`}>
                {RISK_STATUS_LABEL[risk.status]}
              </p>
              <p className="text-xs text-dark-400 mt-0.5">
                {allMessages.length > 0 ? allMessages.join(' ') : 'همه‌ی محدودیت‌های ریسک امروز رعایت شده است.'}
              </p>
            </div>
          </div>

          {/* Today snapshot */}
          <div>
            <h2 className="section-title"><TrendingUp className="w-4 h-4 text-gold-400" /> وضعیت امروز</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <RiskGauge
                label="سود/زیان روز"
                value={`${dailyPnlPercent >= 0 ? '+' : ''}${dailyPnlPercent.toFixed(2)}%`}
                sub={formatCurrency(dailyPnl)}
                percent={Math.min(100, (Math.abs(dailyPnlPercent) / Math.max(form.daily_max_loss, form.daily_profit_target, 1)) * 100)}
                danger={maxLossHit}
                good={profitTargetHit}
                icon={dailyPnl >= 0 ? TrendingUp : TrendingDown}
              />
              <RiskGauge
                label="تعداد معامله امروز"
                value={`${tradesCountToday} / ${form.max_trades_per_day}`}
                sub="سقف مجاز روزانه"
                percent={form.max_trades_per_day > 0 ? Math.min(100, (tradesCountToday / form.max_trades_per_day) * 100) : 0}
                danger={tradesLimitHit}
                icon={Hash}
              />
              <RiskGauge
                label="باخت‌های متوالی"
                value={`${consecutiveLosses} / ${form.max_consecutive_losses}`}
                sub="آخرین معاملات"
                percent={form.max_consecutive_losses > 0 ? Math.min(100, (consecutiveLosses / form.max_consecutive_losses) * 100) : 0}
                danger={consecutiveLimitHit}
                icon={XCircle}
              />
              <RiskGauge
                label="ریسک مجاز هر معامله"
                value={formatCurrency(riskAmountPerTrade)}
                sub={`${form.max_risk_per_trade}% از موجودی`}
                percent={0}
                icon={Percent}
              />
            </div>
          </div>

          {/* Settings form */}
          <div>
            <h2 className="section-title"><Shield className="w-4 h-4 text-gold-400" /> تنظیمات مدیریت ریسک</h2>
            <div className="glass-card p-4 md:p-6 space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label-text">حداکثر ریسک هر معامله (٪ از سرمایه)</label>
                  <input
                    type="number" step="0.1" min="0" max="100"
                    value={form.max_risk_per_trade}
                    onChange={e => setForm(f => ({ ...f, max_risk_per_trade: Number(e.target.value) }))}
                    className="input-field number-ltr"
                  />
                  <p className="text-[11px] text-dark-500 mt-1">معادل {formatCurrency(riskAmountPerTrade)} با موجودی فعلی</p>
                </div>
                <div>
                  <label className="label-text">حداکثر ضرر روزانه (٪)</label>
                  <input
                    type="number" step="0.1" min="0" max="100"
                    value={form.daily_max_loss}
                    onChange={e => setForm(f => ({ ...f, daily_max_loss: Number(e.target.value) }))}
                    className="input-field number-ltr"
                  />
                </div>
                <div>
                  <label className="label-text">هدف سود روزانه (٪)</label>
                  <input
                    type="number" step="0.1" min="0" max="100"
                    value={form.daily_profit_target}
                    onChange={e => setForm(f => ({ ...f, daily_profit_target: Number(e.target.value) }))}
                    className="input-field number-ltr"
                  />
                </div>
                <div>
                  <label className="label-text">حداکثر تعداد معامله در روز</label>
                  <input
                    type="number" step="1" min="0"
                    value={form.max_trades_per_day}
                    onChange={e => setForm(f => ({ ...f, max_trades_per_day: Number(e.target.value) }))}
                    className="input-field number-ltr"
                  />
                </div>
                <div>
                  <label className="label-text">حداکثر باخت‌های متوالی مجاز</label>
                  <input
                    type="number" step="1" min="0"
                    value={form.max_consecutive_losses}
                    onChange={e => setForm(f => ({ ...f, max_consecutive_losses: Number(e.target.value) }))}
                    className="input-field number-ltr"
                  />
                </div>
                <div className="flex items-end pb-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={form.is_active}
                      onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))}
                      className="w-4 h-4 accent-gold-500"
                    />
                    <span className="text-sm text-dark-300">اعمال این محدودیت‌ها فعال باشد</span>
                  </label>
                </div>
              </div>
              <div className="flex justify-end pt-2 border-t border-white/5">
                <button onClick={handleSave} disabled={saving} className="btn-primary flex items-center gap-1.5 text-sm">
                  <Save className="w-4 h-4" /> {saving ? 'در حال ذخیره...' : 'ذخیره تنظیمات'}
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      <NoTradeWindowsManager />
    </div>
  );
}

function RiskGauge({
  label, value, sub, percent, danger, good, icon: Icon,
}: {
  label: string; value: string; sub: string; percent: number; danger?: boolean; good?: boolean; icon: any;
}) {
  const barColor = danger ? 'bg-danger-500' : good ? 'bg-success-500' : 'bg-gold-500';
  return (
    <div className="kpi-card">
      <div className="flex items-center gap-1.5 text-dark-400">
        <Icon className="w-3.5 h-3.5" />
        <span className="text-[11px]">{label}</span>
      </div>
      <p className={`text-lg font-bold number-ltr ${danger ? 'text-danger-400' : 'text-white'}`}>{value}</p>
      <p className="text-[11px] text-dark-500">{sub}</p>
      {percent > 0 && (
        <div className="h-1.5 rounded-full bg-dark-700 overflow-hidden mt-1">
          <div className={`h-full ${barColor} transition-all duration-300`} style={{ width: `${Math.min(100, percent)}%` }} />
        </div>
      )}
    </div>
  );
}
