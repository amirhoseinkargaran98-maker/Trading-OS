/**
 * TRADING ENGINE — single source of truth for portfolio-level statistics.
 *
 * Per-trade math (P&L, risk, R:R, duration for ONE trade being entered) lives in
 * `calculateTradeMetrics` in `./utils.ts` — that function stays as-is.
 *
 * This file covers everything computed ACROSS a set of trades (win rate, profit
 * factor, expectancy, drawdown, equity curve, etc). Before this file existed,
 * every page (Dashboard, Analytics, Monthly Report, Strategies, Trading Calendar,
 * Reports Ticker) reimplemented these formulas independently — meaning a fix in
 * one place did not fix the others, and two screens could silently disagree.
 *
 * Rule: if a new page needs a portfolio statistic, add/reuse a function here
 * instead of writing the formula inline again.
 */

export type EngineTrade = {
  result: string | null;
  pnl_amount: number | null;
  r_multiple?: number | null;
  rr_ratio?: number | null;
  trade_date: string;
  entry_time?: string | null;
  created_at?: string | null;
  [key: string]: unknown;
};

/**
 * Deterministic chronological ordering for any set of trades.
 *
 * `trade_date` alone is a DATE (no time-of-day), so any query that only
 * `.order('trade_date')`s gives an UNSTABLE order for trades logged on the
 * same day (Postgres does not guarantee tie order). Every function in this
 * file that depends on sequence (equity curve, drawdown, streaks) must go
 * through this comparator instead of trusting caller order, so results are
 * identical no matter how the trades arrived from the DB.
 */
export function compareTradeChronological(a: EngineTrade, b: EngineTrade): number {
  const dateCmp = (a.trade_date || '').localeCompare(b.trade_date || '');
  if (dateCmp !== 0) return dateCmp;
  const at = a.entry_time ? String(a.entry_time) : '';
  const bt = b.entry_time ? String(b.entry_time) : '';
  if (at || bt) {
    const timeCmp = at.localeCompare(bt);
    if (timeCmp !== 0) return timeCmp;
  }
  const ac = a.created_at ? String(a.created_at) : '';
  const bc = b.created_at ? String(b.created_at) : '';
  return ac.localeCompare(bc);
}

/** Trades that have actually concluded (excludes still-open positions). */
export function closedTrades<T extends EngineTrade>(trades: T[]): T[] {
  return trades.filter(t => t.result === 'win' || t.result === 'loss' || t.result === 'breakeven');
}

export function calculateWinRate(trades: EngineTrade[]): number {
  const closed = closedTrades(trades);
  if (closed.length === 0) return 0;
  const wins = closed.filter(t => t.result === 'win').length;
  return (wins / closed.length) * 100;
}

export function calculateAverageWin(trades: EngineTrade[]): number {
  const wins = closedTrades(trades).filter(t => t.result === 'win');
  if (wins.length === 0) return 0;
  return wins.reduce((sum, t) => sum + (Number(t.pnl_amount) || 0), 0) / wins.length;
}

export function calculateAverageLoss(trades: EngineTrade[]): number {
  const losses = closedTrades(trades).filter(t => t.result === 'loss');
  if (losses.length === 0) return 0;
  return Math.abs(losses.reduce((sum, t) => sum + (Number(t.pnl_amount) || 0), 0) / losses.length);
}

/** Gross profit / gross loss. Returns Infinity if there are wins and zero losses. */
export function calculateProfitFactor(trades: EngineTrade[]): number {
  const closed = closedTrades(trades);
  const grossProfit = closed.filter(t => t.result === 'win').reduce((s, t) => s + (Number(t.pnl_amount) || 0), 0);
  const grossLoss = Math.abs(closed.filter(t => t.result === 'loss').reduce((s, t) => s + (Number(t.pnl_amount) || 0), 0));
  if (grossLoss === 0) return grossProfit > 0 ? Infinity : 0;
  return grossProfit / grossLoss;
}

/** Expected value per trade in currency terms: (winRate*avgWin) - (lossRate*avgLoss). */
export function calculateExpectancy(trades: EngineTrade[]): number {
  const closed = closedTrades(trades);
  if (closed.length === 0) return 0;
  const winRate = calculateWinRate(trades) / 100;
  const lossRate = 1 - winRate;
  const value = winRate * calculateAverageWin(trades) - lossRate * calculateAverageLoss(trades);
  return Math.abs(value) < 1e-10 ? 0 : value;
}

export function calculateAverageRMultiple(trades: EngineTrade[]): number {
  const values = closedTrades(trades)
    .map(t => Number(t.r_multiple))
    .filter(v => Number.isFinite(v));
  if (values.length === 0) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

/** Average PLANNED R:R ratio (target reward/risk set before the trade) — distinct
 * from calculateAverageRMultiple, which is the ACTUAL R achieved after the trade closed. */
export function calculateAveragePlannedRR(trades: EngineTrade[]): number {
  const values = closedTrades(trades)
    .map(t => Number(t.rr_ratio))
    .filter(v => !Number.isNaN(v) && v > 0);
  if (values.length === 0) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

export function calculateTotalPnl(trades: EngineTrade[]): number {
  return trades.reduce((sum, t) => sum + (Number(t.pnl_amount) || 0), 0);
}

export type EquityPoint = { date: string; capital: number; pnl: number };

/**
 * Builds a running equity curve from a starting capital and a chronologically
 * sorted trade list. Also returns max drawdown (peak-to-trough, in %) — the
 * single definition used everywhere in the app (Dashboard, Monthly Report).
 */
export function calculateEquityCurve(trades: EngineTrade[], startingCapital: number): {
  points: EquityPoint[];
  maxDrawdownPercent: number;
  currentDrawdownPercent: number;
  peakCapital: number;
} {
  const sorted = [...trades].sort(compareTradeChronological);
  let capital = startingCapital;
  let peak = startingCapital;
  let maxDrawdownPercent = 0;
  const points: EquityPoint[] = [{ date: sorted[0]?.trade_date || '', capital, pnl: 0 }];

  for (const t of sorted) {
    const pnl = Number(t.pnl_amount) || 0;
    capital += pnl;
    if (capital > peak) peak = capital;
    const drawdown = peak > 0 ? ((peak - capital) / peak) * 100 : 0;
    if (drawdown > maxDrawdownPercent) maxDrawdownPercent = drawdown;
    points.push({ date: t.trade_date, capital, pnl });
  }

  const currentDrawdownPercent = peak > 0 ? ((peak - capital) / peak) * 100 : 0;
  return { points, maxDrawdownPercent, currentDrawdownPercent, peakCapital: peak };
}

/**
 * Process vs Outcome classification — the core "good process can lose, bad
 * process can win" distinction. `processScore` (0-100) is currently a simple
 * rule-based estimate (psychology tags, risk discipline, and documented mistakes).
 * The result is persisted by TradeForm and reused by analytics; this function is
 * the single source of truth for the score calculation.
 */
export type ProcessVerdict = 'good_good' | 'good_bad' | 'bad_good' | 'bad_bad';

export function estimateProcessScore(trade: EngineTrade & {
  psychology_tags?: string[] | null;
  risk_percent?: number | null;
  mistakes?: string | null;
}, maxRiskPercent: number): number {
  let score = 100;
  const tags = trade.psychology_tags || [];
  const badTags = ['fomo', 'revenge', 'overtrading', 'greed', 'hesitation'];
  score -= tags.filter(t => badTags.includes(t)).length * 15;
  if ((trade.risk_percent || 0) > maxRiskPercent) score -= 25;
  if (trade.mistakes && trade.mistakes.trim().length > 0) score -= 15;
  return Math.max(0, Math.min(100, score));
}

export type ReviewFields = {
  is_open?: boolean | null;
  exit_reason?: string | null;
  mistakes?: string | null;
  lessons?: string | null;
  feeling_after?: string | null;
};

/** A review is complete only after a closed trade has a meaningful reflection. */
export function isTradeReviewComplete(trade: ReviewFields): boolean {
  if (trade.is_open !== false) return false;
  const hasReflection = Boolean(
    trade.lessons?.trim() || trade.mistakes?.trim() || trade.exit_reason?.trim()
  );
  const hasPostTradeState = Boolean(trade.feeling_after?.trim());
  return hasReflection && hasPostTradeState;
}

export function classifyProcessVsOutcome(processScore: number, pnl: number): ProcessVerdict {
  const goodProcess = processScore >= 70;
  const goodOutcome = pnl >= 0;
  if (goodProcess && goodOutcome) return 'good_good';
  if (goodProcess && !goodOutcome) return 'good_bad';
  if (!goodProcess && goodOutcome) return 'bad_good';
  return 'bad_bad';
}

/**
 * Statistical confidence label for small sample sizes — used anywhere a
 * "best setup/session/symbol" claim is shown, so the app never states a
 * strong conclusion from 2-3 trades.
 */
export function sampleConfidence(n: number): 'low' | 'medium' | 'high' {
  if (n < 10) return 'low';
  if (n < 30) return 'medium';
  return 'high';
}


export type TradeDataQuality = { score: number; missing: string[] };

/** Deterministic data-completeness check. This measures journal completeness, not trade quality. */
export function calculateTradeDataQuality(trade: Record<string, unknown>): TradeDataQuality {
  const checks: Array<[string, boolean]> = [
    ['تاریخ', Boolean(trade.trade_date)],
    ['زمان ورود', Boolean(trade.entry_time)],
    ['قیمت ورود', Number(trade.entry_price) > 0],
    ['حد ضرر', Number(trade.stop_loss) > 0],
    ['تارگت', Number(trade.take_profit) > 0],
    ['ریسک', Number(trade.risk_amount) > 0],
    ['Setup', Boolean(trade.setup_id || trade.entry_reason)],
    ['Strategy', Boolean(trade.strategy_id)],
    ['روانشناسی', Boolean(trade.feeling_before || trade.psychology_tags)],
    ['Review', trade.is_open === true || trade.review_completed === true],
  ];
  const missing = checks.filter(([, ok]) => !ok).map(([label]) => label);
  return { score: Math.round((checks.length - missing.length) / checks.length * 100), missing };
}
