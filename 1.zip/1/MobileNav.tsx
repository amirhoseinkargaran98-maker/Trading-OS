import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, TrendingUp, History, BarChart2,
  Calendar, Target, BookOpen, Settings, LogOut,
  Menu, X, Brain, Shield, PlusCircle, Layers, Sparkles, Gauge, Trophy,
  ClipboardList, Database, Crosshair, Compass, Award, Scroll, ClipboardCheck, Newspaper
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'داشبورد' },
  { to: '/trade/new', icon: PlusCircle, label: 'ثبت معامله' },
  { to: '/history', icon: History, label: 'تاریخچه' },
  { to: '/calendar', icon: Calendar, label: 'تقویم' },
  { to: '/analytics', icon: BarChart2, label: 'تحلیل' },
  { to: '/reports', icon: ClipboardList, label: 'گزارش‌ها' },
  { to: '/news', icon: Newspaper, label: 'نگهبان خبر' },
  { to: '/data', icon: Database, label: 'داده‌ها' },
  { to: '/ai-coach', icon: Sparkles, label: 'مربی AI' },
  { to: '/process-intelligence', icon: Gauge, label: 'هوشمندی فرآیند' },
  { to: '/trading-intelligence', icon: Trophy, label: 'مرکز هوش معاملاتی' },
  { to: '/context-intelligence', icon: Compass, label: 'هوش زمینه‌ای' },
  { to: '/edge-lab', icon: Crosshair, label: 'آزمایشگاه Edge' },
  { to: '/improvement', icon: ClipboardCheck, label: 'مرکز بهبود عملکرد' },
  { to: '/psychology', icon: Brain, label: 'روانشناسی' },
  { to: '/strategies', icon: Layers, label: 'استراتژی' },
  { to: '/risk', icon: Shield, label: 'ریسک' },
  { to: '/prop-mode', icon: Award, label: 'حالت پراپ' },
  { to: '/constitution', icon: Scroll, label: 'قانون اساسی معاملاتی' },
  { to: '/goals', icon: Target, label: 'اهداف' },
  { to: '/journal', icon: BookOpen, label: 'ژورنال' },
  { to: '/settings', icon: Settings, label: 'تنظیمات' },
];

export default function MobileNav() {
  const { signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <>
      {/* Top bar */}
      <header className="flex items-center justify-between px-4 py-3 bg-dark-900 border-b border-white/5 md:hidden">
        <button onClick={() => setOpen(true)} className="text-white p-1">
          <Menu className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-gradient-to-br from-gold-400 to-gold-600 rounded-lg flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-dark-950" strokeWidth={2.5} />
          </div>
          <span className="text-sm font-bold text-white">Trading OS</span>
        </div>
        <div className="w-7" />
      </header>

      {/* Bottom Nav (5 main items) */}
      <nav className="fixed bottom-0 left-0 right-0 bg-dark-900 border-t border-white/5 md:hidden z-40 safe-area-bottom">
        <div className="flex">
          {[navItems[0], navItems[1], navItems[2], navItems[3], navItems[4]].map(({ to, icon: Icon, label }) => {
            const isActive = to === '/' ? location.pathname === '/' : location.pathname.startsWith(to);
            return (
              <NavLink
                key={to}
                to={to}
                className={`flex-1 flex flex-col items-center py-2 gap-0.5 transition-colors ${
                  isActive ? 'text-gold-400' : 'text-dark-400 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px]">{label}</span>
              </NavLink>
            );
          })}
          <button
            onClick={() => setOpen(true)}
            className="flex-1 flex flex-col items-center py-2 gap-0.5 text-dark-400 hover:text-white"
          >
            <Menu className="w-5 h-5" />
            <span className="text-[10px]">بیشتر</span>
          </button>
        </div>
      </nav>

      {/* Full menu drawer */}
      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-72 bg-dark-900 flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-white/5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-br from-gold-400 to-gold-600 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-dark-950" strokeWidth={2.5} />
                </div>
                <span className="text-sm font-bold text-white">Trading OS</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-dark-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
              {navItems.map(({ to, icon: Icon, label }) => {
                const isActive = to === '/' ? location.pathname === '/' : location.pathname.startsWith(to);
                return (
                  <NavLink
                    key={to}
                    to={to}
                    onClick={() => setOpen(false)}
                    className={isActive ? 'nav-item-active flex' : 'nav-item flex'}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span>{label}</span>
                  </NavLink>
                );
              })}
            </nav>

            <div className="p-3 border-t border-white/5">
              <button
                onClick={() => { signOut(); setOpen(false); }}
                className="nav-item w-full text-danger-400 hover:text-danger-300 hover:bg-danger-500/10"
              >
                <LogOut className="w-4 h-4" />
                <span>خروج</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
