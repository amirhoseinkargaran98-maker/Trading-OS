import { useState } from 'react';
import { BrainCircuit, RefreshCw, ShieldCheck, AlertTriangle, XCircle } from 'lucide-react';
import { askTradingCoach } from '@/lib/aiCoach';

type Verdict = 'ok' | 'warning' | 'danger' | null;

function detectVerdict(text: string): Verdict {
  if (/خطرناک|نقض|تخلف|هشدار جدی/.test(text)) return 'danger';
  if (/احتیاط|مراقب|بهتر است|توجه کن/.test(text)) return 'warning';
  return 'ok';
}

export default function PostTradeCoach({ trade }: { trade: Record<string, unknown> }) {
  const [loading, setLoading] = useState(false);
  const [text, setText] = useState('');
  const [verdict, setVerdict] = useState<Verdict>(null);

  async function analyze() {
    setLoading(true);
    setText('');
    try {
      const result = await askTradingCoach({
        mode: 'post_trade',
        trades: [trade],
        question: 'این معامله‌ی بسته‌شده را با دیدی سخت‌گیرانه از نظر رعایت پلن، مدیریت ریسک و روانشناسی بررسی کن. یک حکم قطعی (قابل قبول/نیازمند احتیاط/خطرناک) بده و دقیقاً یک درس عملی برای معامله‌ی بعدی مشخص کن.',
      });
      const responseText = result.text || 'تحلیلی دریافت نشد.';
      setText(responseText);
      setVerdict(detectVerdict(responseText));
    } catch (error) {
      setText(error instanceof Error ? error.message : 'AI Coach در دسترس نیست.');
      setVerdict(null);
    } finally {
      setLoading(false);
    }
  }

  const verdictStyle = verdict === 'danger'
    ? 'border-danger-500/25 bg-danger-500/5 text-danger-300'
    : verdict === 'warning'
    ? 'border-gold-500/25 bg-gold-500/5 text-gold-300'
    : 'border-success-500/20 bg-success-500/5 text-dark-200';

  const VerdictIcon = verdict === 'danger' ? XCircle : verdict === 'warning' ? AlertTriangle : ShieldCheck;

  return (
    <div className="glass-card p-4 border-gold-500/15 bg-gold-500/[0.03]">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gold-500/10 flex items-center justify-center flex-shrink-0">
            <BrainCircuit className="w-4 h-4 text-gold-400" />
          </div>
          <div>
            <p className="text-xs text-gold-400 font-semibold">POST-TRADE REVIEW</p>
            <p className="text-sm font-semibold text-white mt-0.5">مرور این معامله با مربی هوش مصنوعی</p>
          </div>
        </div>
        <button type="button" onClick={analyze} disabled={loading} className="btn-secondary inline-flex items-center gap-2 text-sm">
          {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <BrainCircuit className="w-3.5 h-3.5" />}
          {loading ? 'در حال تحلیل...' : text ? 'تحلیل مجدد' : 'تحلیل کن'}
        </button>
      </div>

      {text && (
        <div className={`mt-4 rounded-xl border p-3 text-sm leading-7 ${verdictStyle}`}>
          <div className="flex gap-2 items-start">
            <VerdictIcon className="w-4 h-4 mt-1 flex-shrink-0" />
            <span className="whitespace-pre-wrap">{text}</span>
          </div>
        </div>
      )}
    </div>
  );
}
