import { useEffect, useState, useCallback, useRef } from 'react';
import { AlertTriangle, Flame, Brain, BookOpen, Target, X, ShieldAlert } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { getPsychologyLabel } from '@/lib/utils';
import { detectBehaviorSignals, type BehaviorSignal, type BehaviorSignalType } from '@/lib/behaviorEngine';
import { sendBrowserNotification } from '@/lib/notify';

const ICONS: Record<BehaviorSignalType, any> = {
  consecutive_losses: Flame,
  overtrading: ShieldAlert,
  psychology_pattern: Brain,
  missed_journal: BookOpen,
  goal_deadline: Target,
};

const TONE_STYLES: Record<BehaviorSignal['severity'], string> = {
  danger: 'border-danger-500/25 bg-danger-500/5',
  warning: 'border-gold-500/25 bg-gold-500/5',
  info: 'border-dark-500/20 bg-dark-800/40',
};

const ICON_TONE: Record<BehaviorSignal['severity'], string> = {
  danger: 'text-danger-400',
  warning: 'text-gold-400',
  info: 'text-dark-300',
};

export default function BehaviorAlerts() {
  const { user } = useAuth();
  const [signals, setSignals] = useState<BehaviorSignal[]>([]);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const notifiedRef = useRef<Set<string>>(new Set());

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    const now = new Date();
    const [{ data: recentTrades }, { data: riskSettings }, { data: reviews }, { data: goals }] = await Promise.all([
      supabase.from('trades').select('trade_date, result, psychology_tags, entry_time, created_at').eq('user_id', user.id).eq('account_id', getActiveAccountId()).not('result', 'eq', 'open').order('trade_date', { ascending: false }).order('entry_time', { ascending: false }).limit(60),
      supabase.from('risk_settings').select('max_trades_per_day, max_consecutive_losses, is_active').eq('user_id', user.id).eq('account_id', getActiveAccountId()).eq('is_active', true).limit(1),
      supabase.from('daily_reviews').select('review_date').eq('user_id', user.id).order('review_date', { ascending: false }).limit(1),
      supabase.from('goals').select('title, end_date, is_achieved').eq('user_id', user.id).eq('is_achieved', false).not('end_date', 'is', null),
    ]);

    // Domain logic lives entirely in behaviorEngine.ts — this component only
    // fetches data and renders. Swap data source or add a rule without
    // touching any JSX.
    const detected = detectBehaviorSignals({
      trades: recentTrades || [],
      maxConsecutiveLosses: riskSettings?.[0]?.max_consecutive_losses,
      maxTradesPerDay: riskSettings?.[0]?.max_trades_per_day,
      lastReviewDate: reviews?.[0]?.review_date || null,
      upcomingGoals: goals || [],
      now,
    });

    setSignals(detected);
    setLoading(false);

    // Fire a real browser notification for new danger-level signals only
    // (once per signal id per session) so risk warnings reach the trader
    // even if this tab isn't focused — never re-notifies for the same signal.
    detected.filter(s => s.severity === 'danger' && !notifiedRef.current.has(s.id)).forEach(s => {
      notifiedRef.current.add(s.id);
      sendBrowserNotification(s.title, s.description, s.id);
    });
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const visible = signals.filter(s => !dismissed.has(s.id));

  if (loading || visible.length === 0) return null;

  return (
    <div className="space-y-2 mb-2">
      {visible.map(s => {
        const Icon = ICONS[s.type] || AlertTriangle;
        const title = s.meta ? `${s.title}: ${getPsychologyLabel(s.meta)}` : s.title;
        return (
          <div key={s.id} className={`glass-card p-3.5 flex items-start gap-3 border ${TONE_STYLES[s.severity]}`}>
            <Icon className={`w-5 h-5 flex-shrink-0 mt-0.5 ${ICON_TONE[s.severity]}`} />
            <div className="flex-1 min-w-0">
              <p className={`text-sm font-semibold ${ICON_TONE[s.severity]}`}>{title}</p>
              <p className="text-xs text-dark-400 mt-0.5">{s.description}</p>
            </div>
            <button onClick={() => setDismissed(prev => new Set(prev).add(s.id))} className="text-dark-500 hover:text-white flex-shrink-0">
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}