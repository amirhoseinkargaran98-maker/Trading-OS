import { useMemo } from 'react';
import { Activity, CheckCircle2, CircleAlert, Clock3, Crosshair, Gauge, ShieldCheck, Target, Brain, ArrowDown, ArrowUp } from 'lucide-react';
import { formatCurrency, toPersianDateTime, getFeelingLabel, getPsychologyLabel } from '@/lib/utils';

type Props = { trade: any };

function num(v: any) { const n = Number(v); return Number.isFinite(n) ? n : 0; }

export default function TradeReplay({ trade }: Props) {
  const analysis = useMemo(() => {
    const checks = [
      { label: 'Entry مشخص و ثبت شده', ok: num(trade.entry_price) > 0 },
      { label: 'Stop Loss قبل از ورود مشخص شده', ok: num(trade.stop_loss) > 0 },
      { label: 'Take Profit مشخص شده', ok: num(trade.take_profit) > 0 },
      { label: 'ریسک معامله ثبت شده', ok: num(trade.risk_amount) > 0 },
      { label: 'دلیل ورود ثبت شده', ok: !!trade.entry_reason },
      { label: 'مرور پس از معامله تکمیل شده', ok: trade.review_completed === true },
    ];
    const score = Math.round(checks.filter(c => c.ok).length / checks.length * 100);
    const risk = num(trade.risk_amount);
    const rr = num(trade.rr_ratio);
    const actualR = trade.r_multiple == null ? null : num(trade.r_multiple);
    const execution = score >= 85 && rr >= 2 && risk > 0 ? 'clean' : score >= 65 ? 'review' : 'weak';
    return { checks, score, rr, risk, actualR, execution };
  }, [trade]);

  const events = [
    { key: 'plan', title: 'پیش از ورود', icon: ShieldCheck, tone: 'text-gold-400', content: trade.entry_reason || 'دلیل ورود ثبت نشده', meta: trade.feeling_before ? getFeelingLabel(trade.feeling_before) : 'حالت ذهنی ثبت نشده' },
    { key: 'entry', title: 'ورود', icon: Crosshair, tone: 'text-blue-400', content: `${trade.direction === 'buy' ? 'خرید' : 'فروش'} در ${trade.entry_price ?? '—'}`, meta: trade.entry_time ? toPersianDateTime(trade.entry_time) : 'زمان ثبت نشده' },
    { key: 'risk', title: 'کنترل ریسک', icon: Gauge, tone: 'text-purple-400', content: `ریسک ${formatCurrency(trade.risk_amount)}`, meta: `R:R ${trade.rr_ratio ? Number(trade.rr_ratio).toFixed(2) : '—'}` },
    { key: 'manage', title: 'مدیریت معامله', icon: Activity, tone: 'text-cyan-400', content: trade.mistakes || 'مورد خاصی ثبت نشده', meta: trade.feeling_during ? getFeelingLabel(trade.feeling_during) : 'حالت حین معامله ثبت نشده' },
    { key: 'exit', title: 'خروج', icon: trade.direction === 'buy' ? ArrowUp : ArrowDown, tone: trade.result === 'win' ? 'text-success-400' : 'text-danger-400', content: `${trade.exit_price ?? '—'} · ${trade.exit_reason || 'دلیل خروج ثبت نشده'}`, meta: trade.exit_time ? toPersianDateTime(trade.exit_time) : 'زمان خروج ثبت نشده' },
    { key: 'review', title: 'پس از معامله', icon: Brain, tone: 'text-gold-300', content: trade.lessons || 'درس معامله ثبت نشده', meta: trade.feeling_after ? getFeelingLabel(trade.feeling_after) : 'حالت بعد از معامله ثبت نشده' },
  ];

  return (
    <section className="glass-card p-5" dir="rtl">
      <div className="flex flex-wrap items-start justify-between gap-4 mb-5">
        <div>
          <div className="flex items-center gap-2"><Activity className="w-5 h-5 text-gold-400" /><h2 className="text-lg font-bold text-white">Replay & Execution Intelligence</h2></div>
          <p className="text-xs text-dark-400 mt-1">بازسازی مسیر معامله و ارزیابی کیفیت اجرا؛ مستقل از هوش مصنوعی</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-center"><div className="text-[11px] text-dark-400">Execution Score</div><div className="text-2xl font-black text-gold-400">{analysis.score}</div></div>
          <div className={`px-3 py-2 rounded-xl border text-xs font-semibold ${analysis.execution === 'clean' ? 'border-success-500/30 bg-success-500/10 text-success-400' : analysis.execution === 'review' ? 'border-warning-500/30 bg-warning-500/10 text-warning-400' : 'border-danger-500/30 bg-danger-500/10 text-danger-400'}`}>
            {analysis.execution === 'clean' ? 'اجرای تمیز' : analysis.execution === 'review' ? 'نیازمند بازبینی' : 'اجرای ضعیف'}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-6">
        <Mini label="ریسک واقعی" value={formatCurrency(analysis.risk)} />
        <Mini label="R:R برنامه‌ریزی‌شده" value={analysis.rr ? `${analysis.rr.toFixed(2)}R` : '—'} />
        <Mini label="نتیجه واقعی" value={analysis.actualR == null ? '—' : `${analysis.actualR > 0 ? '+' : ''}${analysis.actualR.toFixed(2)}R`} />
        <Mini label="وضعیت Review" value={trade.review_completed ? 'تکمیل' : 'ناقص'} />
      </div>

      <div className="relative">
        <div className="absolute right-[19px] top-4 bottom-4 w-px bg-white/10" />
        <div className="space-y-3">
          {events.map((e) => { const Icon = e.icon; return (
            <div key={e.key} className="relative flex gap-4 items-start">
              <div className={`relative z-10 w-10 h-10 shrink-0 rounded-xl border border-white/10 bg-dark-900 flex items-center justify-center ${e.tone}`}><Icon className="w-4 h-4" /></div>
              <div className="min-w-0 flex-1 rounded-xl border border-white/5 bg-white/[0.02] p-3">
                <div className="flex flex-wrap justify-between gap-2"><div className="text-sm font-semibold text-white">{e.title}</div><div className="text-[11px] text-dark-400">{e.meta}</div></div>
                <div className="text-xs text-dark-300 mt-1 leading-6">{e.content}</div>
              </div>
            </div>
          ); })}
        </div>
      </div>

      <div className="mt-5 pt-4 border-t border-white/5">
        <div className="text-xs font-semibold text-dark-300 mb-3">کنترل‌های فرآیند</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {analysis.checks.map(c => <div key={c.label} className="flex items-center gap-2 text-xs text-dark-300"><span className={c.ok ? 'text-success-400' : 'text-danger-400'}>{c.ok ? <CheckCircle2 className="w-4 h-4"/> : <CircleAlert className="w-4 h-4"/>}</span>{c.label}</div>)}
        </div>
      </div>
    </section>
  );
}

function Mini({ label, value }: {label:string; value:string}) { return <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3"><div className="text-[10px] text-dark-500 mb-1">{label}</div><div className="text-sm font-bold text-white number-ltr">{value}</div></div>; }
