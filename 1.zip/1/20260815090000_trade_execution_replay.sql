-- Trading OS Phase 8: optional event-level execution replay.
-- The UI works from the core trade fields even before this migration is applied.
CREATE TABLE IF NOT EXISTS trade_execution_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_id uuid NOT NULL REFERENCES trades(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK (event_type IN ('plan','entry','risk_check','management','exit','review','note')),
  event_time timestamptz NOT NULL DEFAULT now(),
  title text,
  content text,
  emotion text,
  price numeric(15,5),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS trade_execution_events_trade_idx ON trade_execution_events(trade_id, event_time);
CREATE INDEX IF NOT EXISTS trade_execution_events_user_idx ON trade_execution_events(user_id, event_time);

ALTER TABLE trade_execution_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_trade_execution_events" ON trade_execution_events;
CREATE POLICY "select_own_trade_execution_events" ON trade_execution_events FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_trade_execution_events" ON trade_execution_events;
CREATE POLICY "insert_own_trade_execution_events" ON trade_execution_events FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_trade_execution_events" ON trade_execution_events;
CREATE POLICY "update_own_trade_execution_events" ON trade_execution_events FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_trade_execution_events" ON trade_execution_events;
CREATE POLICY "delete_own_trade_execution_events" ON trade_execution_events FOR DELETE TO authenticated USING (auth.uid() = user_id);
