import { useEffect, useMemo, useState } from 'react';
import { CalendarDays, CalendarClock, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { daysInJalaliMonth, jalaliToGregorian, parseDateOnly, toJalaliDate, toPersianDigits } from '@/lib/utils';

type Props = { value?: string; onChange: (value: string) => void; onBlur?: () => void };

const MONTH_NAMES = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
const DAY_NAMES = ['ش','ی','د','س','چ','پ','ج'];

function parseJalali(value?: string) {
  const d = value ? parseDateOnly(value) : null;
  return d ? toJalaliDate(d) : null;
}
function formatJalali(y:number,m:number,d:number) { return `${y}/${String(m).padStart(2,'0')}/${String(d).padStart(2,'0')}`; }
function displayJalali(y:number,m:number,d:number) { return toPersianDigits(formatJalali(y,m,d)); }

function jalaliWeekday(year:number, month:number, day:number) {
  const g = jalaliToGregorian(`${year}/${month}/${day}`);
  const d = parseDateOnly(g);
  if (!d) return 0;
  // JS: Sunday=0. Convert to Persian calendar order Saturday=0.
  return (d.getDay() + 1) % 7;
}

export default function JalaliDatePicker({ value, onChange, onBlur }: Props) {
  const today = toJalaliDate(new Date());
  const selected = parseJalali(value);
  const [open,setOpen] = useState(false);
  const [draft,setDraft] = useState(selected || today);
  const [view,setView] = useState({year:(selected||today).year, month:(selected||today).month});
  const [yearMode,setYearMode] = useState(false);

  useEffect(()=>{ if(open){ const next=selected||today; setDraft(next); setView({year:next.year,month:next.month}); setYearMode(false); } },[open, value]);

  const days = useMemo(()=>daysInJalaliMonth(view.year,view.month),[view.year,view.month]);
  const firstWeekday = jalaliWeekday(view.year,view.month,1);
  const cells = useMemo(()=>Array.from({length:42},(_,i)=>{ const n=i-firstWeekday+1; return n>=1&&n<=days?n:null; }),[firstWeekday,days]);
  const isToday = (d:number) => view.year===today.year && view.month===today.month && d===today.day;
  const isSelected = (d:number) => draft.year===view.year && draft.month===view.month && d===draft.day;

  const close=()=>{setOpen(false);onBlur?.()};
  const choose=(day:number)=>setDraft({year:view.year,month:view.month,day});
  const confirm=()=>{ const g=jalaliToGregorian(formatJalali(draft.year,draft.month,draft.day)); if(g) onChange(g); close(); };
  const setToday=()=>{ setDraft(today); setView({year:today.year,month:today.month}); const g=jalaliToGregorian(formatJalali(today.year,today.month,today.day)); if(g) onChange(g); close(); };
  const moveMonth=(delta:number)=>{
    let y=view.year,m=view.month+delta; if(m<1){m=12;y--;} if(m>12){m=1;y++;}
    setView({year:y,month:m});
    setDraft(d=>({...d,year:y,month:m,day:Math.min(d.day,daysInJalaliMonth(y,m))}));
  };
  const yearOptions=Array.from({length:15},(_,i)=>today.year-7+i);
  const text=selected?displayJalali(selected.year,selected.month,selected.day):'';

  return <div className="relative">
    <button type="button" onClick={()=>setOpen(true)} className="input-field w-full flex items-center justify-between gap-2">
      <span className={text?'text-white':'text-dark-500'}>{text||'انتخاب تاریخ'}</span><CalendarDays className="w-4 h-4 text-gold-400"/>
    </button>
    {open && <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 sm:p-6" dir="rtl">
      <button type="button" aria-label="بستن انتخاب تاریخ" onClick={close} className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative z-10 trade-date-picker-modal max-h-[calc(100vh-1rem)] overflow-y-auto rounded-3xl border border-white/10 bg-dark-900/98 shadow-2xl shadow-black/60 p-3 sm:p-4 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between mb-3">
          <div><h3 className="text-sm font-bold text-white">انتخاب تاریخ معامله</h3><p className="text-[10px] text-dark-500 mt-0.5">تقویم شمسی</p></div>
          <button type="button" onClick={close} className="p-2 rounded-xl text-dark-400 hover:text-white hover:bg-white/5"><X className="w-4 h-4"/></button>
        </div>
        <button type="button" onClick={setToday} className="w-full flex items-center justify-between gap-2 rounded-xl bg-gold-500/10 border border-gold-500/25 px-3 py-2 mb-3 text-gold-300 hover:bg-gold-500/15">
          <span className="flex items-center gap-2"><CalendarClock className="w-4 h-4"/> امروز</span><span className="number-ltr text-xs">{displayJalali(today.year,today.month,today.day)}</span>
        </button>
        <div className="rounded-xl border border-white/8 bg-black/10 p-2">
          <div className="flex items-center justify-between mb-3">
            <button type="button" onClick={()=>moveMonth(-1)} className="p-1.5 rounded-lg hover:bg-white/5 text-dark-300"><ChevronRight className="w-4 h-4"/></button>
            <button type="button" onClick={()=>setYearMode(v=>!v)} className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-white font-semibold">{toPersianDigits(view.year)} • {MONTH_NAMES[view.month-1]}</button>
            <button type="button" onClick={()=>moveMonth(1)} className="p-1.5 rounded-lg hover:bg-white/5 text-dark-300"><ChevronLeft className="w-4 h-4"/></button>
          </div>
          {yearMode ? <div className="grid grid-cols-3 gap-2 max-h-60 overflow-y-auto p-1">{yearOptions.map(y=><button key={y} type="button" onClick={()=>{setView(v=>({...v,year:y}));setYearMode(false)}} className={`rounded-xl py-3 text-sm ${y===view.year?'bg-gold-500/20 text-gold-300 border border-gold-500/30':'bg-white/5 text-dark-300 hover:bg-white/10'}`}>{toPersianDigits(y)}</button>)}</div> : <>
            <div className="grid grid-cols-7 mb-2">{DAY_NAMES.map(d=><div key={d} className="text-center text-[10px] text-dark-500 py-1">{d}</div>)}</div>
            <div className="grid grid-cols-7 gap-1">{cells.map((d,i)=>d===null?<div key={i} className="aspect-square"/>:<button key={i} type="button" onClick={()=>choose(d)} className={`aspect-square rounded-lg text-sm transition-all ${isSelected(d)?'bg-gold-500 text-dark-950 font-extrabold shadow-lg shadow-gold-500/20':isToday(d)?'border border-gold-500/50 text-gold-300 bg-gold-500/5':'text-dark-200 hover:bg-white/10'}`}>{toPersianDigits(d)}</button>)}</div>
          </>}
        </div>
        <div className="mt-3 rounded-xl bg-white/[0.03] border border-white/8 p-3 flex items-center justify-between">
          <div><div className="text-[10px] text-dark-500">تاریخ انتخاب‌شده</div><div className="text-lg font-bold text-white number-ltr mt-0.5">{displayJalali(draft.year,draft.month,draft.day)}</div></div>
          <div className="text-right"><div className="text-[10px] text-dark-500">معادل میلادی</div><div className="text-xs text-dark-300 number-ltr mt-1">{toPersianDigits(jalaliToGregorian(`${draft.year}/${draft.month}/${draft.day}`))}</div></div>
        </div>
        <button type="button" onClick={confirm} className="w-full mt-2 btn-primary py-2.5 text-sm">تأیید و انتخاب تاریخ</button>
      </div></div>}
  </div>;
}
