import { sampleConfidence } from '@/lib/tradingEngine';

export type ContextTrade = {
  strategy_id?: string | null; setup_id?: string | null; symbol?: string | null;
  session?: string | null; direction?: string | null; timeframe?: string | null;
  pnl_amount?: number | null; r_multiple?: number | null; process_score?: number | null;
  result?: string | null; strategies?: { name?: string | null } | null; setups?: { name?: string | null } | null;
};
export type ContextRow = {
  key:string; label:string; trades:number; winRate:number; avgR:number; expectancy:number;
  pnl:number; avgProcess:number|null; confidence:'low'|'medium'|'high'; quality:number;
  status:'insufficient'|'watch'|'promising'|'strong'; dimensions:Record<string,string>;
};
const n=(v:unknown)=>Number.isFinite(Number(v))?Number(v):0;
const nice=(v:string|null|undefined)=>v?String(v).replace(/_/g,' '):'—';
const dims=[['strategy','استراتژی'],['setup','ستاپ'],['symbol','نماد'],['session','سشن'],['direction','جهت'],['timeframe','تایم‌فریم']] as const;
function value(t:ContextTrade,k:string){if(k==='strategy')return t.strategy_id||null;if(k==='setup')return t.setup_id||null;return (t as any)[k]||null;}
function name(t:ContextTrade,k:string){if(k==='strategy')return t.strategies?.name||t.strategy_id||'استراتژی';if(k==='setup')return t.setups?.name||t.setup_id||'ستاپ';return nice(value(t,k));}
function metrics(rows:ContextTrade[]){const pnl=rows.reduce((s,t)=>s+n(t.pnl_amount),0);const rs=rows.filter(t=>t.r_multiple!=null).map(t=>n(t.r_multiple));const ps=rows.filter(t=>t.process_score!=null).map(t=>n(t.process_score));const wins=rows.filter(t=>n(t.pnl_amount)>0).length;return {trades:rows.length,pnl,avgR:rs.length?rs.reduce((a,b)=>a+b,0)/rs.length:0,expectancy:rows.length?pnl/rows.length:0,winRate:rows.length?wins/rows.length*100:0,avgProcess:ps.length?ps.reduce((a,b)=>a+b,0)/ps.length:null};}
export function buildContextRows(trades:ContextTrade[], minSample=5):ContextRow[]{
 const closed=trades.filter(t=>t.result!=='open'&&(t.pnl_amount!=null||t.r_multiple!=null));
 const base=metrics(closed); const map=new Map<string,ContextTrade[]>();
 // Start with 2- and 3-dimensional contexts; this gives useful combinations without exploding the UI.
 for(const t of closed){const active=dims.filter(([k])=>value(t,k)); for(let size=2;size<=3;size++){const combos=(arr:any[],start:number,prefix:any[]):any=>{if(prefix.length===size){const parts=prefix.map(([k,v]:any)=>`${k}:${v}`).join('|');const list=map.get(parts)||[];list.push(t);map.set(parts,list);return;}for(let i=start;i<arr.length;i++)combos(arr,i+1,[...prefix,arr[i]]);}; combos(active,0,[]);}}
 const rows:ContextRow[]=[];
 for(const [key,rs] of map){const m=metrics(rs);const confidence=sampleConfidence(m.trades);const size=Math.min(1,m.trades/30);const r=Math.max(-1,Math.min(1,(m.avgR-base.avgR)/0.8));const w=Math.max(-1,Math.min(1,(m.winRate-base.winRate)/25));const p=m.avgProcess==null||base.avgProcess==null?0:Math.max(-1,Math.min(1,(m.avgProcess-base.avgProcess)/20));const quality=Math.round(Math.max(0,Math.min(100,50+size*(r*25+w*15+p*10))));let status:ContextRow['status']='insufficient';if(m.trades>=minSample)status=m.avgR>0&&quality>=62?'strong':m.avgR>0?'promising':'watch';const dimensions:Record<string,string>={};key.split('|').forEach(part=>{const [k,v]=part.split(':');const d=dims.find(x=>x[0]===k);if(d)dimensions[d[1]]=k==='strategy'||k==='setup'?(rs.find(t=>value(t,k)===v)?.[k==='strategy'?'strategies':'setups'] as any)?.name||v:nice(v);});rows.push({key,label:Object.entries(dimensions).map(([k,v])=>`${k}: ${v}`).join(' · '),...m,confidence,quality,status,dimensions});}
 return rows.sort((a,b)=>b.quality-a.quality||b.avgR-a.avgR||b.trades-a.trades).slice(0,60);
}
export function contextSummary(rows:ContextRow[]){return {total:rows.length,strong:rows.filter(x=>x.status==='strong').length,promising:rows.filter(x=>x.status==='promising').length,insufficient:rows.filter(x=>x.status==='insufficient').length,best:rows.filter(x=>x.status==='strong'&&x.confidence!=='low').slice(0,3)};}
