ALTER TABLE public.profiles ALTER COLUMN initial_capital SET DEFAULT 0;
ALTER TABLE public.profiles ALTER COLUMN current_capital SET DEFAULT 0;
ALTER TABLE public.accounts ALTER COLUMN initial_balance SET DEFAULT 0;
ALTER TABLE public.accounts ALTER COLUMN current_balance SET DEFAULT 0;
CREATE OR REPLACE FUNCTION public.reset_account_balance(p_account_id uuid, p_new_initial numeric) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$ BEGIN UPDATE public.accounts SET initial_balance=GREATEST(0,COALESCE(p_new_initial,0)), current_balance=GREATEST(0,COALESCE(p_new_initial,0)), updated_at=now() WHERE id=p_account_id AND user_id=auth.uid(); END; $$;
REVOKE ALL ON FUNCTION public.reset_account_balance(uuid,numeric) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.reset_account_balance(uuid,numeric) TO authenticated;
