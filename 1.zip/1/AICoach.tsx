import { useEffect, useMemo, useState, type ElementType } from 'react';
import { BrainCircuit, MessageCircle, ShieldCheck, Sparkles, Target, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { askTradingCoach, buildLocalCoachSignals } from '@/lib/aiCoach';

const quickPrompts = [
  'سه مهم‌ترین اشتباه تکرارشونده من چیست؟',
  'امروز قبل از اولین معامله روی چه چیزی تمرکز کنم؟',
  'آیا الگوی FOMO یا Revenge در معاملات اخیرم دیده می‌شود؟',
  'عملکرد من را از نظر ریسک، اجرا و روانشناسی ارزیابی کن.',
];

export default function AICoach() {
  const { user, profile } = useAuth();
  const [trades, setTrades] = useState<Record<string, unknown>[]>([]);
  const [risk, setRisk] = useState<Record<string, unknown> | null>(null);
  const [goals, setGoals] = useState<Record<string, unknown>[]>([]);
  const [journals, setJournals] = useState<Record<string, unknown>[]>([]);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      supabase.from('trades').select('*').eq('user_id', user.id).eq('account_id', getActiveAccountId()).order('trade_date', { ascending: false }).limit(100),
      supabase.from('risk_settings').select('*').eq('user_id', user.id).eq('account_id', getActiveAccountId()).eq('is_active', true).maybeSingle(),
      supabase.from('goals').select('*').eq('user_id', user.id).eq('is_achieved', false).order('end_date', { ascending: true }).limit(20),
      supabase.from('daily_reviews').select('*').eq('user_id', user.id).order('review_date', { ascending: false }).limit(14),
    ]).then(([tradesResult, riskResult, goalsResult, journalsResult]) => {
      setTrades(tradesResult.data || []);
      setRisk(riskResult.data || null);
      setGoals(goalsResult.data || []);
      setJournals(journalsResult.data || []);
    });
  }, [user]);

  const signals = useMemo(() => buildLocalCoachSignals(trades), [trades]);

  async function ask(questionText = question) {
    if (!questionText.trim()) return;
    setLoading(true);
    setAnswer('');
    try {
      const result = await askTradingCoach({ profile, riskSettings: risk, trades, goals, journals, question: questionText, mode: 'chat' });
      setAnswer(result.text || 'پاسخی دریافت نشد.');
    } catch (error) {
      setAnswer(error instanceof Error ? error.message : 'خطا در اتصال به AI Coach');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div>
          <div className="flex items-center gap-2 text-gold-400 text-xs font-semibold"><Sparkles className="w-4 h-4" /> PERSONAL TRADING COACH</div>
          <h1 className="text-2xl font-bold text-white mt-2">مربی هوشمند معاملات</h1>
          <p className="text-sm text-dark-400 mt-1">مربی برای تصمیم‌گیری بهتر؛ نه سیگنال خرید و فروش.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Metric icon={ShieldCheck} title="انضباط" value={`${signals.disciplineScore}/100`} />
        <Metric icon={TrendingUp} title="نرخ برد اخیر" value={`${signals.winRate}%`} />
        <Metric icon={Target} title="تعداد معاملات" value={`${signals.sampleSize}`} />
        <Metric icon={BrainCircuit} title="تگ غالب" value={signals.topPsychologyTag || '—'} />
      </div>

      <div className="grid xl:grid-cols-[1fr_340px] gap-5 items-start">
        <section className="glass-card p-5">
          <div className="flex items-center gap-2 mb-4"><MessageCircle className="w-5 h-5 text-gold-400" /><h2 className="text-lg font-bold text-white">گفت‌وگو با مربی</h2></div>
          <div className="grid sm:grid-cols-2 gap-2 mb-5">
            {quickPrompts.map(prompt => <button key={prompt} onClick={() => { setQuestion(prompt); ask(prompt); }} className="text-right p-3 rounded-xl bg-white/[0.03] border border-white/5 hover:border-gold-500/20 hover:bg-gold-500/[0.04] text-xs text-dark-300 transition">{prompt}</button>)}
          </div>
          <textarea value={question} onChange={e => setQuestion(e.target.value)} placeholder="مثلاً: بر اساس ۳۰ معامله اخیرم، بزرگ‌ترین نقطه ضعف من چیست؟" rows={5} className="input-field resize-none" />
          <button onClick={() => ask()} disabled={loading || !question.trim()} className="btn-primary mt-3 w-full py-3">{loading ? 'مربی در حال تحلیل داده‌هاست...' : 'تحلیل کن'}</button>
          {answer && <div className="mt-5 rounded-2xl border border-gold-500/10 bg-black/20 p-5 whitespace-pre-wrap text-sm leading-8 text-dark-100">{answer}</div>}
        </section>

        <aside className="space-y-4">
          <div className="glass-card p-5">
            <p className="text-xs text-dark-400">اصل مربی</p>
            <h3 className="text-lg font-bold text-white mt-2">اول سیستم، بعد احساس.</h3>
            <p className="text-sm text-dark-400 leading-7 mt-3">قوانین ریسک توسط موتور سیستم کنترل می‌شوند. AI برای تشخیص الگو، توضیح و Coaching استفاده می‌شود.</p>
          </div>
          <div className="glass-card p-5">
            <p className="text-xs text-dark-400">وضعیت نمونه اخیر</p>
            <div className="mt-3 h-2 rounded-full bg-dark-700 overflow-hidden"><div className="h-full rounded-full bg-gold-500" style={{ width: `${signals.disciplineScore}%` }} /></div>
            <p className="text-xs text-dark-400 mt-2">امتیاز انضباط {signals.disciplineScore} از 100</p>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Metric({ icon: Icon, title, value }: { icon: ElementType; title: string; value: string }) {
  return <div className="glass-card p-4"><Icon className="w-4 h-4 text-gold-400" /><p className="text-xs text-dark-400 mt-3">{title}</p><p className="text-lg font-bold text-white mt-1 number-ltr">{value}</p></div>;
}