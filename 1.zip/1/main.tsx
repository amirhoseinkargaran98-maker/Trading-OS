import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import AppErrorBoundary from './components/AppErrorBoundary';
import './index.css';

const missingEnv = !import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY;

function EnvSetupNotice() {
  return (
    <div dir="rtl" style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: '#0d1117', color: '#fff', padding: 24, fontFamily: 'sans-serif',
    }}>
      <div style={{ maxWidth: 420, textAlign: 'center' }}>
        <h1 style={{ fontSize: 18, fontWeight: 700, marginBottom: 12 }}>تنظیمات Supabase یافت نشد</h1>
        <p style={{ fontSize: 14, color: '#adb5bd', lineHeight: 1.9, marginBottom: 12 }}>
          یک فایل به اسم <code style={{ color: '#f59e0b' }}>.env</code> کنار <code style={{ color: '#f59e0b' }}>package.json</code> بساز
          و این دو خط را با مقادیر واقعی پروژه‌ات (از Supabase Dashboard → Settings → API) پر کن:
        </p>
        <pre style={{
          textAlign: 'left', direction: 'ltr', background: 'rgba(255,255,255,0.05)',
          padding: 12, borderRadius: 8, fontSize: 12, overflowX: 'auto',
        }}>{`VITE_SUPABASE_URL=https://xxxxx.supabase.co\nVITE_SUPABASE_ANON_KEY=eyJ...`}</pre>
        <p style={{ fontSize: 13, color: '#6c757d', marginTop: 12 }}>بعد از ساختن فایل، دوباره سرور را اجرا کن.</p>
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppErrorBoundary>
      {missingEnv ? <EnvSetupNotice /> : <App />}
    </AppErrorBoundary>
  </StrictMode>
);
