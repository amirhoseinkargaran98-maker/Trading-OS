import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, TrendingUp, History, BarChart2,
  Calendar, Target, BookOpen, Settings, LogOut, ClipboardList,
  Menu, X, Brain, Shield, PlusCircle, ChevronRight,
  Layers, Sparkles, Gauge, Trophy, ClipboardCheck, Crosshair, Compass, Database, Award, Scroll, Newspaper
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'داشبورد' },
  { to: '/trade/new', icon: PlusCircle, label: 'ثبت معامله' },
  { to: '/history', icon: History, label: 'تاریخچه معاملات' },
  { to: '/calendar', icon: Calendar, label: 'تقویم' },
  { to: '/analytics', icon: BarChart2, label: 'تحلیل عملکرد' },
  { to: '/reports', icon: ClipboardList, label: 'گزارش‌های دوره‌ای' },
  { to: '/news', icon: Newspaper, label: 'نگهبان خبر' },
  { to: '/data', icon: Database, label: 'مرکز داده' },
  { to: '/ai-coach', icon: Sparkles, label: 'مربی هوش مصنوعی' },
  { to: '/process-intelligence', icon: Gauge, label: 'هوشمندی فرآیند' },
  { to: '/trading-intelligence', icon: Trophy, label: 'مرکز هوش معاملاتی' },
  { to: '/improvement', icon: ClipboardCheck, label: 'مرکز بهبود عملکرد' },
  { to: '/context-intelligence', icon: Compass, label: 'هوش زمینه‌ای' },
  { to: '/edge-lab', icon: Crosshair, label: 'آزمایشگاه Edge' },
  { to: '/prop-mode', icon: Award, label: 'حالت پراپ' },
  { to: '/constitution', icon: Scroll, label: 'قانون اساسی معاملاتی' },
  { to: '/psychology', icon: Brain, label: 'تحلیل روانشناسی' },
  { to: '/strategies', icon: Layers, label: 'استراتژی‌ها' },
  { to: '/risk', icon: Shield, label: 'مدیریت ریسک' },
  { to: '/goals', icon: Target, label: 'اهداف' },
  { to: '/journal', icon: BookOpen, label: 'ژورنال' },
  { to: '/settings', icon: Settings, label: 'تنظیمات' },
];

export default function Sidebar() {
  const { profile, signOut } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  return (
    <aside
      className={`
        relative flex flex-col h-full bg-dark-900 border-l border-white/5
        transition-all duration-300 ease-in-out
        ${collapsed ? 'w-16' : 'w-56'}
      `}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/5">
        {!collapsed && (
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-gradient-to-br from-gold-400 to-gold-600 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-dark-950" strokeWidth={2.5} />
            </div>
            <div>
              <span className="text-sm font-bold text-white">Trading OS</span>
            </div>
          </div>
        )}
        {collapsed && (
          <div className="w-8 h-8 bg-gradient-to-br from-gold-400 to-gold-600 rounded-lg flex items-center justify-center mx-auto">
            <TrendingUp className="w-4 h-4 text-dark-950" strokeWidth={2.5} />
          </div>
        )}
        {!collapsed && (
          <button
            onClick={() => setCollapsed(true)}
            className="text-dark-400 hover:text-white transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {collapsed && (
        <button
          onClick={() => setCollapsed(false)}
          className="absolute -left-3 top-20 bg-dark-700 border border-white/10 rounded-full p-1 text-dark-400 hover:text-white transition-colors shadow-lg z-10"
        >
          <ChevronRight className="w-3 h-3 rotate-180" />
        </button>
      )}

      {/* Nav */}
      <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
        {navItems.map(({ to, icon: Icon, label }) => {
          const isActive = to === '/'
            ? location.pathname === '/'
            : location.pathname.startsWith(to);
          return (
            <NavLink
              key={to}
              to={to}
              className={isActive ? 'nav-item-active flex' : 'nav-item flex'}
              title={collapsed ? label : undefined}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {!collapsed && <span className="text-sm truncate">{label}</span>}
            </NavLink>
          );
        })}
      </nav>

      {/* User section */}
      <div className="p-3 border-t border-white/5">
        {!collapsed ? (
          <div className="flex items-center gap-2.5 mb-2">
            <div className="w-8 h-8 bg-gold-500/20 border border-gold-500/30 rounded-full flex items-center justify-center text-gold-400 text-xs font-bold flex-shrink-0">
              {profile?.display_name?.charAt(0)?.toUpperCase() || 'T'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{profile?.display_name || 'تریدر'}</p>
              <p className="text-xs text-dark-400">حساب فعال</p>
            </div>
          </div>
        ) : (
          <div className="w-8 h-8 bg-gold-500/20 border border-gold-500/30 rounded-full flex items-center justify-center text-gold-400 text-xs font-bold mx-auto mb-2">
            {profile?.display_name?.charAt(0)?.toUpperCase() || 'T'}
          </div>
        )}
        <button
          onClick={signOut}
          className="nav-item w-full justify-center text-danger-400 hover:text-danger-300 hover:bg-danger-500/10"
          title="خروج"
        >
          <LogOut className="w-4 h-4" />
          {!collapsed && <span className="text-sm">خروج</span>}
        </button>
      </div>
    </aside>
  );
}
