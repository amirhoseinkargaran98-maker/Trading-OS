/*
# Trading OS - Full Database Schema

## Overview
Complete schema for Trading OS - a professional trading journal and performance management system.

## New Tables

### 1. profiles
Extends auth.users with user-specific settings and account info.
- id: references auth.users
- display_name, avatar_url
- initial_capital: starting account balance
- current_capital: live balance

### 2. accounts
Trading accounts (a user may have multiple broker accounts).
- user_id, name, broker, currency, initial_balance, current_balance, is_active

### 3. strategies
Trading strategies created by the user.
- user_id, name, description, rules, is_active

### 4. setups
Specific trade setups/patterns.
- user_id, strategy_id, name, description

### 5. tags
Reusable tags for trades.
- user_id, name, color

### 6. trades
Core trade records - the heart of the system.
- All trade data: symbol, direction, session, entry/exit prices, SL/TP
- P&L, R:R, lot size, risk
- Psychology fields
- Links to strategy, setup, tags

### 7. trade_screenshots
Screenshots attached to trades (Before/Entry/After).
- trade_id, url, type, caption

### 8. daily_reviews
Daily trading journal entries.
- user_id, date, content, mood, lessons, plan

### 9. notes
General notes and journal entries.
- user_id, type (daily/weekly/monthly), title, content, date

### 10. goals
Trading goals with progress tracking.
- user_id, type, title, target, current, period, deadline

### 11. risk_settings
Per-account risk management configuration.
- user_id, account_id, max_risk_per_trade, daily_max_loss, daily_profit_target, max_trades_per_day, max_consecutive_losses

### 12. ai_reports
AI-generated analysis reports.
- user_id, type, content, metadata, generated_at

## Security
All tables have RLS enabled with owner-scoped policies (authenticated only).
*/

-- ─── PROFILES ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  avatar_url text,
  initial_capital numeric(15,2) NOT NULL DEFAULT 0,
  current_capital numeric(15,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE TO authenticated USING (auth.uid() = id);

-- ─── ACCOUNTS ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  broker text,
  account_type text DEFAULT 'live', -- live, demo, prop
  currency text NOT NULL DEFAULT 'USD',
  initial_balance numeric(15,2) NOT NULL DEFAULT 0,
  current_balance numeric(15,2) NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_accounts" ON accounts;
CREATE POLICY "select_own_accounts" ON accounts FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_accounts" ON accounts;
CREATE POLICY "insert_own_accounts" ON accounts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_accounts" ON accounts;
CREATE POLICY "update_own_accounts" ON accounts FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_accounts" ON accounts;
CREATE POLICY "delete_own_accounts" ON accounts FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── STRATEGIES ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS strategies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  rules text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE strategies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_strategies" ON strategies;
CREATE POLICY "select_own_strategies" ON strategies FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_strategies" ON strategies;
CREATE POLICY "insert_own_strategies" ON strategies FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_strategies" ON strategies;
CREATE POLICY "update_own_strategies" ON strategies FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_strategies" ON strategies;
CREATE POLICY "delete_own_strategies" ON strategies FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── SETUPS ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS setups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  strategy_id uuid REFERENCES strategies(id) ON DELETE SET NULL,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE setups ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_setups" ON setups;
CREATE POLICY "select_own_setups" ON setups FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_setups" ON setups;
CREATE POLICY "insert_own_setups" ON setups FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_setups" ON setups;
CREATE POLICY "update_own_setups" ON setups FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_setups" ON setups;
CREATE POLICY "delete_own_setups" ON setups FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── TAGS ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  color text DEFAULT '#f59e0b',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tags ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_tags" ON tags;
CREATE POLICY "select_own_tags" ON tags FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_tags" ON tags;
CREATE POLICY "insert_own_tags" ON tags FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_tags" ON tags;
CREATE POLICY "update_own_tags" ON tags FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_tags" ON tags;
CREATE POLICY "delete_own_tags" ON tags FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── TRADES ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS trades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  account_id uuid REFERENCES accounts(id) ON DELETE SET NULL,
  strategy_id uuid REFERENCES strategies(id) ON DELETE SET NULL,
  setup_id uuid REFERENCES setups(id) ON DELETE SET NULL,

  -- Identification
  trade_number serial,

  -- Date/Time
  trade_date date NOT NULL,
  entry_time timestamptz,
  exit_time timestamptz,
  duration_minutes integer,

  -- Market Info
  symbol text NOT NULL,
  direction text NOT NULL CHECK (direction IN ('buy', 'sell')),
  timeframe text,
  session text, -- london, new_york, asian, sydney
  market_condition text, -- trend, range, breakout, pullback, reversal

  -- Prices
  entry_price numeric(15,5),
  exit_price numeric(15,5),
  stop_loss numeric(15,5),
  take_profit numeric(15,5),

  -- Sizing
  lot_size numeric(10,4),
  contract_size numeric(15,2) DEFAULT 100,

  -- Risk/Reward
  risk_percent numeric(8,4),
  risk_amount numeric(15,2),
  potential_profit numeric(15,2),
  rr_ratio numeric(8,4),

  -- P&L
  pnl_amount numeric(15,2),
  pnl_percent numeric(8,4),
  capital_before numeric(15,2),
  capital_after numeric(15,2),

  -- Result
  result text CHECK (result IN ('win', 'loss', 'breakeven', 'open')),
  r_multiple numeric(8,4),

  -- Reasons
  entry_reason text,
  exit_reason text,
  trend text,

  -- Psychology
  feeling_before text, -- calm, anxious, confident, fearful, greedy, neutral
  feeling_during text,
  feeling_after text,
  psychology_tags text[], -- fomo, revenge, overtrading, fear, greed, hesitation

  -- Mistakes & Lessons
  mistakes text,
  lessons text,
  notes text,

  -- Status
  is_open boolean DEFAULT false,
  tags text[],

  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS trades_user_id_idx ON trades(user_id);
CREATE INDEX IF NOT EXISTS trades_trade_date_idx ON trades(trade_date);
CREATE INDEX IF NOT EXISTS trades_symbol_idx ON trades(symbol);
CREATE INDEX IF NOT EXISTS trades_result_idx ON trades(result);

ALTER TABLE trades ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_trades" ON trades;
CREATE POLICY "select_own_trades" ON trades FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_trades" ON trades;
CREATE POLICY "insert_own_trades" ON trades FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_trades" ON trades;
CREATE POLICY "update_own_trades" ON trades FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_trades" ON trades;
CREATE POLICY "delete_own_trades" ON trades FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── TRADE SCREENSHOTS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS trade_screenshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_id uuid NOT NULL REFERENCES trades(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  url text NOT NULL,
  screenshot_type text DEFAULT 'entry', -- before, entry, after
  caption text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trade_screenshots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_screenshots" ON trade_screenshots;
CREATE POLICY "select_own_screenshots" ON trade_screenshots FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_screenshots" ON trade_screenshots;
CREATE POLICY "insert_own_screenshots" ON trade_screenshots FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_screenshots" ON trade_screenshots;
CREATE POLICY "update_own_screenshots" ON trade_screenshots FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_screenshots" ON trade_screenshots;
CREATE POLICY "delete_own_screenshots" ON trade_screenshots FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── DAILY REVIEWS ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS daily_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  review_date date NOT NULL,
  mood text, -- great, good, neutral, bad, terrible
  content text,
  lessons text,
  plan_for_tomorrow text,
  daily_pnl numeric(15,2),
  total_trades integer DEFAULT 0,
  wins integer DEFAULT 0,
  losses integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, review_date)
);

ALTER TABLE daily_reviews ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_reviews" ON daily_reviews;
CREATE POLICY "select_own_reviews" ON daily_reviews FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_reviews" ON daily_reviews;
CREATE POLICY "insert_own_reviews" ON daily_reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_reviews" ON daily_reviews;
CREATE POLICY "update_own_reviews" ON daily_reviews FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_reviews" ON daily_reviews;
CREATE POLICY "delete_own_reviews" ON daily_reviews FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── NOTES ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  note_type text DEFAULT 'daily', -- daily, weekly, monthly, general
  title text,
  content text NOT NULL,
  note_date date,
  tags text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE notes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_notes" ON notes;
CREATE POLICY "select_own_notes" ON notes FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_notes" ON notes;
CREATE POLICY "insert_own_notes" ON notes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notes" ON notes;
CREATE POLICY "update_own_notes" ON notes FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notes" ON notes;
CREATE POLICY "delete_own_notes" ON notes FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── GOALS ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  goal_type text NOT NULL, -- profit, win_rate, drawdown, trades, rr, capital
  target_value numeric(15,4),
  current_value numeric(15,4) DEFAULT 0,
  period text DEFAULT 'monthly', -- daily, weekly, monthly, yearly
  start_date date,
  end_date date,
  is_achieved boolean DEFAULT false,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE goals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_goals" ON goals;
CREATE POLICY "select_own_goals" ON goals FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_goals" ON goals;
CREATE POLICY "insert_own_goals" ON goals FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_goals" ON goals;
CREATE POLICY "update_own_goals" ON goals FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_goals" ON goals;
CREATE POLICY "delete_own_goals" ON goals FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── RISK SETTINGS ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS risk_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  account_id uuid REFERENCES accounts(id) ON DELETE CASCADE,
  max_risk_per_trade numeric(5,2) DEFAULT 1.0,
  daily_max_loss numeric(5,2) DEFAULT 2.0,
  daily_profit_target numeric(5,2) DEFAULT 3.0,
  max_trades_per_day integer DEFAULT 5,
  max_consecutive_losses integer DEFAULT 3,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, account_id)
);

ALTER TABLE risk_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_risk_settings" ON risk_settings;
CREATE POLICY "select_own_risk_settings" ON risk_settings FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_risk_settings" ON risk_settings;
CREATE POLICY "insert_own_risk_settings" ON risk_settings FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_risk_settings" ON risk_settings;
CREATE POLICY "update_own_risk_settings" ON risk_settings FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_risk_settings" ON risk_settings;
CREATE POLICY "delete_own_risk_settings" ON risk_settings FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── AI REPORTS ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  report_type text NOT NULL, -- performance, psychology, pattern, weekly, monthly
  title text,
  content text NOT NULL,
  metadata jsonb,
  generated_at timestamptz DEFAULT now()
);

ALTER TABLE ai_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_ai_reports" ON ai_reports;
CREATE POLICY "select_own_ai_reports" ON ai_reports FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_ai_reports" ON ai_reports;
CREATE POLICY "insert_own_ai_reports" ON ai_reports FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_ai_reports" ON ai_reports;
CREATE POLICY "update_own_ai_reports" ON ai_reports FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_ai_reports" ON ai_reports;
CREATE POLICY "delete_own_ai_reports" ON ai_reports FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ─── AUTO-CREATE PROFILE ON SIGNUP ───────────────────────────────────────────
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, initial_capital, current_capital)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
    0,
    0
  )
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.accounts (user_id, name, broker, initial_balance, current_balance)
  VALUES (
    NEW.id,
    'حساب اصلی',
    'My Broker',
    0,
    0
  )
  ON CONFLICT DO NOTHING;

  INSERT INTO public.risk_settings (user_id)
  SELECT NEW.id
  WHERE NOT EXISTS (SELECT 1 FROM public.risk_settings WHERE user_id = NEW.id AND account_id IS NULL);

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
