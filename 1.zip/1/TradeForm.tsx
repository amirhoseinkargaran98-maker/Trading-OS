import { useState, useEffect, useCallback, useMemo } from 'react';
import type { ElementType, ReactNode } from 'react';
import { useForm, Controller, useWatch } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';
import { Calculator, Save, X, ChevronDown, AlertCircle, CheckCircle, Layers, Copy, Bookmark, Trash2, ShieldCheck, ShieldAlert, Zap, LockKeyhole, ArrowDownToLine, ArrowUpFromLine, CalendarOff } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import {
  calculateTradeMetrics, determineResult, getContractSize,
  toPersianDate, CONTRACT_SIZES, toGregorianDateInput, formatCurrency, combineDateAndTimeLocal, getTradeTimeInput, normalizeLotSize, formatLotSize, roundMoney
} from '@/lib/utils';
import JalaliDatePicker from '@/components/JalaliDatePicker';
import TimeScrollPicker from '@/components/TimeScrollPicker';
import TradeScreenshots from '@/components/TradeScreenshots';
import { estimateProcessScore, isTradeReviewComplete } from '@/lib/tradingEngine';
import { getExecutionRiskBand } from '@/lib/riskEngine';
import { parseLegacyRules, evaluateStrategyRules } from '@/lib/ruleEngine';
import { checkNoTradeWindow } from '@/lib/riskEngine';
import { combineTradeDateTime } from '@/lib/utils';
import PreTradeCoach from '@/components/ai/PreTradeCoach';

const SYMBOLS = ['XAUUSD', 'EURUSD', 'GBPUSD', 'USDJPY', 'US30', 'NAS100', 'SPX500', 'BTCUSD', 'ETHUSD', 'GBPJPY', 'AUDUSD', 'USDCAD'];
const TIMEFRAMES = ['m1','m5','m15','m30','h1','h4','d1','w1'];
const TF_LABELS: Record<string,string> = { m1:'M1', m5:'M5', m15:'M15', m30:'M30', h1:'H1', h4:'H4', d1:'D1', w1:'W1' };
const SESSIONS = [
  { value: 'london', label: 'لندن' },
  { value: 'new_york', label: 'نیویورک' },
  { value: 'asian', label: 'آسیا' },
  { value: 'sydney', label: 'سیدنی' },
];
const CONDITIONS = [
  { value: 'trend', label: 'روند' },
  { value: 'range', label: 'رنج' },
  { value: 'breakout', label: 'شکست' },
  { value: 'pullback', label: 'پولبک' },
  { value: 'reversal', label: 'بازگشت' },
];
const FEELINGS = [
  { value: 'calm', label: '😌 آرام' },
  { value: 'confident', label: '💪 مطمئن' },
  { value: 'neutral', label: '😐 خنثی' },
  { value: 'satisfied', label: '😊 راضی' },
  { value: 'anxious', label: '😟 نگران' },
  { value: 'fearful', label: '😨 ترسیده' },
  { value: 'angry', label: '😡 عصبانی' },
  { value: 'excited', label: '🤩 هیجان‌زده' },
  { value: 'greedy', label: '🤑 طمعکار' },
  { value: 'frustrated', label: '😤 ناامید' },
];
const PSYCH_TAGS = [
  { value: 'fomo', label: '🏃 FOMO' },
  { value: 'revenge', label: '😡 انتقام' },
  { value: 'overtrading', label: '🔄 اورترید' },
  { value: 'fear', label: '😨 ترس' },
  { value: 'greed', label: '🤑 طمع' },
  { value: 'hesitation', label: '🤔 تردید' },
  { value: 'discipline', label: '🧘 انضباط' },
  { value: 'confidence', label: '💪 اطمینان' },
  { value: 'satisfaction', label: '😊 رضایت' },
  { value: 'anger', label: '🔥 عصبانیت' },
];

type FormValues = {
  trade_date: string;
  symbol: string;
  direction: 'buy' | 'sell';
  timeframe: string;
  session: string;
  market_condition: string;
  entry_time: string;
  exit_time: string;
  entry_price: string;
  exit_price: string;
  stop_loss: string;
  take_profit: string;
  lot_size: string;
  contract_size: string;
  capital_before: string;
  commission: string;
  swap: string;
  risk_percent: string;
  auto_lot_sizing: boolean;
  risk_mode: 'percent' | 'amount';
  risk_input_value: string;
  result: string;
  strategy_id: string;
  setup_id: string;
  entry_reason: string;
  exit_reason: string;
  feeling_before: string;
  feeling_during: string;
  feeling_after: string;
  psychology_tags: string[];
  mistakes: string;
  lessons: string;
  notes: string;
  trend: string;
  is_open: boolean;
};

type Calculated = {
  risk_amount: number | null;
  risk_percent: number | null;
  potential_profit: number | null;
  rr_ratio: number | null;
  pnl_amount: number | null;
  gross_pnl_amount: number | null;
  pnl_percent: number | null;
  capital_after: number | null;
  r_multiple: number | null;
  duration_minutes: number | null;
};

export default function TradeForm() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const { id } = useParams<{ id?: string }>();
  const isEdit = Boolean(id);

  const [strategies, setStrategies] = useState<any[]>([]);
  const [setups, setSetups] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [createdTradeId, setCreatedTradeId] = useState<string | null>(null);
  const [calc, setCalc] = useState<Calculated>({
    risk_amount: null, risk_percent: null, potential_profit: null,
    rr_ratio: null, pnl_amount: null, gross_pnl_amount: null, pnl_percent: null,
    capital_after: null, r_multiple: null, duration_minutes: null
  });
  const [customSymbol, setCustomSymbol] = useState('');
  const exitFocusRequested = isEdit && typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('focus') === 'exit';

  const { register, handleSubmit, watch, setValue, getValues, control, reset, formState: { errors } } = useForm<FormValues>({
    defaultValues: {
      trade_date: toGregorianDateInput(),
      symbol: 'XAUUSD',
      direction: 'buy',
      contract_size: '100',
      capital_before: String(profile?.current_capital ?? 0),
      commission: '0',
      swap: '0',
      psychology_tags: [],
      is_open: exitFocusRequested ? false : true,
      auto_lot_sizing: true,
      risk_mode: 'percent',
      risk_input_value: '0.5',
    }
  });

  const commissionField = register('commission');

  const watchedFields = useWatch({
    control,
    name: ['entry_price', 'exit_price', 'stop_loss', 'take_profit', 'lot_size', 'contract_size', 'capital_before', 'direction', 'symbol', 'entry_time', 'exit_time', 'trade_date', 'commission', 'swap'],
  });

  const symbolValue = useWatch({ control, name: 'symbol' });
  const autoLotSizing = useWatch({ control, name: 'auto_lot_sizing' });
  const riskMode = useWatch({ control, name: 'risk_mode' });
  const isOpen = useWatch({ control, name: 'is_open' });
  const exitTimeValue = useWatch({ control, name: 'exit_time' });
  const exitPriceValue = useWatch({ control, name: 'exit_price' });
  const entryPriceValue = useWatch({ control, name: 'entry_price' });
  const stopLossValue = useWatch({ control, name: 'stop_loss' });
  const takeProfitValue = useWatch({ control, name: 'take_profit' });
  const riskInputValue = useWatch({ control, name: 'risk_input_value' });
  const capitalBeforeValue = useWatch({ control, name: 'capital_before' });
  const lotSizeValue = useWatch({ control, name: 'lot_size' });
  const selectedStrategyId = useWatch({ control, name: 'strategy_id' });
  const selectedPsychologyTags = useWatch({ control, name: 'psychology_tags' });
  const selectedStrategy = useMemo(() => strategies.find(s => s.id === selectedStrategyId), [strategies, selectedStrategyId]);
  // A strategy's rule_config defaults to `{}` in the database (not null), which
  // is truthy — so `cfg || parseLegacyRules(...)` would never fall back to the
  // legacy free-text rules for any strategy not yet re-saved through the new
  // rule editor. Treat an object with no meaningfully-set field as "not
  // configured" so the fallback actually runs.
  const strategyRuleConfig = useMemo(() => {
    const cfg = selectedStrategy?.rule_config;
    const hasStructuredRules = !!cfg && Object.values(cfg).some(
      v => v !== undefined && v !== null && !(Array.isArray(v) && v.length === 0)
    );
    return hasStructuredRules ? cfg : parseLegacyRules(selectedStrategy?.rules);
  }, [selectedStrategy]);
  const ruleViolations = useMemo(() => evaluateStrategyRules(strategyRuleConfig, {
    session: watch('session'), direction: watch('direction'), timeframe: watch('timeframe'), symbol: symbolValue === 'custom' ? customSymbol : symbolValue,
    market_condition: watch('market_condition'), rr_ratio: calc.rr_ratio, risk_percent: calc.risk_percent, stop_loss: Number(stopLossValue) || null, take_profit: Number(takeProfitValue) || null,
    entry_reason: watch('entry_reason'), psychology_tags: selectedPsychologyTags || []
  }), [strategyRuleConfig, selectedStrategyId, watch('session'), watch('direction'), watch('timeframe'), symbolValue, customSymbol, watch('market_condition'), calc.rr_ratio, calc.risk_percent, stopLossValue, takeProfitValue, watch('entry_reason'), selectedPsychologyTags]);
  const blockingRuleViolations = ruleViolations.filter(v => v.severity === 'block');

  const riskPolicy = useMemo(() => { const capital = Number(capitalBeforeValue) || 0; const input = Number(riskInputValue) || 0; const targetAmount = riskMode === 'amount' ? input : capital > 0 ? capital * input / 100 : 0; return { ...getExecutionRiskBand(capital, calc.risk_amount), targetAmount }; }, [capitalBeforeValue, calc.risk_amount, riskMode, riskInputValue]);

  const riskStatus = useMemo(() => {
    const actual = calc.risk_amount;
    if (actual === null || !Number.isFinite(actual) || Number(capitalBeforeValue) <= 0) return { key:'unknown', label:'سرمایه، ورود و حد ضرر را مشخص کن.', tone:'neutral' as const };
    if (riskPolicy.blocks) return { key:'blocked', label:'🔴 ریسک بیش از سقف ۱٫۱٪؛ ثبت معامله مسدود است.', tone:'danger' as const };
    if (riskPolicy.key==='half_percent') return { key:'valid', label:'🟢 داخل باند عالی ۰٫۵٪', tone:'success' as const };
    if (riskPolicy.key==='one_percent') return { key:'valid', label:'🟢 داخل باند عالی ۱٪', tone:'success' as const };
    if (riskPolicy.key==='transition') return { key:'transition', label:'🟡 بین دو باند استاندارد؛ بررسی کن.', tone:'warning' as const };
    return { key:'under', label:'🟡 کمتر از باند استاندارد؛ آگاهانه بررسی کن.', tone:'warning' as const };
  }, [calc.risk_amount, riskPolicy, capitalBeforeValue]);

  // When opening the edit form from 'بستن معامله', keep the exit fields visible.
  // Query-string based navigation avoids depending on router location state.
  useEffect(() => {
    if (!exitFocusRequested || !isEdit) return;
    setValue('is_open', false, { shouldDirty: false });
  }, [exitFocusRequested, isEdit, setValue]);

  useEffect(() => {
    if (!exitFocusRequested || !isEdit || isOpen) return;
    const frame = window.requestAnimationFrame(() => {
      const section = document.getElementById('trade-exit-section');
      if (!section) return;
      section.scrollIntoView({ behavior: 'auto', block: 'center' });
      const input = section.querySelector<HTMLInputElement>('input[type=number]');
      if (input) input.focus({ preventScroll: true });
    });
    return () => window.cancelAnimationFrame(frame);
  }, [exitFocusRequested, isEdit, isOpen]);

  // Closing rule: on an edit of an open trade, entering an actual exit
  // price or exit time is treated as a close action. This prevents a common
  // failure mode where the user fills the exit fields but forgets to toggle
  // the status from OPEN to CLOSED.
  useEffect(() => {
    if (!isEdit) return;
    if ((exitPriceValue || exitTimeValue) && isOpen) {
      setValue('is_open', false, { shouldDirty: true });
    }
  }, [isEdit, exitPriceValue, exitTimeValue, isOpen, setValue]);

  // Auto-calculate
  useEffect(() => {
    const [entryP, exitP, slP, tpP, lotP, csP, capP, dir, sym, entryT, exitT, tradeDate, commissionP, swapP] = watchedFields;
    const entry = parseFloat(entryP);
    const exit = parseFloat(exitP);
    const sl = parseFloat(slP);
    const tp = parseFloat(tpP);
    const lot = parseFloat(lotP);
    const cs = parseFloat(csP) || getContractSize(sym || 'XAUUSD');
    const cap = parseFloat(capP);

    if (!entry || !lot) {
      setCalc({ risk_amount: null, risk_percent: null, potential_profit: null, rr_ratio: null, pnl_amount: null, gross_pnl_amount: null, pnl_percent: null, capital_after: null, r_multiple: null, duration_minutes: null });
      return;
    }

    const result = calculateTradeMetrics({
      symbol: sym || 'XAUUSD',
      direction: (dir || 'buy') as 'buy' | 'sell',
      entryPrice: entry,
      exitPrice: isNaN(exit) ? undefined : exit,
      stopLoss: isNaN(sl) ? undefined : sl,
      takeProfit: isNaN(tp) ? undefined : tp,
      lotSize: lot,
      contractSize: cs,
      capitalBefore: isNaN(cap) ? undefined : cap,
      entryTime: entryT && tradeDate ? combineDateAndTimeLocal(tradeDate, entryT) || undefined : undefined,
      exitTime: exitT && tradeDate ? combineDateAndTimeLocal(tradeDate, exitT) || undefined : undefined,
      commission: parseFloat(commissionP) || 0,
      swap: parseFloat(swapP) || 0,
    });

    setCalc({
      risk_amount: result.risk_amount ?? null,
      risk_percent: result.risk_percent ?? null,
      potential_profit: result.potential_profit ?? null,
      rr_ratio: result.rr_ratio ?? null,
      pnl_amount: result.pnl_amount ?? null,
      gross_pnl_amount: result.gross_pnl_amount ?? null,
      pnl_percent: result.pnl_percent ?? null,
      capital_after: result.capital_after ?? null,
      r_multiple: result.r_multiple ?? null,
      duration_minutes: result.duration_minutes ?? null,
    });
  }, watchedFields);

  // Auto-set contract size when symbol changes
  useEffect(() => {
    const sym = symbolValue;
    if (sym && sym !== 'custom') {
      setValue('contract_size', String(getContractSize(sym)));
    }
  }, [symbolValue, setValue]);

  // Position size calculator: given entry, stop loss, and desired risk (% or $), auto-fill lot size
  const sizingFields = useWatch({
    control,
    name: ['entry_price', 'stop_loss', 'contract_size', 'capital_before', 'auto_lot_sizing', 'risk_mode', 'risk_input_value', 'symbol'],
  });

  useEffect(() => {
    const [entryP, slP, csP, capP, autoSizing, riskMode, riskInputP, sym] = sizingFields;
    if (!autoSizing) return;

    const entry = parseFloat(entryP);
    const sl = parseFloat(slP);
    const cs = parseFloat(csP) || getContractSize((sym as string) || 'XAUUSD');
    const cap = parseFloat(capP);
    const riskInput = parseFloat(riskInputP as string);

    if (!entry || !sl || entry === sl || !riskInput || riskInput <= 0) return;

    const riskAmount = riskMode === 'percent'
      ? (cap > 0 ? (cap * riskInput) / 100 : NaN)
      : riskInput;

    if (!riskAmount || isNaN(riskAmount) || riskAmount <= 0) return;

    const priceDistance = Math.abs(entry - sl);
    const computedLot = riskAmount / (priceDistance * cs);

    if (isFinite(computedLot) && computedLot > 0) {
      // Auto sizing always rounds DOWN to the nearest broker-valid 0.01 lot
      // so the actual risk can never exceed the requested risk just because of rounding.
      const normalizedLot = normalizeLotSize(computedLot, 'floor');
      if (normalizedLot) {
        setValue('lot_size', formatLotSize(normalizedLot), { shouldValidate: false });
      }
      if (riskMode === 'amount' && cap > 0) {
        setValue('risk_percent', ((riskAmount / cap) * 100).toFixed(2));
      } else if (riskMode === 'percent') {
        setValue('risk_percent', riskInputP as string);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, sizingFields);

  // Load strategies, setups, accounts
  const [maxRiskPercent, setMaxRiskPercent] = useState(1);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [commissionRatePerLot, setCommissionRatePerLot] = useState<number | null>(null);
  const [commissionRateSource, setCommissionRateSource] = useState<'symbol' | 'account' | null>(null);
  const [commissionAutoEnabled, setCommissionAutoEnabled] = useState(false);
  useEffect(() => {
    if (!user) return;
    Promise.all([
      supabase.from('strategies').select('*').eq('user_id', user.id).eq('is_active', true),
      supabase.from('setups').select('*').eq('user_id', user.id),
      supabase.from('accounts').select('*').eq('user_id', user.id).eq('is_active', true).order('created_at', { ascending: true }),
      supabase.from('risk_settings').select('max_risk_per_trade').eq('user_id', user.id).eq('is_active', true).limit(1).maybeSingle(),
    ]).then(([{ data: strats }, { data: sups }, { data: accs }, { data: risk }]) => {
      if (strats) setStrategies(strats);
      if (sups) setSetups(sups);
      if (accs) setAccounts(accs);
      if (risk?.max_risk_per_trade) setMaxRiskPercent(Number(risk.max_risk_per_trade));
      // Default to the first (oldest) active account — only when creating a
      // new trade and nothing was already picked (e.g. loaded from an edit).
      if (accs && accs.length > 0 && !isEdit && !selectedAccountId) {
        const preferred = getActiveAccountId();
        const chosen = preferred ? accs.find(a => a.id === preferred) : null;
        const targetAccount = chosen || accs[0];
        setSelectedAccountId(targetAccount.id);
        setValue('capital_before', String(targetAccount.current_balance));
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Keep capital_before in sync with whichever account is selected (new trade only)
  useEffect(() => {
    if (isEdit || !selectedAccountId) return;
    const acc = accounts.find(a => a.id === selectedAccountId);
    if (acc) setValue('capital_before', String(acc.current_balance));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedAccountId]);

  // Learn the broker's commission-per-lot from the first journal entry with a real commission for this account/symbol.
  // No extra database column is required: the rate is derived from existing commission + lot_size data.
  useEffect(() => {
    if (!user || isEdit || !selectedAccountId) {
      setCommissionRatePerLot(null);
      setCommissionRateSource(null);
      setCommissionAutoEnabled(false);
      return;
    }

    const effectiveSymbol = symbolValue === 'custom' ? customSymbol.trim() : symbolValue;
    if (!effectiveSymbol) {
      setCommissionRatePerLot(null);
      setCommissionRateSource(null);
      setCommissionAutoEnabled(false);
      return;
    }

    let cancelled = false;
    (async () => {
      const { data: sameSymbol } = await supabase
        .from('trades')
        .select('commission, lot_size, created_at')
        .eq('user_id', user.id)
        .eq('account_id', selectedAccountId)
        .eq('symbol', effectiveSymbol)
        .gt('commission', 0)
        .gt('lot_size', 0)
        .order('created_at', { ascending: true })
        .limit(1)
        .maybeSingle();

      let source = sameSymbol;
      if (!source) {
        const { data: accountLatest } = await supabase
          .from('trades')
          .select('commission, lot_size, created_at')
          .eq('user_id', user.id)
          .eq('account_id', selectedAccountId)
          .gt('commission', 0)
          .gt('lot_size', 0)
          .order('created_at', { ascending: true })
          .limit(1)
          .maybeSingle();
        source = accountLatest;
      }

      const rate = source && Number(source.lot_size) > 0
        ? roundMoney(Number(source.commission) / Number(source.lot_size))
        : null;

      if (cancelled) return;
      if (rate && rate > 0) {
        setCommissionRatePerLot(rate);
        setCommissionRateSource(sameSymbol ? 'symbol' : 'account');
        setCommissionAutoEnabled(true);
      } else {
        setCommissionRatePerLot(null);
        setCommissionRateSource(null);
        setCommissionAutoEnabled(false);
      }
    })();

    return () => { cancelled = true; };
  }, [user, isEdit, selectedAccountId, symbolValue, customSymbol]);

  // Once a commission rate is known, keep the commission field synchronized with the valid lot size.
  useEffect(() => {
    if (isEdit || !commissionAutoEnabled || !commissionRatePerLot) return;
    const lot = normalizeLotSize(Number(lotSizeValue));
    if (!lot) return;
    const nextCommission = roundMoney(commissionRatePerLot * lot);
    if (nextCommission !== null) {
      setValue('commission', nextCommission.toFixed(2), { shouldDirty: false });
    }
  }, [isEdit, commissionAutoEnabled, commissionRatePerLot, lotSizeValue, setValue]);

  // No-trade window check (only meaningful for a fresh trade — an edit isn't "right now")
  const [noTradeWarning, setNoTradeWarning] = useState<string | null>(null);
  useEffect(() => {
    if (!user || isEdit) return;
    supabase.from('no_trade_windows').select('label, day_of_week, start_time, end_time, is_active').eq('user_id', user.id).eq('is_active', true)
      .then(({ data }) => {
        if (data) setNoTradeWarning(checkNoTradeWindow(data, new Date()));
      });
  }, [user, isEdit]);

  // Load templates (new-trade mode only)
  const [templates, setTemplates] = useState<any[]>([]);
  const [showTemplateBar, setShowTemplateBar] = useState(false);
  const [showSaveTemplate, setShowSaveTemplate] = useState(false);
  const [templateName, setTemplateName] = useState('');
  const [duplicating, setDuplicating] = useState(false);
  const [showAdvancedRisk, setShowAdvancedRisk] = useState(false);

  const loadTemplates = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('trade_templates').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    setTemplates(data || []);
  }, [user]);

  useEffect(() => { if (!isEdit) loadTemplates(); }, [isEdit, loadTemplates]);

  const applyFieldSet = (t: {
    symbol?: string | null; direction?: string | null; timeframe?: string | null; session?: string | null;
    market_condition?: string | null; strategy_id?: string | null; setup_id?: string | null;
    contract_size?: number | string | null; risk_mode?: string | null; risk_input_value?: number | string | null;
    entry_reason?: string | null;
  }) => {
    if (t.symbol) setValue('symbol', SYMBOLS.includes(t.symbol) ? t.symbol : 'custom');
    if (t.symbol && !SYMBOLS.includes(t.symbol)) setCustomSymbol(t.symbol);
    if (t.direction) setValue('direction', t.direction as 'buy' | 'sell');
    if (t.timeframe) setValue('timeframe', t.timeframe);
    if (t.session) setValue('session', t.session);
    if (t.market_condition) setValue('market_condition', t.market_condition);
    if (t.strategy_id) setValue('strategy_id', t.strategy_id);
    if (t.setup_id) setValue('setup_id', t.setup_id);
    if (t.contract_size) setValue('contract_size', String(t.contract_size));
    if (t.risk_mode) setValue('risk_mode', t.risk_mode as 'percent' | 'amount');
    if (t.risk_input_value) setValue('risk_input_value', String(t.risk_input_value));
    if (t.entry_reason) setValue('entry_reason', t.entry_reason);
  };

  const applyTemplate = (templateId: string) => {
    const t = templates.find(x => x.id === templateId);
    if (t) applyFieldSet(t);
  };

  const handleDuplicateLastTrade = async () => {
    if (!user) return;
    setDuplicating(true);
    const { data } = await supabase
      .from('trades').select('*').eq('user_id', user.id)
      .order('created_at', { ascending: false }).limit(1).maybeSingle();
    setDuplicating(false);
    if (!data) return;
    applyFieldSet({
      symbol: data.symbol, direction: data.direction, timeframe: data.timeframe, session: data.session,
      market_condition: data.market_condition, strategy_id: data.strategy_id, setup_id: data.setup_id,
      contract_size: data.contract_size, risk_mode: 'percent', risk_input_value: data.risk_percent,
    });
  };

  const handleSaveTemplate = async () => {
    if (!user || !templateName.trim()) return;
    const v = getValues();
    const sym = v.symbol === 'custom' ? customSymbol : v.symbol;
    await supabase.from('trade_templates').insert({
      user_id: user.id,
      name: templateName.trim(),
      symbol: sym || null,
      direction: v.direction || null,
      timeframe: v.timeframe || null,
      session: v.session || null,
      market_condition: v.market_condition || null,
      strategy_id: v.strategy_id || null,
      setup_id: v.setup_id || null,
      contract_size: parseFloat(v.contract_size) || null,
      risk_mode: v.risk_mode || 'percent',
      risk_input_value: parseFloat(v.risk_input_value) || null,
      entry_reason: v.entry_reason || null,
    });
    setTemplateName('');
    setShowSaveTemplate(false);
    loadTemplates();
  };

  const handleDeleteTemplate = async (templateId: string) => {
    if (!user) return;
    await supabase.from('trade_templates').delete().eq('id', templateId).eq('user_id', user.id);
    loadTemplates();
  };

  // Load trade data if editing
  useEffect(() => {
    if (!isEdit || !id || !user) return;
    supabase.from('trades').select('*').eq('id', id).eq('user_id', user.id).maybeSingle().then(({ data }) => {
      if (!data) return;
      reset({
        trade_date: data.trade_date,
        symbol: SYMBOLS.includes(data.symbol) ? data.symbol : 'custom',
        direction: data.direction,
        auto_lot_sizing: false,
        risk_mode: 'percent',
        risk_input_value: String(data.risk_percent || '1'),
        timeframe: data.timeframe || '',
        session: data.session || '',
        market_condition: data.market_condition || '',
        entry_time: getTradeTimeInput(data.entry_time),
        exit_time: getTradeTimeInput(data.exit_time),
        entry_price: String(data.entry_price || ''),
        exit_price: String(data.exit_price || ''),
        stop_loss: String(data.stop_loss || ''),
        take_profit: String(data.take_profit || ''),
        lot_size: formatLotSize(Number(data.lot_size)),
        contract_size: String(data.contract_size || 100),
        capital_before: String(data.capital_before || ''),
        commission: String(data.commission ?? 0),
        swap: String(data.swap ?? 0),
        result: data.result || '',
        strategy_id: data.strategy_id || '',
        setup_id: data.setup_id || '',
        entry_reason: data.entry_reason || '',
        exit_reason: data.exit_reason || '',
        feeling_before: data.feeling_before || '',
        feeling_during: data.feeling_during || '',
        feeling_after: data.feeling_after || '',
        psychology_tags: data.psychology_tags || [],
        mistakes: data.mistakes || '',
        lessons: data.lessons || '',
        notes: data.notes || '',
        trend: data.trend || '',
        is_open: exitFocusRequested ? false : Boolean(data.is_open),
        risk_percent: String(data.risk_percent || ''),
      });
      if (data.account_id) setSelectedAccountId(data.account_id);
      if (!SYMBOLS.includes(data.symbol)) setCustomSymbol(data.symbol);
    });
  }, [isEdit, id, user]);

  const onSubmit = async (data: FormValues) => {
    if (!user) return;
    setSaving(true);
    setError(null);

    const capitalBefore = Number(data.capital_before) || 0;
    if (!isEdit && capitalBefore <= 0) { setSaving(false); setError('ابتدا سرمایه اولیه حساب را در تنظیمات تعیین کن.'); return; }
    if (!data.entry_price || !data.stop_loss) { setSaving(false); setError('قیمت ورود و حد ضرر برای محاسبه ریسک الزامی هستند.'); return; }
    if (!data.lot_size) { setSaving(false); setError('حجم معامله محاسبه نشده است؛ سرمایه، ورود، حد ضرر و مقدار ریسک را بررسی کن.'); return; }

    // Risk Guard: only the two defined execution bands are considered standard.
    if (blockingRuleViolations.length > 0) {
      setError(`معامله با قوانین استراتژی انتخاب‌شده مغایرت دارد: ${blockingRuleViolations.map(v => v.title).join('، ')}`);
      setSaving(false);
      return;
    }
    const actualRisk = calc.risk_amount;
    if (actualRisk !== null && getExecutionRiskBand(Number(data.capital_before) || 0, actualRisk).blocks) {
      setSaving(false);
      setError(`ریسک واقعی ${formatCurrency(actualRisk)} از سقف مجاز ۱٫۱٪ عبور کرده است.`);
      return;
    }

    try {
      const sym = data.symbol === 'custom' ? customSymbol : data.symbol;
      const pnl = calc.pnl_amount;
      // A trade is closed only when an exit point is supplied. The exit timestamp
      // may be optional for legacy rows, but when the user explicitly enters an
      // exit price/time, the stored state must never remain `open`.
      const hasExitPrice = Boolean(data.exit_price);
      const hasExitTime = Boolean(data.exit_time);
      const hasExitData = hasExitPrice || hasExitTime;
      const effectiveIsOpen = Boolean(data.is_open && !hasExitData);

      if (!effectiveIsOpen && !hasExitPrice && !hasExitTime && !isEdit) {
        throw new Error('برای معامله بسته، قیمت یا زمان خروج را وارد کن.');
      }
      const computedResult = pnl !== null ? determineResult(pnl) : null;
      const result = effectiveIsOpen
        ? 'open'
        : (computedResult ?? (data.result && data.result !== 'open' ? data.result : 'breakeven'));
      const processScore = estimateProcessScore({
        result,
        pnl_amount: calc.pnl_amount,
        r_multiple: calc.r_multiple,
        trade_date: data.trade_date,
        psychology_tags: data.psychology_tags || [],
        risk_percent: calc.risk_percent,
        mistakes: data.mistakes || null,
      }, maxRiskPercent * 1.1);
      const reviewCompleted = isTradeReviewComplete({
        is_open: effectiveIsOpen,
        exit_reason: data.exit_reason,
        mistakes: data.mistakes,
        lessons: data.lessons,
        feeling_after: data.feeling_after,
      });

      const payload: any = {
        user_id: user.id,
        trade_date: data.trade_date,
        symbol: sym,
        direction: data.direction,
        timeframe: data.timeframe || null,
        session: data.session || null,
        market_condition: data.market_condition || null,
        entry_time: data.entry_time ? combineTradeDateTime(data.trade_date, data.entry_time) : null,
        exit_time: data.exit_time ? combineTradeDateTime(data.trade_date, data.exit_time) : null,
        entry_price: parseFloat(data.entry_price) || null,
        exit_price: parseFloat(data.exit_price) || null,
        stop_loss: parseFloat(data.stop_loss) || null,
        take_profit: parseFloat(data.take_profit) || null,
        lot_size: normalizeLotSize(parseFloat(data.lot_size), 'nearest'),
        contract_size: parseFloat(data.contract_size) || 100,
        capital_before: parseFloat(data.capital_before) || null,
        account_id: selectedAccountId || accounts[0]?.id || null,
        strategy_id: data.strategy_id || null,
        setup_id: data.setup_id || null,
        entry_reason: data.entry_reason || null,
        exit_reason: data.exit_reason || null,
        feeling_before: data.feeling_before || null,
        feeling_during: data.feeling_during || null,
        feeling_after: data.feeling_after || null,
        psychology_tags: data.psychology_tags?.length ? data.psychology_tags : null,
        mistakes: data.mistakes || null,
        lessons: data.lessons || null,
        notes: data.notes || null,
        trend: data.trend || null,
        is_open: effectiveIsOpen,
        result,
        // Calculated fields
        risk_amount: calc.risk_amount,
        risk_percent: calc.risk_percent,
        potential_profit: calc.potential_profit,
        rr_ratio: calc.rr_ratio,
        pnl_amount: calc.pnl_amount,
        gross_pnl_amount: calc.gross_pnl_amount,
        commission: parseFloat(data.commission) || 0,
        swap: parseFloat(data.swap) || 0,
        pnl_percent: calc.pnl_percent,
        capital_after: calc.capital_after,
        r_multiple: calc.r_multiple,
        duration_minutes: calc.duration_minutes,
        // Persist the canonical process/review state so every analytics screen
        // reads real data rather than silently operating on NULLs.
        process_score: processScore,
        review_completed: reviewCompleted,
      };

      if (isEdit) {
        const { error: err } = await supabase.from('trades').update(payload).eq('id', id).eq('user_id', user.id);
        if (err) throw err;
        // Update the balance of the account this trade actually belongs to
        const targetAccountId = selectedAccountId || accounts[0]?.id;
        if (calc.capital_after !== null && targetAccountId) {
          await supabase.from('accounts').update({ current_balance: calc.capital_after }).eq('id', targetAccountId);
        }
      } else {
        const { data: inserted, error: err } = await supabase.from('trades').insert(payload).select('id').single();
        if (err) throw err;
        // Update the balance of the account this trade actually belongs to
        const targetAccountId = selectedAccountId || accounts[0]?.id;
        if (calc.capital_after !== null && targetAccountId) {
          await supabase.from('accounts').update({ current_balance: calc.capital_after }).eq('id', targetAccountId);
        }
        setSuccess(true);
        setCreatedTradeId(inserted.id);
        return;
      }

      setSuccess(true);
      setTimeout(() => navigate('/history'), 1200);
    } catch (e: any) {
      const err = e as { message?: string; code?: string; details?: string };
      setError([err.message, err.code ? `کد ${err.code}` : '', err.details || ''].filter(Boolean).join(' · ') || 'خطا در ذخیره معامله');
    } finally {
      setSaving(false);
    }
  };

  const selectedPsychTags = watch('psychology_tags') || [];
  const togglePsychTag = (tag: string) => {
    const current = watch('psychology_tags') || [];
    const updated = current.includes(tag) ? current.filter(t => t !== tag) : [...current, tag];
    setValue('psychology_tags', updated);
  };

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <Calculator className="w-5 h-5 text-gold-400" />
          {isEdit ? 'ویرایش معامله' : 'ثبت معامله جدید'}
        </h1>
        <button onClick={() => navigate(-1)} className="btn-secondary p-2 !px-2">
          <X className="w-4 h-4" />
        </button>
      </div>

      {!isEdit && (
        <div className="glass-card p-3 flex items-center gap-2 flex-wrap">
          <span className="text-xs text-dark-400 flex items-center gap-1 flex-shrink-0">
            <Layers className="w-3.5 h-3.5 text-gold-400" /> شروع سریع:
          </span>
          <button
            type="button"
            onClick={handleDuplicateLastTrade}
            disabled={duplicating}
            className="btn-secondary text-xs py-1.5 px-2.5 flex items-center gap-1"
          >
            <Copy className="w-3.5 h-3.5" /> {duplicating ? 'در حال بارگذاری...' : 'کپی آخرین معامله'}
          </button>

          {templates.length > 0 && (
            <select
              onChange={e => { if (e.target.value) applyTemplate(e.target.value); e.target.value = ''; }}
              className="select-field w-auto text-xs py-1.5"
              defaultValue=""
            >
              <option value="" disabled>استفاده از قالب...</option>
              {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          )}

          <button
            type="button"
            onClick={() => setShowSaveTemplate(true)}
            className="btn-secondary text-xs py-1.5 px-2.5 flex items-center gap-1"
          >
            <Bookmark className="w-3.5 h-3.5" /> ذخیره به‌عنوان قالب
          </button>

          {templates.length > 0 && (
            <button
              type="button"
              onClick={() => setShowTemplateBar(s => !s)}
              className="text-xs text-dark-400 hover:text-white mr-auto"
            >
              مدیریت قالب‌ها
            </button>
          )}
        </div>
      )}

      {showTemplateBar && templates.length > 0 && (
        <div className="glass-card p-3 space-y-1.5">
          {templates.map(t => (
            <div key={t.id} className="flex items-center justify-between text-xs bg-dark-900/60 rounded-lg px-3 py-2">
              <span className="text-dark-200">{t.name}</span>
              <button type="button" onClick={() => handleDeleteTemplate(t.id)} className="text-dark-400 hover:text-danger-400">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {showSaveTemplate && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm space-y-4" dir="rtl">
            <h3 className="text-lg font-semibold text-white">ذخیره به‌عنوان قالب</h3>
            <div>
              <label className="label-text">نام قالب</label>
              <input
                type="text" value={templateName} onChange={e => setTemplateName(e.target.value)}
                className="input-field" placeholder="مثلاً: طلا - شکست ساختار - لندن" autoFocus
              />
            </div>
            <p className="text-[11px] text-dark-500">نماد، جهت، تایم‌فریم، سشن، استراتژی، ست‌آپ و تنظیمات ریسک فعلی ذخیره می‌شود.</p>
            <div className="flex gap-3 justify-end pt-1">
              <button type="button" onClick={() => setShowSaveTemplate(false)} className="btn-secondary">انصراف</button>
              <button type="button" onClick={handleSaveTemplate} disabled={!templateName.trim()} className="btn-primary">ذخیره</button>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 p-3 bg-danger-500/10 border border-danger-500/20 rounded-lg text-danger-400 text-sm">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}
      {success && (
        <div className="flex items-center gap-2 p-3 bg-success-500/10 border border-success-500/20 rounded-lg text-success-400 text-sm">
          <CheckCircle className="w-4 h-4 flex-shrink-0" />
          معامله ذخیره شد. حالا می‌توانی تصاویر قبل، حین و بعد معامله را همین‌جا اضافه کنی.
        </div>
      )}

      {Number(capitalBeforeValue) <= 0 && !isEdit && (
        <div className="glass-card p-4 border border-warning-500/20 bg-warning-500/[0.04]">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-warning-400 shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-warning-300">ابتدا سرمایه اولیه را تعیین کن</p>
              <p className="text-xs text-dark-400 mt-1">حساب تازه با $0 شروع می‌شود؛ برای محاسبه حجم و ریسک و ثبت معامله، سرمایه اولیه را در تنظیمات حساب انتخاب کن.</p>
              <button type="button" onClick={() => navigate('/settings')} className="btn-secondary text-xs mt-3">رفتن به تنظیمات حساب</button>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {!isEdit && accounts.length > 1 && (
          <div className="glass-card p-3">
            <label className="label-text">حساب</label>
            <select
              value={selectedAccountId}
              onChange={e => setSelectedAccountId(e.target.value)}
              className="select-field"
            >
              {accounts.map(a => <option key={a.id} value={a.id}>{a.name}{a.broker ? ` — ${a.broker}` : ''}</option>)}
            </select>
          </div>
        )}
        {/* Section 1: Basic Info */}
        <Section title="اطلاعات پایه">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <label className="label-text">نماد</label>
              <select {...register('symbol')} className="select-field">
                {SYMBOLS.map(s => <option key={s} value={s}>{s}</option>)}
                <option value="custom">— دیگر —</option>
              </select>
            </div>
            {symbolValue === 'custom' && (
              <div>
                <label className="label-text">نماد دلخواه</label>
                <input
                  type="text"
                  value={customSymbol}
                  onChange={e => setCustomSymbol(e.target.value.toUpperCase())}
                  className="input-field"
                  placeholder="USDCAD"
                />
              </div>
            )}
            <div>
              <label className="label-text">جهت معامله</label>
              <select {...register('direction')} className="select-field">
                <option value="buy">▲ خرید (Buy)</option>
                <option value="sell">▼ فروش (Sell)</option>
              </select>
            </div>
            <div>
              <label className="label-text">تایم‌فریم</label>
              <select {...register('timeframe')} className="select-field">
                <option value="">انتخاب کنید</option>
                {TIMEFRAMES.map(t => <option key={t} value={t}>{TF_LABELS[t]}</option>)}
              </select>
            </div>
            <div>
              <label className="label-text">سشن</label>
              <select {...register('session')} className="select-field">
                <option value="">انتخاب کنید</option>
                {SESSIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>
            <div>
              <label className="label-text">شرایط بازار</label>
              <select {...register('market_condition')} className="select-field">
                <option value="">انتخاب کنید</option>
                {CONDITIONS.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </div>
            <div>
              <label className="label-text">روند</label>
              <select {...register('trend')} className="select-field">
                <option value="">انتخاب کنید</option>
                <option value="up">صعودی</option>
                <option value="down">نزولی</option>
                <option value="sideways">خنثی</option>
              </select>
            </div>
          </div>
        </Section>

        {/* Section 2: Trade Command Center */}
        <Section title="مرکز اجرای معامله">
          <div className="space-y-4">
            {/* Trade state */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 rounded-2xl border border-white/10 bg-dark-900/60 p-3">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isOpen ? 'bg-success-500/10 text-success-400' : 'bg-gold-500/10 text-gold-400'}`}>
                  {isOpen ? <ArrowUpFromLine className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">{isOpen ? 'باز کردن معامله' : 'ثبت معامله بسته‌شده'}</p>
                  <p className="text-[11px] text-dark-400">{isOpen ? 'فعلاً فقط اطلاعات لازم برای ورود را ثبت کن؛ خروج را بعداً اضافه می‌کنی.' : 'اطلاعات ورود و خروج را هم‌زمان ثبت می‌کنی.'}</p>
                </div>
              </div>
              <div className="flex items-center gap-1 bg-dark-950/70 border border-white/10 rounded-xl p-1 w-full lg:w-auto">
                <button type="button" onClick={() => setValue('is_open', true)} className={`flex-1 lg:flex-none px-4 py-2 rounded-lg text-xs font-medium transition-all ${isOpen ? 'bg-success-500/15 text-success-400 shadow-sm' : 'text-dark-400 hover:text-white'}`}>
                  معامله باز
                </button>
                <button type="button" onClick={() => setValue('is_open', false)} className={`flex-1 lg:flex-none px-4 py-2 rounded-lg text-xs font-medium transition-all ${!isOpen ? 'bg-gold-500/15 text-gold-400 shadow-sm' : 'text-dark-400 hover:text-white'}`}>
                  بسته‌شده
                </button>
              </div>
            </div>

            {/* Context row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="rounded-xl bg-dark-900/50 border border-white/5 px-3 py-2">
                <p className="text-[10px] text-dark-500">نماد</p>
                <p className="text-sm font-semibold text-white number-ltr">{symbolValue === 'custom' ? customSymbol || '—' : symbolValue}</p>
              </div>
              <div className="rounded-xl bg-dark-900/50 border border-white/5 px-3 py-2">
                <p className="text-[10px] text-dark-500">جهت</p>
                <p className={`text-sm font-semibold ${watch('direction') === 'buy' ? 'text-success-400' : 'text-danger-400'}`}>{watch('direction') === 'buy' ? 'خرید' : 'فروش'}</p>
              </div>
              <div className="rounded-xl bg-dark-900/50 border border-white/5 px-3 py-2">
                <p className="text-[10px] text-dark-500">تایم‌فریم</p>
                <p className="text-sm font-semibold text-white number-ltr">{TF_LABELS[watch('timeframe')] || watch('timeframe') || '—'}</p>
              </div>
              <div className="rounded-xl bg-dark-900/50 border border-white/5 px-3 py-2">
                <p className="text-[10px] text-dark-500">زمان ورود</p>
                <p className="text-sm font-semibold text-white number-ltr">{watch('entry_time') || '—'}</p>
              </div>
            </div>

            {/* Three decision inputs */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <PriceInput label="نقطه ورود" hint="قیمت اجرای معامله" required value={entryPriceValue} register={register('entry_price', { required: 'قیمت ورود را وارد کن' })} accent="gold" placeholder="3342.50" />
              <PriceInput label="حد ضرر" hint="نقطه بی‌اعتبار شدن تحلیل" required value={stopLossValue} register={register('stop_loss', { required: 'حد ضرر را وارد کن' })} accent="danger" placeholder="3348.00" />
              <PriceInput label="تارگت" hint="هدف برنامه‌ریزی‌شده" value={takeProfitValue} register={register('take_profit')} accent="success" placeholder="3330.00" />
            </div>

            {/* Live risk preview */}
            <div className="rounded-2xl border border-gold-500/15 bg-gradient-to-br from-gold-500/[0.06] to-dark-900/70 p-3 md:p-4">
              <div className="flex items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gold-500/10 flex items-center justify-center"><Calculator className="w-4 h-4 text-gold-400" /></div>
                  <div><p className="text-sm font-semibold text-white">پیش‌نمایش ریسک</p><p className="text-[10px] text-dark-500">محاسبات لحظه‌ای؛ بدون ورود دستی عددهای تکراری</p></div>
                </div>
                <button type="button" onClick={() => setShowAdvancedRisk(v => !v)} className="text-[11px] text-dark-400 hover:text-white flex items-center gap-1">
                  تنظیمات پیشرفته <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showAdvancedRisk ? 'rotate-180' : ''}`} />
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <MetricPill label="ریسک دلاری" value={calc.risk_amount ? formatCurrency(calc.risk_amount) : '—'} tone="danger" />
                <MetricPill label="ریسک درصدی" value={calc.risk_percent ? `${calc.risk_percent.toFixed(2)}%` : '—'} tone="danger" />
                <MetricPill label="حجم پیشنهادی" value={lotSizeValue || '—'} tone="gold" />
                <MetricPill label="نسبت ریسک به بازده" value={calc.rr_ratio ? `1 : ${calc.rr_ratio.toFixed(2)}` : '—'} tone="success" />
              </div>

              <div className="mt-3 rounded-xl bg-dark-950/50 border border-white/5 px-3 py-3">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    {riskStatus.tone === 'success' ? <ShieldCheck className="w-4 h-4 text-success-400" /> : riskStatus.tone === 'danger' ? <ShieldAlert className="w-4 h-4 text-danger-400" /> : <AlertCircle className="w-4 h-4 text-warning-400" />}
                    <span className={`text-xs ${riskStatus.tone === 'success' ? 'text-success-300' : riskStatus.tone === 'danger' ? 'text-danger-300' : 'text-warning-300'}`}>{riskStatus.label}</span>
                  </div>
                  <div className="flex items-center gap-3 text-[11px]">
                    <span className="text-dark-500">هدف: <b className="text-dark-200 number-ltr">{riskPolicy.targetAmount ? formatCurrency(riskPolicy.targetAmount) : '—'}</b></span>
                    <span className="text-dark-500">بازه: <b className="text-dark-200 number-ltr">{riskPolicy.minAmount ? `${formatCurrency(riskPolicy.minAmount)} تا ${formatCurrency(riskPolicy.maxAmount)}` : '—'}</b></span>
                  </div>
                </div>
                {calc.risk_amount !== null && <div className="mt-2 text-[10px] text-dark-500">ریسک واقعی: <span className="text-white font-semibold number-ltr">{formatCurrency(calc.risk_amount)}</span> · {calc.risk_percent?.toFixed(2)}٪</div>}
                {calc.rr_ratio !== null && <div className="mt-1 text-[10px] text-dark-500">R:R: <span className={`font-semibold ${calc.rr_ratio >= 2 ? 'text-success-400' : 'text-warning-400'}`}>1 : {calc.rr_ratio.toFixed(2)}</span></div>}
              </div>

              <div className="mt-3">
                <div className="flex items-center justify-between mb-2"><span className="text-[11px] text-dark-400">سطح ریسک</span><span className="text-[10px] text-dark-600">۰٫۵٪ یا ۱٪ · باندهای دلاری واقعی</span></div>
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <div className="rounded-lg border border-success-500/15 bg-success-500/5 p-2"><div className="text-[10px] text-success-300">۰٫۵٪ استاندارد</div><div className="text-[10px] text-dark-300 number-ltr mt-1">{capitalBeforeValue ? `${formatCurrency((Number(capitalBeforeValue)||0)*0.005)} تا ${formatCurrency((Number(capitalBeforeValue)||0)*0.006)}` : '—'}</div></div>
                  <div className="rounded-lg border border-success-500/15 bg-success-500/5 p-2"><div className="text-[10px] text-success-300">۱٪ استاندارد</div><div className="text-[10px] text-dark-300 number-ltr mt-1">{capitalBeforeValue ? `${formatCurrency((Number(capitalBeforeValue)||0)*0.009)} تا ${formatCurrency((Number(capitalBeforeValue)||0)*0.011)}` : '—'}</div></div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[0.5, 1].map(v => {
                    const blocked = v > 1;
                    const active = riskMode === 'percent' && Number(riskInputValue) === v;
                    const band = v === 0.5 ? '۰٫۵٪ · باند ۰٫۵ تا ۰٫۶٪' : '۱٪ · باند ۰٫۹ تا ۱٫۱٪';
                    return <button key={v} type="button" disabled={blocked} onClick={() => { setValue('risk_mode', 'percent'); setValue('risk_input_value', String(v)); }} className={`py-2.5 rounded-lg text-xs font-semibold border transition-all ${active ? 'bg-gold-500/15 border-gold-500/40 text-gold-300' : blocked ? 'opacity-30 cursor-not-allowed border-white/5 text-dark-500' : 'border-white/10 bg-dark-950/40 text-dark-300 hover:text-white hover:border-gold-500/25'}`}><span className="block">{v}%</span><span className="block text-[9px] text-dark-500 mt-0.5">{band}</span></button>;
                  })}
                </div>
              </div>

              {showAdvancedRisk && (
                <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3 pt-3 border-t border-white/5">
                  <div><label className="label-text">نوع ریسک</label><div className="flex gap-1 bg-dark-950/60 rounded-lg p-1 border border-white/10"><button type="button" onClick={() => setValue('risk_mode', 'percent')} className={`flex-1 text-xs py-1.5 rounded-md ${riskMode === 'percent' ? 'bg-gold-500/20 text-gold-400' : 'text-dark-400'}`}>درصد</button><button type="button" onClick={() => setValue('risk_mode', 'amount')} className={`flex-1 text-xs py-1.5 rounded-md ${riskMode === 'amount' ? 'bg-gold-500/20 text-gold-400' : 'text-dark-400'}`}>دلار</button></div></div>
                  <div><label className="label-text">مقدار ریسک</label><input type="number" step="any" {...register('risk_input_value')} className="input-field number-ltr" placeholder="0.5" /></div>
                </div>
              )}
            </div>

            {/* Entry timing */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="rounded-xl border border-white/5 bg-dark-900/40 p-3">
                <label className="label-text">زمان ورود</label>
                <Controller name="entry_time" control={control} render={({ field }) => <TimeScrollPicker value={field.value} onChange={field.onChange} onBlur={field.onBlur} />} />
              </div>
              <div className="rounded-xl border border-white/5 bg-dark-900/40 p-3 trade-date-compact">
                <label className="label-text">تاریخ معامله</label>
                <Controller name="trade_date" control={control} rules={{ required: true }} render={({ field }) => <JalaliDatePicker value={field.value} onChange={field.onChange} onBlur={field.onBlur} />} />
              </div>
            </div>

            {/* Exit is deliberately hidden for open trades */}
            {!isOpen && (
              <div id="trade-exit-section" className="rounded-2xl border border-success-500/15 bg-success-500/[0.035] p-3 md:p-4 space-y-3 scroll-mt-24">
                <div className="flex items-center gap-2"><ArrowDownToLine className="w-4 h-4 text-success-400" /><div><p className="text-sm font-semibold text-white">بستن معامله</p><p className="text-[10px] text-dark-500">اکنون فقط اطلاعات خروج را ثبت کن.</p></div></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <PriceInput label="نقطه خروج" hint="قیمت واقعی اجرای خروج" value={watch('exit_price')} register={register('exit_price')} accent="success" placeholder="3337.00" />
                  <div><label className="label-text">زمان خروج</label><Controller name="exit_time" control={control} render={({ field }) => <TimeScrollPicker value={field.value} onChange={field.onChange} onBlur={field.onBlur} />} /></div>
                </div>
              </div>
            )}

            {/* Advanced technical details */}
            <details className="rounded-xl border border-white/5 bg-dark-950/30">
              <summary className="cursor-pointer list-none px-3 py-2.5 text-xs text-dark-400 hover:text-white flex items-center justify-between"><span className="flex items-center gap-2"><LockKeyhole className="w-3.5 h-3.5" /> جزئیات فنی و محاسبات</span><ChevronDown className="w-3.5 h-3.5" /></summary>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 px-3 pb-3 pt-1">
                <div><label className="label-text">حجم معامله</label><input type="number" step="0.01" min="0.01" {...register('lot_size', { required: !autoLotSizing, min: { value: 0.01, message: 'حداقل حجم 0.01 است' }, onBlur: (e) => { const normalized = normalizeLotSize(Number(e.target.value), 'nearest'); if (normalized) setValue('lot_size', formatLotSize(normalized), { shouldValidate: true, shouldDirty: true }); } })} className={`input-field number-ltr ${autoLotSizing ? 'opacity-60 bg-dark-900/80' : ''}`} readOnly={autoLotSizing} /></div>
                <div><label className="label-text">Contract Size</label><input type="number" step="any" {...register('contract_size')} className="input-field number-ltr" /></div>
                <div><label className="label-text">سرمایه قبل از معامله</label><input type="number" step="any" {...register('capital_before')} className="input-field number-ltr" /></div>
                <div>
                  <label className="label-text">کمیسیون ($)</label>
                  <input type="number" step="0.01" min="0" {...commissionField} onChange={(e) => { commissionField.onChange(e); setCommissionAutoEnabled(false); }} className="input-field number-ltr" placeholder="0" />
                  {commissionAutoEnabled && commissionRatePerLot ? (
                    <p className="mt-1 text-[10px] text-gold-300">کمیسیون خودکار: {formatCurrency(commissionRatePerLot)} برای هر لات · بر اساس {commissionRateSource === 'symbol' ? 'اولین معامله ثبت‌شده همین نماد' : 'اولین معامله ثبت‌شده این حساب'}</p>
                  ) : (
                    <p className="mt-1 text-[10px] text-dark-500">در اولین معامله کمیسیون واقعی را وارد کن؛ از معامله بعدی نرخ هر لات خودکار محاسبه می‌شود.</p>
                  )}
                </div>
                <div><label className="label-text">سواپ ($)</label><input type="number" step="any" {...register('swap')} className="input-field number-ltr" placeholder="0" /></div>
                {(Number(watch('commission')) > 0 || Number(watch('swap')) > 0) && calc.gross_pnl_amount !== null && (
                  <div className="col-span-2 rounded-lg bg-dark-900/60 border border-white/5 p-2.5 flex items-center justify-between text-xs">
                    <span className="text-dark-400">سود ناخالص {formatCurrency(calc.gross_pnl_amount)} − هزینه‌ها {formatCurrency((Number(watch('commission'))||0)+(Number(watch('swap'))||0))}</span>
                    <span className={`font-semibold number-ltr ${(calc.pnl_amount||0) >= 0 ? 'profit-text' : 'loss-text'}`}>خالص: {formatCurrency(calc.pnl_amount)}</span>
                  </div>
                )}
                <div className="flex items-end"><label className="flex items-center gap-2 cursor-pointer text-xs text-dark-300"><input type="checkbox" {...register('auto_lot_sizing')} className="w-4 h-4 accent-gold-500" /> محاسبه خودکار حجم</label></div>
              </div>
            </details>

            {/* Results */}
            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-5 gap-2 p-3 bg-dark-900/50 rounded-xl border border-white/5">
              <CalcField label="سود احتمالی" value={calc.potential_profit} color="success" prefix="$" />
              <CalcField label="P&L $" value={calc.pnl_amount} prefix="$" color={calc.pnl_amount && calc.pnl_amount > 0 ? 'success' : 'danger'} />
              <CalcField label="P&L %" value={calc.pnl_percent} suffix="%" color={calc.pnl_percent && calc.pnl_percent > 0 ? 'success' : 'danger'} />
              <CalcField label="R Multiple" value={calc.r_multiple} suffix="R" color={calc.r_multiple && calc.r_multiple > 0 ? 'success' : 'danger'} />
              <CalcField label="مدت" value={calc.duration_minutes} suffix=" دقیقه" />
            </div>
          </div>
        </Section>

        {/* Section 4: Strategy */}
        <Section title="استراتژی و ستاپ">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="label-text">استراتژی</label>
              <select {...register('strategy_id')} className="select-field">
                <option value="">بدون استراتژی</option>
                {strategies.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              {selectedStrategy && (
                <div className="mt-2 rounded-xl border border-gold-500/15 bg-gold-500/[0.035] p-2.5">
                  <div className="flex items-center justify-between gap-2 mb-1"><span className="text-[10px] text-gold-300">🛡️ قانون استراتژی</span><span className={`text-[10px] font-semibold ${blockingRuleViolations.length ? 'text-danger-400' : 'text-success-400'}`}>{blockingRuleViolations.length ? `${blockingRuleViolations.length} مغایرت` : 'در محدوده پلن'}</span></div>
                  {ruleViolations.slice(0, 3).map(v => <div key={v.id} className={`text-[10px] ${v.severity === 'block' ? 'text-danger-300' : 'text-warning-300'}`}>• {v.message}</div>)}
                  {!ruleViolations.length && <div className="text-[10px] text-dark-500">قوانین این استراتژی در حال حاضر نقض نشده‌اند.</div>}
                </div>
              )}
            </div>
            <div>
              <label className="label-text">ستاپ</label>
              <select {...register('setup_id')} className="select-field">
                <option value="">بدون ستاپ</option>
                {setups.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="label-text">دلیل ورود</label>
              <textarea {...register('entry_reason')} className="input-field h-20 resize-none" placeholder="چرا وارد این معامله شدید؟" />
            </div>
            <div>
              <label className="label-text">دلیل خروج</label>
              <textarea {...register('exit_reason')} className="input-field h-20 resize-none" placeholder="چرا از این معامله خارج شدید؟" />
            </div>
          </div>
        </Section>

        {/* Section 5: Psychology */}
        <Section title="روانشناسی">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
            <div>
              <label className="label-text">حس قبل از معامله</label>
              <select {...register('feeling_before')} className="select-field">
                <option value="">انتخاب کنید</option>
                {FEELINGS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
              </select>
            </div>
            <div>
              <label className="label-text">حس حین معامله</label>
              <select {...register('feeling_during')} className="select-field">
                <option value="">انتخاب کنید</option>
                {FEELINGS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
              </select>
            </div>
            <div>
              <label className="label-text">حس بعد از معامله</label>
              <select {...register('feeling_after')} className="select-field">
                <option value="">انتخاب کنید</option>
                {FEELINGS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="label-text mb-2 block">برچسب روانشناسی</label>
            <div className="flex flex-wrap gap-2">
              {PSYCH_TAGS.map(tag => (
                <button
                  key={tag.value}
                  type="button"
                  onClick={() => togglePsychTag(tag.value)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    selectedPsychTags.includes(tag.value)
                      ? 'bg-gold-500/20 border border-gold-500/40 text-gold-400'
                      : 'bg-dark-800 border border-white/10 text-dark-300 hover:border-white/20'
                  }`}
                >
                  {tag.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
            <div>
              <label className="label-text">اشتباهات</label>
              <textarea {...register('mistakes')} className="input-field h-20 resize-none" placeholder="چه اشتباهی در این معامله انجام دادید؟" />
            </div>
            <div>
              <label className="label-text">درس‌ها</label>
              <textarea {...register('lessons')} className="input-field h-20 resize-none" placeholder="از این معامله چه درسی گرفتید؟" />
            </div>
          </div>

          <div className="mt-3">
            <label className="label-text">یادداشت‌ها</label>
            <textarea {...register('notes')} className="input-field h-24 resize-none" placeholder="یادداشت‌های اضافی..." />
          </div>
        </Section>

        {(isEdit && id || createdTradeId) && (
          <div className="pt-2">
            <TradeScreenshots tradeId={(createdTradeId || id)!} />
            {createdTradeId && <div className="flex justify-end gap-2 mt-3"><button type="button" onClick={() => navigate(`/trade/${createdTradeId}`)} className="btn-secondary text-xs">مشاهده جزئیات معامله</button><button type="button" onClick={() => navigate('/history')} className="btn-primary text-xs">اتمام و بازگشت به ژورنال</button></div>}
          </div>
        )}

        {/* AI Pre-Trade Coach */}
        {!isEdit && noTradeWarning && (
          <div className="glass-card p-3.5 flex items-center gap-3 border border-danger-500/30 bg-danger-500/5">
            <CalendarOff className="w-5 h-5 text-danger-400 flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-danger-400">تو یه بازه‌ی «معامله‌نکن» هستی</p>
              <p className="text-xs text-dark-400 mt-0.5">{noTradeWarning} — طبق قانونی که خودت تعریف کردی، الان زمان مناسبی برای معامله نیست.</p>
            </div>
          </div>
        )}
        {!isEdit && <PreTradeCoach trade={{ ...watch(), calculated: calc }} maxRiskPercent={maxRiskPercent} />}

        {Object.keys(errors).length > 0 && (
          <div className="rounded-xl border border-danger-500/20 bg-danger-500/[0.04] p-3 text-xs text-danger-300">
            {Object.values(errors).map((e, i) => <div key={i}>• {String((e as {message?:string}).message || 'یک فیلد الزامی تکمیل نشده است.')}</div>)}
          </div>
        )}

        {/* Submit */}
        <div className="flex justify-end gap-3">
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary px-6">
            انصراف
          </button>
          <button type="submit" disabled={saving || success || (!isEdit && Number(capitalBeforeValue) <= 0)} className="btn-primary px-8 flex items-center gap-2">
            {saving ? (
              <div className="w-4 h-4 border-2 border-dark-950/30 border-t-dark-950 rounded-full animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {isEdit ? 'ذخیره تغییرات' : 'ثبت معامله'}
          </button>
        </div>
      </form>
    </div>
  );
}


function PriceInput({ label, hint, required, value, register, accent, placeholder }: { label: string; hint: string; required?: boolean; value?: string; register: any; accent: 'gold'|'danger'|'success'; placeholder: string }) {
  const styles = { gold: 'border-gold-500/25 focus-within:border-gold-500/60', danger: 'border-danger-500/20 focus-within:border-danger-500/55', success: 'border-success-500/20 focus-within:border-success-500/55' };
  return <div className={`rounded-xl border bg-dark-900/50 p-3 transition-all ${styles[accent]}`}>
    <label className="label-text mb-1">{label}{required ? ' *' : ''}</label>
    <p className="text-[10px] text-dark-600 mb-2">{hint}</p>
    <input type="number" step="any" {...register} className="w-full bg-transparent border-0 outline-none text-lg font-semibold text-white number-ltr placeholder:text-dark-700" placeholder={placeholder} value={undefined} />
  </div>;
}

function MetricPill({ label, value, tone }: { label: string; value: string; tone: 'gold'|'danger'|'success' }) {
  const cls = { gold: 'text-gold-400', danger: 'text-danger-400', success: 'text-success-400' };
  return <div className="rounded-xl bg-dark-950/55 border border-white/5 p-2.5 text-center"><p className="text-[10px] text-dark-500 mb-1">{label}</p><p className={`text-sm font-bold number-ltr ${cls[tone]}`}>{value}</p></div>;
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="glass-card overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between p-4 text-right hover:bg-white/3 transition-colors"
      >
        <h2 className="text-sm font-semibold text-white">{title}</h2>
        <ChevronDown className={`w-4 h-4 text-dark-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <div className="px-4 pb-4">{children}</div>}
    </div>
  );
}

function CalcField({ label, value, prefix, suffix, color }: {
  label: string;
  value: number | null;
  prefix?: string;
  suffix?: string;
  color?: 'success' | 'danger' | string;
}) {
  const colorClass = color === 'success' ? 'text-success-400' : color === 'danger' ? 'text-danger-400' : 'text-white';
  return (
    <div className="bg-dark-800/60 rounded-lg p-2.5">
      <p className="text-xs text-dark-400 mb-1">{label}</p>
      <p className={`text-sm font-semibold number-ltr ${value !== null ? colorClass : 'text-dark-600'}`}>
        {value !== null
          ? `${value > 0 && (color === 'success' || color === 'danger') ? '+' : ''}${prefix || ''}${value.toFixed(2)}${suffix || ''}`
          : '—'
        }
      </p>
    </div>
  );
}
