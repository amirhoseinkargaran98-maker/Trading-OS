/**
 * Thin wrapper around the browser's native Notification API so risk/behavior
 * alerts can reach the trader even when the tab is in the background —
 * genuinely important for someone with several tabs open while trading.
 *
 * Fully optional and silent-safe: if the browser doesn't support
 * Notification, or the user denies/never grants permission, every function
 * here just no-ops instead of throwing.
 */

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getNotificationPermission(): NotificationPermission | 'unsupported' {
  if (!isNotificationSupported()) return 'unsupported';
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (!isNotificationSupported()) return 'unsupported';
  if (Notification.permission !== 'default') return Notification.permission;
  try {
    return await Notification.requestPermission();
  } catch {
    return 'denied';
  }
}

export function sendBrowserNotification(title: string, body: string, tag?: string) {
  if (!isNotificationSupported() || Notification.permission !== 'granted') return;
  try {
    new Notification(title, { body, tag, icon: '/vite.svg' });
  } catch {
    // Some browsers (mostly mobile) throw if not called from a service worker
    // context — safe to ignore, this is a best-effort enhancement only.
  }
}
