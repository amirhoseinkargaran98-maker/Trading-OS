import { compareTradeChronological, type EngineTrade } from '@/lib/tradingEngine';

export type PerformanceTrade = {
  trade_date: string;
  result?: string | null;
  pnl_amount?: number | null;
  r_multiple?: number | null;
  risk_percent?: number | null;
  entry_reason?: string | null;
  session?: string | null;
  entry_time?: string | null;
  created_at?: string | null;
};

const num = (v: unknown) => Number(v) || 0;
// Every function below that walks trades in sequence (equity/drawdown, streaks)
// must use a deterministic chronological order — trade_date alone is unstable
// for same-day trades. See compareTradeChronological in tradingEngine.ts.
const chronological = (trades: PerformanceTrade[]) =>
  [...trades].sort((a, b) => compareTradeChronological(a as EngineTrade, b as EngineTrade));

export function calculatePerformanceProfile(trades: PerformanceTrade[], initialCapital: number) {
  const closed = chronological(trades.filter(t => t.result !== 'open' && t.pnl_amount !== null && t.pnl_amount !== undefined));
  const wins = closed.filter(t => num(t.pnl_amount) > 0);
  const losses = closed.filter(t => num(t.pnl_amount) < 0);
  const grossProfit = wins.reduce((s,t)=>s+num(t.pnl_amount),0);
  const grossLossAbs = Math.abs(losses.reduce((s,t)=>s+num(t.pnl_amount),0));
  const expectancy = closed.length ? closed.reduce((s,t)=>s+num(t.pnl_amount),0)/closed.length : 0;
  const avgWin = wins.length ? grossProfit/wins.length : 0;
  const avgLoss = losses.length ? grossLossAbs/losses.length : 0;
  const payoff = avgLoss ? avgWin/avgLoss : 0;
  const profitFactor = grossLossAbs ? grossProfit/grossLossAbs : (grossProfit > 0 ? Infinity : 0);
  const avgR = closed.length ? closed.reduce((s,t)=>s+num(t.r_multiple),0)/closed.length : 0;
  const totalRisk = closed.reduce((s,t)=>s+num(t.risk_percent),0);

  let equity = initialCapital;
  let peak = initialCapital;
  let maxDD = 0;
  let maxDDAmount = 0;
  let currentWin = 0, currentLoss = 0, bestWin = 0, worstLoss = 0;
  for (const t of closed) {
    const pnl = num(t.pnl_amount);
    equity += pnl;
    peak = Math.max(peak, equity);
    const ddAmount = Math.max(0, peak-equity);
    maxDDAmount = Math.max(maxDDAmount, ddAmount);
    maxDD = Math.max(maxDD, peak ? ddAmount/peak*100 : 0);
    if (pnl > 0) { currentWin++; currentLoss=0; bestWin=Math.max(bestWin,currentWin); }
    else if (pnl < 0) { currentLoss++; currentWin=0; worstLoss=Math.max(worstLoss,currentLoss); }
  }
  return { trades:closed.length, expectancy, avgWin, avgLoss, payoff, profitFactor, avgR, totalRisk, maxDD, maxDDAmount, bestWin, worstLoss };
}

export function monthlyPerformance(trades: PerformanceTrade[]) {
  const map: Record<string,{pnl:number; trades:number; wins:number}> = {};
  trades.filter(t=>t.result!=='open').forEach(t=>{
    const key=(t.trade_date||'').slice(0,7);
    if(!key) return;
    map[key] ??= {pnl:0,trades:0,wins:0};
    map[key].pnl += num(t.pnl_amount);
    map[key].trades++;
    if(num(t.pnl_amount)>0) map[key].wins++;
  });
  return Object.entries(map).sort(([a],[b])=>a.localeCompare(b)).map(([month,v])=>({month,...v,winRate:v.trades?v.wins/v.trades*100:0}));
}

export function streakInfo(trades: PerformanceTrade[]) {
  let bestW=0,bestL=0,w=0,l=0;
  chronological(trades.filter(t=>t.result!=='open')).forEach(t=>{
    const pnl=num(t.pnl_amount);
    if(pnl>0){w++;l=0;bestW=Math.max(bestW,w);} else if(pnl<0){l++;w=0;bestL=Math.max(bestL,l);}
  });
  return {bestWinStreak:bestW,bestLossStreak:bestL};
}
