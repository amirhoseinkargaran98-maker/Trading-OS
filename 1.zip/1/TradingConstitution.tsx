import { useState, useEffect, useCallback } from 'react';
import { Scroll, Plus, Trash2, ShieldCheck, Info } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

type Rule = { id: string; category: string; rule_type: 'hard' | 'soft'; rule_text: string; is_active: boolean };

const CATEGORIES: { key: string; label: string }[] = [
  { key: 'risk', label: 'قوانین ریسک' },
  { key: 'entry', label: 'قوانین ورود' },
  { key: 'exit', label: 'قوانین خروج' },
  { key: 'session', label: 'قوانین سشن' },
  { key: 'psychology', label: 'قوانین روانشناسی' },
  { key: 'no_trade', label: 'قوانین معامله‌نکردن' },
  { key: 'recovery', label: 'قوانین بازگشت بعد از ضرر' },
];

export default function TradingConstitution() {
  const { user } = useAuth();
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);
  const [newRuleText, setNewRuleText] = useState<Record<string, string>>({});
  const [newRuleType, setNewRuleType] = useState<Record<string, 'hard' | 'soft'>>({});
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase.from('trading_constitution_rules').select('*').eq('user_id', user.id).order('created_at');
    setRules(data || []);
    setLoading(false);
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const addRule = async (category: string) => {
    const text = (newRuleText[category] || '').trim();
    if (!user || !text) return;
    await supabase.from('trading_constitution_rules').insert({
      user_id: user.id, category, rule_text: text, rule_type: newRuleType[category] || 'hard',
    });
    setNewRuleText(f => ({ ...f, [category]: '' }));
    load();
  };

  const toggleActive = async (rule: Rule) => {
    if (!user) return;
    await supabase.from('trading_constitution_rules').update({ is_active: !rule.is_active }).eq('id', rule.id).eq('user_id', user.id);
    load();
  };

  const deleteRule = async (id: string) => {
    if (!user) return;
    await supabase.from('trading_constitution_rules').delete().eq('id', id).eq('user_id', user.id);
    setDeleteId(null);
    load();
  };

  const hardCount = rules.filter(r => r.rule_type === 'hard' && r.is_active).length;
  const softCount = rules.filter(r => r.rule_type === 'soft' && r.is_active).length;

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div className="flex items-center gap-2"><Scroll className="w-5 h-5 text-gold-400" /><h1 className="text-xl font-bold text-white">قانون اساسی معاملاتی</h1></div>
      </div>

      <div className="glass-card p-3.5 flex items-start gap-3 border border-gold-500/15 bg-gold-500/[0.03]">
        <Info className="w-4.5 h-4.5 text-gold-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-dark-300 leading-6">
          قوانین «سخت» (Hard) قوانینی هستن که هیچ‌وقت نباید بشکنی — مرز قرمزت. قوانین «نرم» (Soft) راهنمای تصمیم‌گیری‌ان، جایی که قضاوت لحظه‌ای هم دخیله.
          الان <span className="text-white font-semibold number-ltr">{hardCount}</span> قانون سخت و <span className="text-white font-semibold number-ltr">{softCount}</span> قانون نرم فعال داری.
        </p>
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><div className="w-6 h-6 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" /></div>
      ) : (
        <div className="space-y-4">
          {CATEGORIES.map(cat => {
            const catRules = rules.filter(r => r.category === cat.key);
            return (
              <div key={cat.key} className="glass-card p-4">
                <h2 className="text-sm font-semibold text-white mb-3 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-gold-400" /> {cat.label}
                </h2>

                {catRules.length === 0 ? (
                  <p className="text-xs text-dark-500 mb-3">هنوز قانونی تو این دسته ننوشتی.</p>
                ) : (
                  <div className="space-y-2 mb-3">
                    {catRules.map(r => (
                      <div key={r.id} className={`flex items-center justify-between gap-2 rounded-lg px-3 py-2 border ${r.rule_type === 'hard' ? 'border-danger-500/20 bg-danger-500/5' : 'border-gold-500/15 bg-gold-500/[0.03]'} ${!r.is_active ? 'opacity-40' : ''}`}>
                        <div className="flex items-center gap-2 min-w-0">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded flex-shrink-0 ${r.rule_type === 'hard' ? 'bg-danger-500/15 text-danger-400' : 'bg-gold-500/15 text-gold-400'}`}>
                            {r.rule_type === 'hard' ? 'سخت' : 'نرم'}
                          </span>
                          <span className="text-sm text-dark-200 truncate">{r.rule_text}</span>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button onClick={() => toggleActive(r)} className="text-[10px] text-dark-400 hover:text-white px-1.5">{r.is_active ? 'غیرفعال کن' : 'فعال کن'}</button>
                          <button onClick={() => setDeleteId(r.id)} className="p-1 text-dark-400 hover:text-danger-400"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <select
                    value={newRuleType[cat.key] || 'hard'}
                    onChange={e => setNewRuleType(f => ({ ...f, [cat.key]: e.target.value as 'hard' | 'soft' }))}
                    className="select-field w-24 text-xs py-1.5 flex-shrink-0"
                  >
                    <option value="hard">سخت</option>
                    <option value="soft">نرم</option>
                  </select>
                  <input
                    type="text"
                    value={newRuleText[cat.key] || ''}
                    onChange={e => setNewRuleText(f => ({ ...f, [cat.key]: e.target.value }))}
                    onKeyDown={e => e.key === 'Enter' && addRule(cat.key)}
                    className="input-field flex-1 text-sm py-1.5"
                    placeholder="یه قانون جدید بنویس..."
                  />
                  <button onClick={() => addRule(cat.key)} className="btn-secondary p-1.5 !px-2.5 flex-shrink-0"><Plus className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {deleteId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف قانون</h3>
            <p className="text-sm text-dark-400 mb-4">آیا مطمئنی؟</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => deleteRule(deleteId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
