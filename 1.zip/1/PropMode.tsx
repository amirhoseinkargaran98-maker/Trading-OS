import { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck, ShieldAlert, ShieldX, TrendingUp, TrendingDown,
  Wallet, Target, AlertTriangle, Award, Gauge, LockKeyhole, Brain, Scale, RefreshCw, CheckCircle2
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency, toGregorianDateInput } from '@/lib/utils';
import { calculateEquityCurve, compareTradeChronological } from '@/lib/tradingEngine';
import { evaluateRiskStatus, RISK_STATUS_LABEL, type RiskStatus } from '@/lib/riskEngine';

type PropAccount = {
  id: string; name: string; broker: string | null;
  initial_balance: number; current_balance: number;
  prop_max_drawdown_percent: number | null; prop_profit_target_percent: number | null;
};

const STATUS_ICON: Record<RiskStatus, any> = { ready: ShieldCheck, caution: ShieldAlert, locked: ShieldX };
const STATUS_STYLE: Record<RiskStatus, string> = {
  ready: 'border-success-500/25 bg-success-500/5 text-success-400',
  caution: 'border-gold-500/30 bg-gold-500/5 text-gold-400',
  locked: 'border-danger-500/30 bg-danger-500/5 text-danger-400',
};

export default function PropMode() {
  const { user } = useAuth();
  const [accounts, setAccounts] = useState<PropAccount[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<{
    status: RiskStatus; messages: string[]; totalPnl: number; totalPnlPercent: number;
    currentDrawdownPercent: number; dailyPnlPercent: number; tradesToday: number;
    targetHit: boolean; drawdownLimit: number | null; profitTarget: number | null;
    dailyMaxLossPercent: number; dailyProfitTargetPercent: number; maxRiskPerTrade: number;
    maxTradesPerDay: number; maxConsecutiveLosses: number; consecutiveLosses: number;
    targetGapPercent: number; drawdownBufferPercent: number; dailyLossRemainingPercent: number;
    safeRiskPercent: number; healthScore: number; nextAction: string;
  } | null>(null);

  const loadAccounts = useCallback(async () => {
    if (!user) return;
    const { data: accs } = await supabase
      .from('accounts').select('id, name, broker, initial_balance, current_balance, prop_max_drawdown_percent, prop_profit_target_percent')
      .eq('user_id', user.id).eq('account_type', 'prop').eq('is_active', true).order('created_at');
    setAccounts(accs || []);
    if (accs && accs.length > 0 && !selectedId) setSelectedId(accs[0].id);
    if (!accs || accs.length === 0) setLoading(false);
  }, [user, selectedId]);

  useEffect(() => { loadAccounts(); }, [loadAccounts]);

  const loadEvaluation = useCallback(async () => {
    if (!user || !selectedId) return;
    setLoading(true);
    const account = accounts.find(a => a.id === selectedId);
    if (!account) { setLoading(false); return; }

    const today = toGregorianDateInput(new Date());
    const [{ data: allTrades }, { data: riskSettings }] = await Promise.all([
      supabase.from('trades').select('trade_date, entry_time, created_at, pnl_amount, result').eq('user_id', user.id).eq('account_id', selectedId).not('result', 'eq', 'open').order('trade_date', { ascending: true }).order('entry_time', { ascending: true }),
      supabase.from('risk_settings').select('*').eq('user_id', user.id).eq('account_id', selectedId).eq('is_active', true).maybeSingle(),
    ]);

    const trades = allTrades || [];
    const { maxDrawdownPercent, currentDrawdownPercent } = calculateEquityCurve(trades as any, account.initial_balance);
    const totalPnl = trades.reduce((s, t) => s + (Number(t.pnl_amount) || 0), 0);
    const totalPnlPercent = account.initial_balance > 0 ? (totalPnl / account.initial_balance) * 100 : 0;

    const todayTrades = trades.filter(t => t.trade_date === today);
    const dailyPnl = todayTrades.reduce((s, t) => s + (Number(t.pnl_amount) || 0), 0);
    const dailyPnlPercent = account.current_balance > 0 ? (dailyPnl / account.current_balance) * 100 : 0;

    const sortedDesc = [...trades].sort((a, b) => compareTradeChronological(b as any, a as any));
    let consecutiveLosses = 0;
    for (const t of sortedDesc) { if (t.result === 'loss') consecutiveLosses += 1; else break; }

    const risk = evaluateRiskStatus({
      isActive: true,
      todayPnlPercent: dailyPnlPercent,
      dailyMaxLossPercent: riskSettings?.daily_max_loss ?? 2,
      dailyProfitTargetPercent: riskSettings?.daily_profit_target ?? 3,
      tradesToday: todayTrades.length,
      maxTradesPerDay: riskSettings?.max_trades_per_day ?? 5,
      consecutiveLosses,
      maxConsecutiveLosses: riskSettings?.max_consecutive_losses ?? 3,
      currentDrawdownPercent,
      maxDrawdownPercent: account.prop_max_drawdown_percent || undefined,
    });

    const dailyMaxLossPercent = Number(riskSettings?.daily_max_loss ?? 2);
    const dailyProfitTargetPercent = Number(riskSettings?.daily_profit_target ?? 3);
    const maxRiskPerTrade = Number(riskSettings?.max_risk_per_trade ?? 0.5);
    const maxTradesPerDay = Number(riskSettings?.max_trades_per_day ?? 5);
    const maxConsecutiveLosses = Number(riskSettings?.max_consecutive_losses ?? 3);
    const targetHit = !!account.prop_profit_target_percent && totalPnlPercent >= account.prop_profit_target_percent;
    const targetGapPercent = Math.max(0, Number(account.prop_profit_target_percent || 0) - totalPnlPercent);
    const drawdownBufferPercent = account.prop_max_drawdown_percent == null ? Infinity : Math.max(0, Number(account.prop_max_drawdown_percent) - currentDrawdownPercent);
    const dailyLossRemainingPercent = Math.max(0, dailyMaxLossPercent - Math.max(0, -dailyPnlPercent));
    const rawSafeRisk = Math.min(
      maxRiskPerTrade || 0.5,
      dailyLossRemainingPercent > 0 ? dailyLossRemainingPercent / 2 : 0,
      Number.isFinite(drawdownBufferPercent) ? drawdownBufferPercent / 3 : maxRiskPerTrade || 0.5,
    );
    const safeRiskPercent = Math.max(0, Math.floor(rawSafeRisk * 4) / 4);
    const ddHealth = account.prop_max_drawdown_percent ? Math.max(0, 100 - (currentDrawdownPercent / account.prop_max_drawdown_percent) * 100) : 100;
    const dailyHealth = dailyMaxLossPercent ? Math.max(0, 100 - (Math.max(0, -dailyPnlPercent) / dailyMaxLossPercent) * 100) : 100;
    const lossStreakHealth = maxConsecutiveLosses ? Math.max(0, 100 - (consecutiveLosses / maxConsecutiveLosses) * 100) : 100;
    const targetHealth = account.prop_profit_target_percent ? Math.min(100, Math.max(0, (totalPnlPercent / account.prop_profit_target_percent) * 100)) : 50;
    const healthScore = Math.round((ddHealth * 0.4) + (dailyHealth * 0.25) + (lossStreakHealth * 0.2) + (Math.max(20, targetHealth) * 0.15));
    const messages = [...risk.blockers, ...risk.warnings, ...risk.notices].map(r => r.message);
    if (consecutiveLosses >= maxConsecutiveLosses && maxConsecutiveLosses > 0) messages.push(`پس از ${consecutiveLosses} باخت متوالی، توقف تا بازبینی توصیه می‌شود.`);
    if (safeRiskPercent > 0) messages.push(`ریسک محافظه‌کارانه پیشنهادی برای معامله بعد: حدود ${safeRiskPercent.toFixed(2)}٪ از سرمایه.`);
    if (targetHit) messages.push('هدف سود ارزیابی محقق شده — برای حفظ حساب، افزایش ریسک نده.');
    const nextAction = risk.status === 'locked' ? 'امروز معامله نکن؛ ابتدا عامل قفل ریسک را برطرف کن.' : consecutiveLosses >= maxConsecutiveLosses ? 'استاپ روزانه: قبل از معامله بعدی مرور علت باخت‌های متوالی را انجام بده.' : safeRiskPercent <= 0 ? 'امروز بودجه ریسک باقی‌مانده‌ای نداری؛ از ورود جدید خودداری کن.' : targetGapPercent > 0 ? `روی کیفیت اجرا تمرکز کن؛ فاصله تا هدف ${targetGapPercent.toFixed(2)}٪ است و نباید با افزایش ریسک جبران شود.` : 'هدف محقق شده؛ اولویت با حفظ سرمایه و صفر کردن تخلف است.';

    setData({
      status: risk.status, messages, totalPnl, totalPnlPercent, currentDrawdownPercent,
      dailyPnlPercent, tradesToday: todayTrades.length, targetHit,
      drawdownLimit: account.prop_max_drawdown_percent, profitTarget: account.prop_profit_target_percent,
      dailyMaxLossPercent, dailyProfitTargetPercent, maxRiskPerTrade, maxTradesPerDay, maxConsecutiveLosses, consecutiveLosses,
      targetGapPercent, drawdownBufferPercent, dailyLossRemainingPercent, safeRiskPercent, healthScore, nextAction,
    });
    setLoading(false);
  }, [user, selectedId, accounts]);

  useEffect(() => { if (accounts.length && selectedId) loadEvaluation(); }, [accounts, selectedId, loadEvaluation]);

  const account = accounts.find(a => a.id === selectedId);

  if (!loading && accounts.length === 0) {
    return (
      <div className="page-container" dir="rtl">
        <div className="section-header">
          <div className="flex items-center gap-2"><Award className="w-5 h-5 text-gold-400" /><h1 className="text-xl font-bold text-white">حالت پراپ</h1></div>
        </div>
        <div className="glass-card p-10 text-center">
          <p className="text-dark-400 text-sm mb-2">هیچ حساب پراپ فعالی نداری.</p>
          <p className="text-xs text-dark-500">از تنظیمات → حساب‌ها، نوع حساب رو «پراپ» انتخاب کن و حداکثر افت سرمایه و هدف سود ارزیابی رو مشخص کن.</p>
        </div>
      </div>
    );
  }

  const StatusIcon = data ? STATUS_ICON[data.status] : ShieldCheck;
  const ddUsedPercent = data && data.drawdownLimit ? Math.min(100, (data.currentDrawdownPercent / data.drawdownLimit) * 100) : 0;
  const targetProgressPercent = data && data.profitTarget ? Math.min(100, Math.max(0, (data.totalPnlPercent / data.profitTarget) * 100)) : 0;
  const bufferRemaining = data && data.drawdownLimit && account ? (account.initial_balance * (data.drawdownLimit - data.currentDrawdownPercent)) / 100 : null;

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div className="flex items-center gap-2"><Award className="w-5 h-5 text-gold-400" /><h1 className="text-xl font-bold text-white">حالت پراپ</h1></div>
        {accounts.length > 1 && (
          <select value={selectedId || ''} onChange={e => setSelectedId(e.target.value)} className="select-field w-auto">
            {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        )}
      </div>

      {loading || !data || !account ? (
        <div className="flex justify-center py-16"><div className="w-6 h-6 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" /></div>
      ) : (
        <>
          <div className={`glass-card p-4 flex items-start gap-3 border ${STATUS_STYLE[data.status]}`}>
            <StatusIcon className="w-6 h-6 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold">{RISK_STATUS_LABEL[data.status]}</p>
              <p className="text-xs text-dark-400 mt-1">{data.messages.length ? data.messages.join(' ') : 'همه‌چیز طبق قوانین ارزیابیه.'}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="kpi-card">
              <span className="text-[11px] text-dark-400 flex items-center gap-1"><Wallet className="w-3.5 h-3.5" /> موجودی اولیه</span>
              <p className="text-lg font-bold text-white number-ltr">{formatCurrency(account.initial_balance)}</p>
            </div>
            <div className="kpi-card">
              <span className="text-[11px] text-dark-400 flex items-center gap-1">{data.totalPnl >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />} سود/زیان کل</span>
              <p className={`text-lg font-bold number-ltr ${data.totalPnl >= 0 ? 'profit-text' : 'loss-text'}`}>{formatCurrency(data.totalPnl)}</p>
              <p className="text-[11px] text-dark-500 number-ltr">{data.totalPnlPercent >= 0 ? '+' : ''}{data.totalPnlPercent.toFixed(2)}%</p>
            </div>
            <div className="kpi-card">
              <span className="text-[11px] text-dark-400 flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5" /> افت فعلی سرمایه</span>
              <p className={`text-lg font-bold number-ltr ${data.drawdownLimit && data.currentDrawdownPercent >= data.drawdownLimit * 0.8 ? 'text-danger-400' : 'text-white'}`}>{data.currentDrawdownPercent.toFixed(2)}%</p>
              <p className="text-[11px] text-dark-500">{data.drawdownLimit ? `از سقف ${data.drawdownLimit}%` : 'سقفی تعیین نشده'}</p>
            </div>
            <div className="kpi-card">
              <span className="text-[11px] text-dark-400 flex items-center gap-1"><Target className="w-3.5 h-3.5" /> بافر باقی‌مانده</span>
              <p className="text-lg font-bold text-white number-ltr">{bufferRemaining !== null ? formatCurrency(Math.max(0, bufferRemaining)) : '—'}</p>
              <p className="text-[11px] text-dark-500">تا رسیدن به سقف افت سرمایه</p>
            </div>
          </div>

          {data.drawdownLimit && (
            <div className="glass-card p-4">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-dark-400">افت سرمایه نسبت به سقف مجاز</span>
                <span className="text-white number-ltr">{data.currentDrawdownPercent.toFixed(2)}% / {data.drawdownLimit}%</span>
              </div>
              <div className="h-2.5 rounded-full bg-dark-700 overflow-hidden">
                <div className={`h-full transition-all ${ddUsedPercent >= 90 ? 'bg-danger-500' : ddUsedPercent >= 70 ? 'bg-gold-500' : 'bg-success-500'}`} style={{ width: `${ddUsedPercent}%` }} />
              </div>
            </div>
          )}

          {data.profitTarget && (
            <div className="glass-card p-4">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-dark-400">پیشرفت هدف سود ارزیابی</span>
                <span className="text-white number-ltr">{data.totalPnlPercent.toFixed(2)}% / {data.profitTarget}%</span>
              </div>
              <div className="h-2.5 rounded-full bg-dark-700 overflow-hidden">
                <div className={`h-full transition-all ${data.targetHit ? 'bg-success-500' : 'bg-gold-500'}`} style={{ width: `${targetProgressPercent}%` }} />
              </div>
              {data.targetHit && <p className="text-xs text-success-400 mt-2 flex items-center gap-1"><Award className="w-3.5 h-3.5" /> هدف ارزیابی محقق شده</p>}
            </div>
          )}

          <div className="grid lg:grid-cols-3 gap-4">
            <div className="glass-card p-5 lg:col-span-2">
              <div className="flex items-center justify-between gap-3 mb-4">
                <div><h2 className="font-bold text-white flex items-center gap-2"><Gauge className="w-5 h-5 text-gold-400"/> مربی عبور از چالش</h2><p className="text-xs text-dark-500 mt-1">قوانین محافظه‌کارانه برای حفظ حساب؛ هدف این بخش «کم‌کردن احتمال نقض قوانین» است، نه فشار برای رسیدن سریع به سود.</p></div>
                <div className="text-center min-w-[72px]"><p className="text-[10px] text-dark-500">سلامت چالش</p><p className={`text-2xl font-black number-ltr ${data.healthScore>=75?'text-success-400':data.healthScore>=50?'text-gold-400':'text-danger-400'}`}>{data.healthScore}</p><p className="text-[10px] text-dark-500">/100</p></div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="kpi-card"><span className="text-[11px] text-dark-400 flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5"/>ریسک پیشنهادی</span><p className="text-lg font-bold text-gold-300 number-ltr mt-1">{data.safeRiskPercent.toFixed(2)}٪</p><p className="text-[10px] text-dark-500 mt-1">سقف ثبت‌شده {data.maxRiskPerTrade.toFixed(2)}٪</p></div>
                <div className="kpi-card"><span className="text-[11px] text-dark-400 flex items-center gap-1"><Scale className="w-3.5 h-3.5"/>بودجه زیان امروز</span><p className="text-lg font-bold text-white number-ltr mt-1">{data.dailyLossRemainingPercent.toFixed(2)}٪</p><p className="text-[10px] text-dark-500 mt-1">از سقف {data.dailyMaxLossPercent.toFixed(2)}٪</p></div>
                <div className="kpi-card"><span className="text-[11px] text-dark-400 flex items-center gap-1"><LockKeyhole className="w-3.5 h-3.5"/>بافر دراداون</span><p className="text-lg font-bold text-white number-ltr mt-1">{Number.isFinite(data.drawdownBufferPercent) ? `${data.drawdownBufferPercent.toFixed(2)}٪` : '∞'}</p><p className="text-[10px] text-dark-500 mt-1">فضای امن تا سقف مجاز</p></div>
                <div className="kpi-card"><span className="text-[11px] text-dark-400 flex items-center gap-1"><Brain className="w-3.5 h-3.5"/>باخت متوالی</span><p className={`text-lg font-bold number-ltr mt-1 ${data.consecutiveLosses>=data.maxConsecutiveLosses?'text-danger-400':'text-white'}`}>{data.consecutiveLosses}</p><p className="text-[10px] text-dark-500 mt-1">حد توقف {data.maxConsecutiveLosses}</p></div>
              </div>
              <div className="mt-4 p-4 rounded-xl border border-gold-500/15 bg-gold-500/[.04]"><p className="text-xs text-gold-300 flex items-center gap-2"><Target className="w-4 h-4"/>اقدام بعدی</p><p className="text-sm text-white mt-2 leading-6">{data.nextAction}</p></div>
            </div>

            <div className="glass-card p-5">
              <h2 className="font-bold text-white flex items-center gap-2 mb-4"><RefreshCw className="w-5 h-5 text-gold-400"/> چک‌لیست هر روز</h2>
              <div className="space-y-3 text-sm">
                {['ابتدا سقف زیان روز و بافر دراداون را چک کن.','ریسک معامله بعد از بودجه امروز بیشتر نشود.','پس از حد باخت متوالی، معامله‌گری را متوقف کن.','برای رسیدن به تارگت، ریسک را افزایش نده.','قبل از پایان روز Review معاملات را کامل کن.'].map((x,i)=><div key={i} className="flex items-start gap-2 text-dark-300"><CheckCircle2 className="w-4 h-4 text-success-400 shrink-0 mt-0.5"/><span>{x}</span></div>)}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
