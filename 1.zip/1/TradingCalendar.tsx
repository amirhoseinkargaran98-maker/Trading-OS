import { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Calendar, ChevronRight, ChevronLeft, CalendarCheck, TrendingUp, TrendingDown,
  Flame, Snowflake, Star, X, ArrowUpRight, Award, AlertTriangle
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import {
  formatCurrency, toPersianDate, toGregorianDateInput, parseDateOnly,
  getResultLabel, getResultBadgeClass,
} from '@/lib/utils';

type DayAgg = { pnl: number; trades: number; wins: number; losses: number };
type Metric = 'amount' | 'percent' | 'trades';

export default function TradingCalendar() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [monthCursor, setMonthCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [dayAgg, setDayAgg] = useState<Record<string, DayAgg>>({});
  const [balance, setBalance] = useState(0);
  const [dailyTarget, setDailyTarget] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [metric, setMetric] = useState<Metric>('amount');
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [dayTrades, setDayTrades] = useState<any[]>([]);
  const [dayTradesLoading, setDayTradesLoading] = useState(false);

  const monthStart = toGregorianDateInput(monthCursor);
  const monthEnd = toGregorianDateInput(new Date(monthCursor.getFullYear(), monthCursor.getMonth() + 1, 0));
  const todayStr = toGregorianDateInput(new Date());

  const loadMonth = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    const [{ data: trades }, { data: accounts }] = await Promise.all([
      supabase.from('trades').select('trade_date, pnl_amount, result').eq('user_id', user.id).eq('account_id', getActiveAccountId()).gte('trade_date', monthStart).lte('trade_date', monthEnd),
      supabase.from('accounts').select('id, current_balance').eq('user_id', user.id).eq('id', getActiveAccountId()).maybeSingle(),
    ]);

    const agg: Record<string, DayAgg> = {};
    (trades || []).forEach((t: any) => {
      const d = t.trade_date;
      if (!agg[d]) agg[d] = { pnl: 0, trades: 0, wins: 0, losses: 0 };
      agg[d].pnl += Number(t.pnl_amount) || 0;
      agg[d].trades += 1;
      if (t.result === 'win') agg[d].wins += 1;
      if (t.result === 'loss') agg[d].losses += 1;
    });
    setDayAgg(agg);

    const acc = accounts;
    if (acc) {
      setBalance(Number(acc.current_balance) || 0);
      const { data: rs } = await supabase
        .from('risk_settings')
        .select('daily_profit_target, is_active')
        .eq('user_id', user.id)
        .eq('account_id', acc.id)
        .maybeSingle();
      setDailyTarget(rs?.is_active ? Number(rs.daily_profit_target) : null);
    }

    setLoading(false);
  }, [user, monthStart, monthEnd]);

  useEffect(() => { loadMonth(); }, [loadMonth]);

  const openDay = async (dateStr: string) => {
    if (!user) return;
    setSelectedDate(dateStr);
    setDayTradesLoading(true);
    const { data } = await supabase
      .from('trades')
      .select('id, symbol, direction, result, pnl_amount, rr_ratio, entry_time')
      .eq('user_id', user.id)
      .eq('account_id', getActiveAccountId())
      .eq('trade_date', dateStr)
      .order('created_at', { ascending: true });
    setDayTrades(data || []);
    setDayTradesLoading(false);
  };

  // Build calendar grid: array of weeks, each week is 7 date-strings (or null for padding)
  const weeks = useMemo(() => {
    const year = monthCursor.getFullYear();
    const month = monthCursor.getMonth();
    const firstDay = new Date(year, month, 1);
    const startOffset = firstDay.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const cells: (string | null)[] = Array(startOffset).fill(null);
    for (let d = 1; d <= daysInMonth; d++) cells.push(toGregorianDateInput(new Date(year, month, d)));
    while (cells.length % 7 !== 0) cells.push(null);

    const rows: (string | null)[][] = [];
    for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));
    return rows;
  }, [monthCursor]);

  // Monthly stats
  const monthStats = useMemo(() => {
    const entries = Object.entries(dayAgg) as [string, DayAgg][];
    const totalPnl = entries.reduce((s, [, v]) => s + v.pnl, 0);
    const totalTrades = entries.reduce((s, [, v]) => s + v.trades, 0);
    const totalWins = entries.reduce((s, [, v]) => s + v.wins, 0);
    const totalLosses = entries.reduce((s, [, v]) => s + v.losses, 0);
    const closedTrades = totalWins + totalLosses;
    const winRate = closedTrades > 0 ? (totalWins / closedTrades) * 100 : 0;
    const bestDay: [string, DayAgg] | null = entries.length
      ? entries.reduce((best, current) => current[1].pnl > best[1].pnl ? current : best)
      : null;
    const worstDay: [string, DayAgg] | null = entries.length
      ? entries.reduce((worst, current) => current[1].pnl < worst[1].pnl ? current : worst)
      : null;
    const maxAbsPnl = entries.reduce((m, [, v]) => Math.max(m, Math.abs(v.pnl)), 0);
    return { totalPnl, totalTrades, winRate, bestDay, worstDay, maxAbsPnl };
  }, [dayAgg]);

  // Current streak: consecutive trading days (most recent backward) all wins or all losses
  const streak = useMemo(() => {
    const tradingDays = Object.entries(dayAgg) as [string, DayAgg][];
    const tradingDaysFiltered = tradingDays
      .filter(([, v]) => v.trades > 0)
      .sort((a, b) => b[0].localeCompare(a[0]));
    if (tradingDaysFiltered.length === 0) return { count: 0, type: null as 'win' | 'loss' | null, dates: new Set<string>() };
    const sign = tradingDaysFiltered[0][1].pnl >= 0 ? 'win' : 'loss';
    let count = 0;
    const dates = new Set<string>();
    for (const [d, v] of tradingDaysFiltered) {
      const s = v.pnl >= 0 ? 'win' : 'loss';
      if (s !== sign) break;
      count += 1;
      dates.add(d);
    }
    return { count, type: sign as 'win' | 'loss', dates };
  }, [dayAgg]);

  const monthLabel = monthCursor.toLocaleDateString('fa-IR', { month: 'long', year: 'numeric' });

  const getCellValue = (agg: DayAgg | undefined) => {
    if (!agg || agg.trades === 0) return null;
    if (metric === 'amount') return `${agg.pnl >= 0 ? '+' : ''}${formatCurrency(agg.pnl).replace('$', '')}`;
    if (metric === 'percent') {
      const pct = balance > 0 ? (agg.pnl / balance) * 100 : 0;
      return `${pct >= 0 ? '+' : ''}${pct.toFixed(1)}%`;
    }
    return String(agg.trades);
  };

  const getCellIntensity = (agg: DayAgg | undefined) => {
    if (!agg || agg.trades === 0 || monthStats.maxAbsPnl === 0) return 0;
    return Math.min(1, Math.abs(agg.pnl) / monthStats.maxAbsPnl);
  };

  const getCellBg = (agg: DayAgg | undefined) => {
    if (!agg || agg.trades === 0) return 'bg-dark-900/40 hover:bg-dark-800/60';
    const intensity = getCellIntensity(agg);
    if (agg.pnl > 0) {
      if (intensity > 0.66) return 'bg-success-500/35 hover:bg-success-500/45 border-success-500/40';
      if (intensity > 0.33) return 'bg-success-500/20 hover:bg-success-500/30 border-success-500/25';
      return 'bg-success-500/10 hover:bg-success-500/20 border-success-500/15';
    }
    if (agg.pnl < 0) {
      if (intensity > 0.66) return 'bg-danger-500/35 hover:bg-danger-500/45 border-danger-500/40';
      if (intensity > 0.33) return 'bg-danger-500/20 hover:bg-danger-500/30 border-danger-500/25';
      return 'bg-danger-500/10 hover:bg-danger-500/20 border-danger-500/15';
    }
    return 'bg-dark-500/15 hover:bg-dark-500/25';
  };

  const hitDailyTarget = (dateStr: string, agg: DayAgg | undefined) => {
    if (!dailyTarget || !agg || balance <= 0) return false;
    return (agg.pnl / balance) * 100 >= dailyTarget;
  };

  const weekTotal = (week: (string | null)[]) => {
    let pnl = 0, trades = 0;
    week.forEach(d => { if (d && dayAgg[d]) { pnl += dayAgg[d].pnl; trades += dayAgg[d].trades; } });
    return { pnl, trades };
  };

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-bold text-white">تقویم معاملات</h1>
        </div>
        <button
          onClick={() => setMonthCursor(new Date(new Date().getFullYear(), new Date().getMonth(), 1))}
          className="btn-secondary flex items-center gap-1.5 text-xs"
        >
          <CalendarCheck className="w-3.5 h-3.5" /> ماه جاری
        </button>
      </div>

      {/* Month summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="kpi-card">
          <span className="text-[11px] text-dark-400 flex items-center gap-1">
            {monthStats.totalPnl >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />} سود/زیان ماه
          </span>
          <p className={`text-lg font-bold number-ltr ${monthStats.totalPnl >= 0 ? 'profit-text' : 'loss-text'}`}>{formatCurrency(monthStats.totalPnl)}</p>
        </div>
        <div className="kpi-card">
          <span className="text-[11px] text-dark-400">وین‌ریت ماه</span>
          <p className="text-lg font-bold text-white number-ltr">{monthStats.winRate.toFixed(0)}%</p>
          <p className="text-[11px] text-dark-500 number-ltr">{monthStats.totalTrades} معامله</p>
        </div>
        <div className="kpi-card">
          <span className="text-[11px] text-dark-400 flex items-center gap-1"><Award className="w-3.5 h-3.5 text-success-400" /> بهترین روز</span>
          {monthStats.bestDay ? (
            <>
              <p className="text-sm font-bold profit-text number-ltr">{formatCurrency(monthStats.bestDay[1].pnl)}</p>
              <p className="text-[11px] text-dark-500">{toPersianDate(monthStats.bestDay[0])}</p>
            </>
          ) : <p className="text-sm text-dark-500">—</p>}
        </div>
        <div className="kpi-card">
          <span className="text-[11px] text-dark-400 flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5 text-danger-400" /> بدترین روز</span>
          {monthStats.worstDay ? (
            <>
              <p className="text-sm font-bold loss-text number-ltr">{formatCurrency(monthStats.worstDay[1].pnl)}</p>
              <p className="text-[11px] text-dark-500">{toPersianDate(monthStats.worstDay[0])}</p>
            </>
          ) : <p className="text-sm text-dark-500">—</p>}
        </div>
      </div>

      {/* Streak banner */}
      {streak.count >= 2 && (
        <div className={`glass-card p-3 flex items-center gap-2.5 border ${streak.type === 'win' ? 'border-success-500/25 bg-success-500/5' : 'border-danger-500/25 bg-danger-500/5'}`}>
          {streak.type === 'win' ? <Flame className="w-5 h-5 text-success-400 flex-shrink-0" /> : <Snowflake className="w-5 h-5 text-danger-400 flex-shrink-0" />}
          <p className={`text-sm font-medium ${streak.type === 'win' ? 'text-success-400' : 'text-danger-400'}`}>
            {streak.count} روز متوالی {streak.type === 'win' ? 'سودده' : 'ضررده'}
          </p>
        </div>
      )}

      {/* Controls */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-1">
          <button onClick={() => setMonthCursor(m => new Date(m.getFullYear(), m.getMonth() - 1, 1))} className="p-2 rounded-lg text-dark-400 hover:text-white hover:bg-white/5">
            <ChevronRight className="w-4 h-4" />
          </button>
          <h2 className="text-sm font-semibold text-white w-32 text-center">{monthLabel}</h2>
          <button onClick={() => setMonthCursor(m => new Date(m.getFullYear(), m.getMonth() + 1, 1))} className="p-2 rounded-lg text-dark-400 hover:text-white hover:bg-white/5">
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
        <div className="flex gap-1 bg-dark-900/60 rounded-lg p-1 border border-white/10">
          {([
            { key: 'amount', label: 'دلاری' },
            { key: 'percent', label: 'درصد' },
            { key: 'trades', label: 'تعداد' },
          ] as { key: Metric; label: string }[]).map(m => (
            <button
              key={m.key}
              onClick={() => setMetric(m.key)}
              className={`text-xs px-3 py-1.5 rounded-md transition-colors ${metric === m.key ? 'bg-gold-500/20 text-gold-400' : 'text-dark-400 hover:text-white'}`}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* Calendar grid */}
      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="glass-card p-3 md:p-4 overflow-x-auto">
          <div className="min-w-[640px]">
            <div className="grid grid-cols-8 gap-1.5 mb-2">
              {['ی', 'د', 'س', 'چ', 'پ', 'ج', 'ش'].map(d => (
                <div key={d} className="text-center text-[11px] text-dark-500 font-medium py-1">{d}</div>
              ))}
              <div className="text-center text-[11px] text-gold-400 font-medium py-1">جمع هفته</div>
            </div>

            <div className="space-y-1.5">
              {weeks.map((week, wi) => {
                const wt = weekTotal(week);
                const hasAny = week.some(d => d && dayAgg[d]);
                return (
                  <div key={wi} className="grid grid-cols-8 gap-1.5">
                    {week.map((dateStr, di) => {
                      if (!dateStr) return <div key={di} className="aspect-square" />;
                      const agg = dayAgg[dateStr];
                      const isToday = dateStr === todayStr;
                      const inStreak = streak.dates.has(dateStr);
                      const targetHit = hitDailyTarget(dateStr, agg);
                      const value = getCellValue(agg);
                      return (
                        <button
                          key={dateStr}
                          onClick={() => openDay(dateStr)}
                          className={`relative aspect-square rounded-lg border p-1 flex flex-col items-center justify-center gap-0.5 transition-colors ${getCellBg(agg)} ${
                            isToday ? 'ring-1 ring-gold-500/60' : ''
                          } ${inStreak ? 'ring-1 ring-offset-0 ' + (streak.type === 'win' ? 'ring-success-400/50' : 'ring-danger-400/50') : ''}`}
                        >
                          {targetHit && <Star className="w-2.5 h-2.5 text-gold-400 absolute top-1 left-1 fill-gold-400" />}
                          <span className="text-[11px] text-white number-ltr">{parseDateOnly(dateStr)?.getDate() || 0}</span>
                          {value && (
                            <span className={`text-[9px] number-ltr ${agg!.pnl > 0 ? 'text-success-400' : agg!.pnl < 0 ? 'text-danger-400' : 'text-dark-300'}`}>
                              {value}
                            </span>
                          )}
                        </button>
                      );
                    })}
                    {/* Weekly total column */}
                    <div className={`aspect-square rounded-lg border border-white/5 flex flex-col items-center justify-center gap-0.5 ${hasAny ? 'bg-dark-800/60' : 'bg-dark-900/20'}`}>
                      {hasAny ? (
                        <>
                          <span className={`text-[10px] font-semibold number-ltr ${wt.pnl >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                            {wt.pnl >= 0 ? '+' : ''}{formatCurrency(wt.pnl).replace('$', '')}
                          </span>
                          <span className="text-[9px] text-dark-500 number-ltr">{wt.trades} معامله</span>
                        </>
                      ) : <span className="text-[10px] text-dark-600">—</span>}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center gap-4 mt-3 pt-3 border-t border-white/5 text-[11px] text-dark-500 flex-wrap">
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-success-500/35 border border-success-500/40" /> سودده (شدت = میزان سود)</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-danger-500/35 border border-danger-500/40" /> ضررده</span>
              <span className="flex items-center gap-1"><Star className="w-3 h-3 text-gold-400 fill-gold-400" /> رسیدن به هدف سود روزانه</span>
              {streak.count >= 2 && (
                <span className="flex items-center gap-1">
                  <span className={`w-2.5 h-2.5 rounded-full ring-1 ${streak.type === 'win' ? 'ring-success-400/50' : 'ring-danger-400/50'}`} /> استریک فعلی
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Day detail slide-over */}
      {selectedDate && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedDate(null)} />
          <div className="relative w-full max-w-md bg-dark-900 border-r border-white/10 h-full overflow-y-auto p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">{toPersianDate(selectedDate)}</h3>
              <button onClick={() => setSelectedDate(null)} className="text-dark-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {dayAgg[selectedDate] && (
              <div className="grid grid-cols-3 gap-2">
                <div className="rounded-lg bg-dark-800/60 p-2.5 text-center">
                  <p className="text-[11px] text-dark-400">معاملات</p>
                  <p className="text-sm font-semibold text-white number-ltr">{dayAgg[selectedDate].trades}</p>
                </div>
                <div className="rounded-lg bg-dark-800/60 p-2.5 text-center">
                  <p className="text-[11px] text-dark-400">برد/باخت</p>
                  <p className="text-sm font-semibold text-white number-ltr">{dayAgg[selectedDate].wins}/{dayAgg[selectedDate].losses}</p>
                </div>
                <div className="rounded-lg bg-dark-800/60 p-2.5 text-center">
                  <p className="text-[11px] text-dark-400">سود/زیان</p>
                  <p className={`text-sm font-semibold number-ltr ${dayAgg[selectedDate].pnl >= 0 ? 'profit-text' : 'loss-text'}`}>{formatCurrency(dayAgg[selectedDate].pnl)}</p>
                </div>
              </div>
            )}

            {dayTradesLoading ? (
              <div className="flex justify-center py-8">
                <div className="w-6 h-6 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : dayTrades.length === 0 ? (
              <p className="text-sm text-dark-500 text-center py-8">معامله‌ای در این روز ثبت نشده است.</p>
            ) : (
              <div className="space-y-2">
                {dayTrades.map(t => (
                  <button
                    key={t.id}
                    onClick={() => navigate(`/trade/${t.id}`)}
                    className="w-full flex items-center justify-between gap-2 rounded-lg bg-dark-800/60 hover:bg-dark-800 border border-white/5 p-3 text-right transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-semibold ${t.direction === 'buy' ? 'text-success-400' : 'text-danger-400'}`}>
                        {t.direction === 'buy' ? '▲' : '▼'}
                      </span>
                      <div>
                        <p className="text-sm text-white font-mono">{t.symbol}</p>
                        <span className={getResultBadgeClass(t.result)}>{getResultLabel(t.result)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className={`text-sm font-semibold number-ltr ${(t.pnl_amount || 0) >= 0 ? 'profit-text' : 'loss-text'}`}>{formatCurrency(t.pnl_amount)}</p>
                      <ArrowUpRight className="w-3.5 h-3.5 text-dark-500" />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}