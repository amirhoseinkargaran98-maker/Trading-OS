import { useState, useEffect, useCallback } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Cell, RadarChart, PolarGrid, PolarAngleAxis, Radar, LineChart, Line
} from 'recharts';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency, getDayName, getSessionLabel, getHourLabel, getDayOfWeekFromDateInput } from '@/lib/utils';
import MonthlyReportButton from '@/components/MonthlyReportButton';
import {
  calculateWinRate, calculateAverageWin, calculateAverageLoss,
  calculateProfitFactor, calculateExpectancy, calculateAveragePlannedRR,
  compareTradeChronological,
} from '@/lib/tradingEngine';
import { BarChart2, TrendingUp, Award, Activity, Zap, Clock, Target, Grid3x3, Sparkles, ShieldAlert, Trophy, Info } from 'lucide-react';
import { discoverPatterns, discoverySummary, type PatternRow } from '@/lib/patternDiscovery';

type Breakdown = { label: string; pnl: number; wins: number; losses: number; trades: number; winRate: number };

function computeBreakdown(trades: any[], key: string, labelFn: (v: string) => string): Breakdown[] {
  const map: Record<string, { pnl: number; wins: number; losses: number; total: number }> = {};
  for (const t of trades) {
    const k = String(t[key] || 'نامشخص');
    if (!map[k]) map[k] = { pnl: 0, wins: 0, losses: 0, total: 0 };
    map[k].pnl += t.pnl_amount || 0;
    map[k].total++;
    if (t.result === 'win') map[k].wins++;
    if (t.result === 'loss') map[k].losses++;
  }
  return Object.entries(map)
    .map(([k, v]) => ({
      label: labelFn(k),
      pnl: v.pnl,
      wins: v.wins,
      losses: v.losses,
      trades: v.total,
      winRate: v.total > 0 ? (v.wins / v.total) * 100 : 0,
    }))
    .sort((a, b) => b.pnl - a.pnl);
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div className="glass-card p-3 text-xs min-w-[150px]">
      <p className="text-white font-semibold mb-1">{label}</p>
      <p className={d.pnl >= 0 ? 'text-success-400' : 'text-danger-400'}>{formatCurrency(d.pnl)}</p>
      <p className="text-dark-400">Win Rate: {d.winRate?.toFixed(1)}%</p>
      <p className="text-dark-400">معاملات: {d.trades}</p>
    </div>
  );
};

function BreakdownChart({ title, data, icon: Icon }: { title: string; data: Breakdown[]; icon: React.ElementType }) {
  if (!data.length) return null;
  return (
    <div className="glass-card p-4">
      <h2 className="section-title"><Icon className="w-4 h-4 text-gold-400" />{title}</h2>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data} layout="vertical" margin={{ left: 10, right: 10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={false} />
          <XAxis type="number" tick={{ fill: '#6c757d', fontSize: 10 }} tickLine={false} axisLine={false} tickFormatter={v => `$${v.toFixed(0)}`} />
          <YAxis dataKey="label" type="category" tick={{ fill: '#adb5bd', fontSize: 11 }} tickLine={false} axisLine={false} width={60} />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="pnl" radius={[0, 4, 4, 0]}>
            {data.map((entry, i) => (
              <Cell key={i} fill={entry.pnl >= 0 ? '#22c55e' : '#ef4444'} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function StatCard({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="bg-dark-800/60 border border-white/5 rounded-xl p-3">
      <p className="text-xs text-dark-400">{label}</p>
      <p className="text-lg font-bold text-white number-ltr mt-0.5">{value}</p>
      {sub && <p className="text-xs text-dark-500">{sub}</p>}
    </div>
  );
}

function PatternTable({ rows, positive }: { rows: PatternRow[]; positive: boolean }) {
  if (!rows.length) return <p className="text-sm text-dark-500 text-center py-6">هنوز داده کافی برای این بخش وجود ندارد.</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[760px]">
        <thead><tr>
          <th className="table-th text-right">ترکیب</th><th className="table-th">تعداد</th><th className="table-th">Win Rate</th><th className="table-th">Avg R</th><th className="table-th">P&L</th><th className="table-th">Process</th><th className="table-th">سطح شواهد</th>
        </tr></thead>
        <tbody>{rows.map(r => (
          <tr key={r.id}>
            <td className="table-td"><div className="flex flex-wrap gap-1.5">{r.dimensions.map(d => <span key={d.dimension} className="px-2 py-1 rounded-lg bg-dark-800 text-white text-[11px]">{d.label}</span>)}</div></td>
            <td className="table-td text-center number-ltr">{r.trades}</td>
            <td className="table-td text-center number-ltr">{r.winRate.toFixed(0)}%</td>
            <td className={`table-td text-center number-ltr font-semibold ${r.avgR>=0?'text-success-400':'text-danger-400'}`}>{r.avgR>=0?'+':''}{r.avgR.toFixed(2)}R</td>
            <td className={`table-td text-center number-ltr ${r.pnl>=0?'text-success-400':'text-danger-400'}`}>{r.pnl>=0?'+':''}${r.pnl.toFixed(0)}</td>
            <td className="table-td text-center number-ltr">{r.avgProcess==null?'—':r.avgProcess.toFixed(0)}</td>
            <td className="table-td text-center"><span className={`text-[10px] px-2 py-1 rounded-full ${r.confidence==='strong'?'bg-success-500/10 text-success-400':r.confidence==='moderate'?'bg-gold-500/10 text-gold-400':'bg-dark-800 text-dark-400'}`}>{r.confidence==='strong'?'قوی':r.confidence==='moderate'?'متوسط':'کم'}</span></td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}

export default function Analytics() {
  const { user } = useAuth();
  const [trades, setTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'overview' | 'symbols' | 'sessions' | 'strategies' | 'days' | 'hours' | 'distribution' | 'heatmap' | 'patterns'>('overview');

  useEffect(() => {
    if (!user) return;
    supabase
      .from('trades')
      .select('*')
      .eq('user_id', user.id)
      .eq('account_id', getActiveAccountId())
      .not('result', 'eq', 'open')
      .order('trade_date', { ascending: true })
      .order('entry_time', { ascending: true })
      .then(({ data }) => {
        setTrades(data || []);
        setLoading(false);
      });
  }, [user]);

  const closed = trades.filter(t => t.pnl_amount !== null);
  const wins = closed.filter(t => t.result === 'win');
  const losses = closed.filter(t => t.result === 'loss');
  const winRate = calculateWinRate(closed);
  const avgWin = calculateAverageWin(closed);
  const avgLoss = calculateAverageLoss(closed);
  const profitFactor = calculateProfitFactor(closed);
  const expectancy = calculateExpectancy(closed);
  const avgRR = calculateAveragePlannedRR(closed);
  const totalR = closed.filter(t => t.r_multiple).reduce((s, t) => s + (t.r_multiple || 0), 0);

  // Streak — sort chronologically ourselves; DB order alone isn't reliable
  // for same-day trades (see compareTradeChronological in tradingEngine.ts).
  let bestStreak = 0, worstStreak = 0, curWin = 0, curLoss = 0;
  const chronoClosed = [...closed].sort((a, b) => compareTradeChronological(a, b));
  for (const t of chronoClosed) {
    if (t.result === 'win') { curWin++; curLoss = 0; bestStreak = Math.max(bestStreak, curWin); }
    else { curLoss++; curWin = 0; worstStreak = Math.max(worstStreak, curLoss); }
  }

  // Day breakdown — all 7 weekdays (was missing Friday/Saturday: 5 and 6)
  const dayBreakdown = [0, 1, 2, 3, 4, 5, 6].map(day => {
    const dt = closed.filter(t => getDayOfWeekFromDateInput(t.trade_date) === day);
    const dw = dt.filter(t => t.result === 'win').length;
    return {
      label: getDayName(day),
      pnl: dt.reduce((s, t) => s + t.pnl_amount, 0),
      wins: dw, losses: dt.length - dw, trades: dt.length,
      winRate: dt.length ? (dw / dt.length) * 100 : 0,
    };
  });

  // Hour breakdown
  const hourBreakdown = Array.from({ length: 24 }, (_, h) => {
    const ht = closed.filter(t => t.entry_time && new Date(t.entry_time).getHours() === h);
    const hw = ht.filter(t => t.result === 'win').length;
    return {
      label: getHourLabel(h),
      pnl: ht.reduce((s, t) => s + t.pnl_amount, 0),
      wins: hw, losses: ht.length - hw, trades: ht.length,
      winRate: ht.length ? (hw / ht.length) * 100 : 0,
    };
  }).filter(h => h.trades > 0);

  const symbolBreakdown = computeBreakdown(closed, 'symbol', v => v);
  const sessionBreakdown = computeBreakdown(closed, 'session', getSessionLabel);
  const directionBreakdown = computeBreakdown(closed, 'direction', v => v === 'buy' ? 'خرید' : 'فروش');

  // AI-free multidimensional edge discovery. Patterns are descriptive, not predictive.
  const patterns = discoverPatterns(closed);
  const patternSummary = discoverySummary(patterns);

  // R-Multiple distribution histogram
  const R_BUCKETS = [
    { label: '< -2R', test: (r: number) => r < -2 },
    { label: '-2 تا -1R', test: (r: number) => r >= -2 && r < -1 },
    { label: '-1 تا 0R', test: (r: number) => r >= -1 && r < 0 },
    { label: '0 تا 1R', test: (r: number) => r >= 0 && r < 1 },
    { label: '1 تا 2R', test: (r: number) => r >= 1 && r < 2 },
    { label: '2 تا 3R', test: (r: number) => r >= 2 && r < 3 },
    { label: '> 3R', test: (r: number) => r >= 3 },
  ];
  const rMultiples = closed.filter(t => t.r_multiple !== null && t.r_multiple !== undefined).map(t => Number(t.r_multiple));
  const rHistogram = R_BUCKETS.map(b => ({
    label: b.label,
    count: rMultiples.filter(b.test).length,
  }));

  // Day x Session heatmap matrix
  const HEATMAP_SESSIONS = ['london', 'new_york', 'asian', 'sydney'];
  const heatmapDays = [0, 1, 2, 3, 4, 5, 6];
  const heatmapMatrix = heatmapDays.map(day => {
    const row = HEATMAP_SESSIONS.map(session => {
      const cellTrades = closed.filter(t => getDayOfWeekFromDateInput(t.trade_date) === day && t.session === session);
      const cellWins = cellTrades.filter(t => t.result === 'win').length;
      return {
        session,
        trades: cellTrades.length,
        winRate: cellTrades.length ? (cellWins / cellTrades.length) * 100 : null,
        pnl: cellTrades.reduce((s, t) => s + (t.pnl_amount || 0), 0),
      };
    });
    return { day, dayLabel: getDayName(day), cells: row };
  }).filter(row => row.cells.some(c => c.trades > 0));

  const tabs = [
    { key: 'overview', label: 'خلاصه' },
    { key: 'symbols', label: 'نمادها' },
    { key: 'sessions', label: 'سشن‌ها' },
    { key: 'strategies', label: 'استراتژی' },
    { key: 'days', label: 'روزها' },
    { key: 'hours', label: 'ساعات' },
    { key: 'distribution', label: 'توزیع R' },
    { key: 'heatmap', label: 'نقشه حرارتی' },
    { key: 'patterns', label: 'کشف Edge' },
  ] as const;

  if (loading) return (
    <div className="page-container flex items-center justify-center py-20">
      <div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="page-container" dir="rtl">
      <h1 className="text-xl font-bold text-white mb-4 flex items-center justify-between gap-2">
        <span className="flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-gold-400" />
          تحلیل عملکرد
        </span>
        <MonthlyReportButton />
      </h1>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-dark-900 rounded-xl overflow-x-auto mb-4">
        {tabs.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              tab === t.key ? 'bg-gold-500 text-dark-950' : 'text-dark-400 hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="space-y-4">
          {/* Stats grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-5 gap-3">
            <StatCard label="Win Rate" value={`${winRate.toFixed(1)}%`} sub={`${wins.length}W / ${losses.length}L`} />
            <StatCard label="Profit Factor" value={profitFactor >= 999 ? '∞' : profitFactor.toFixed(2)} />
            <StatCard label="Expectancy" value={formatCurrency(expectancy)} />
            <StatCard label="میانگین R:R" value={`${avgRR.toFixed(2)}R`} />
            <StatCard label="مجموع R" value={`${totalR > 0 ? '+' : ''}${totalR.toFixed(2)}R`} />
            <StatCard label="میانگین سود" value={formatCurrency(avgWin)} />
            <StatCard label="میانگین ضرر" value={formatCurrency(-avgLoss)} />
            <StatCard label="بهترین سری برد" value={`${bestStreak} پشت سر هم`} />
            <StatCard label="بدترین سری باخت" value={`${worstStreak} پشت سر هم`} />
            <StatCard label="کل معاملات" value={String(closed.length)} />
          </div>

          {/* Day breakdown */}
          <div className="glass-card p-4">
            <h2 className="section-title"><Activity className="w-4 h-4 text-gold-400" />عملکرد روزهای هفته</h2>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={dayBreakdown}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="label" tick={{ fill: '#adb5bd', fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: '#6c757d', fontSize: 10 }} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
                  {dayBreakdown.map((d, i) => <Cell key={i} fill={d.pnl >= 0 ? '#22c55e' : '#ef4444'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Direction */}
          <BreakdownChart title="عملکرد بر اساس جهت" data={directionBreakdown} icon={TrendingUp} />
        </div>
      )}

      {tab === 'symbols' && <BreakdownChart title="عملکرد بر اساس نماد" data={symbolBreakdown} icon={BarChart2} />}
      {tab === 'sessions' && <BreakdownChart title="عملکرد بر اساس سشن" data={sessionBreakdown} icon={Activity} />}

      {tab === 'strategies' && (
        <div className="space-y-4">
          <BreakdownChart
            title="عملکرد استراتژی‌ها"
            data={computeBreakdown(closed, 'strategy_id', v => v === 'null' || !v ? 'بدون استراتژی' : v)}
            icon={Award}
          />
          <BreakdownChart
            title="عملکرد ستاپ‌ها"
            data={computeBreakdown(closed, 'setup_id', v => v === 'null' || !v ? 'بدون ستاپ' : v)}
            icon={Zap}
          />
        </div>
      )}

      {tab === 'days' && (
        <div className="glass-card p-4">
          <h2 className="section-title"><Activity className="w-4 h-4 text-gold-400" />عملکرد روزهای هفته</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-th">روز</th>
                  <th className="table-th">معاملات</th>
                  <th className="table-th">برنده</th>
                  <th className="table-th">بازنده</th>
                  <th className="table-th">Win Rate</th>
                  <th className="table-th">P&L</th>
                </tr>
              </thead>
              <tbody>
                {dayBreakdown.map(d => (
                  <tr key={d.label} className="table-row-hover">
                    <td className="table-td font-medium">{d.label}</td>
                    <td className="table-td text-dark-300">{d.trades}</td>
                    <td className="table-td text-success-400">{d.wins}</td>
                    <td className="table-td text-danger-400">{d.losses}</td>
                    <td className="table-td text-white">{d.winRate.toFixed(1)}%</td>
                    <td className={`table-td font-semibold number-ltr ${d.pnl >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                      {formatCurrency(d.pnl)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'hours' && (
        <div className="space-y-4">
          <div className="glass-card p-4">
            <h2 className="section-title"><Clock className="w-4 h-4 text-gold-400" />عملکرد بر اساس ساعت</h2>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={hourBreakdown}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="label" tick={{ fill: '#adb5bd', fontSize: 9 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: '#6c757d', fontSize: 9 }} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="pnl" radius={[3, 3, 0, 0]}>
                  {hourBreakdown.map((h, i) => <Cell key={i} fill={h.pnl >= 0 ? '#22c55e' : '#ef4444'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {closed.length === 0 && (
        <div className="glass-card p-12 text-center text-dark-400">
          <BarChart2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>برای مشاهده تحلیل، معاملات خود را ثبت کنید.</p>
        </div>
      )}

      {tab === 'distribution' && closed.length > 0 && (
        <div className="glass-card p-4">
          <h2 className="section-title"><Target className="w-4 h-4 text-gold-400" />توزیع R-Multiple</h2>
          <p className="text-[11px] text-dark-500 mb-2">تعداد معاملات بر اساس اینکه چند برابر ریسک اولیه، سود یا زیان کرده‌اند.</p>
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={rHistogram}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="label" tick={{ fill: '#adb5bd', fontSize: 10 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fill: '#6c757d', fontSize: 10 }} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload;
                  return (
                    <div className="glass-card p-2.5 text-xs">
                      <p className="text-white font-semibold">{d.label}</p>
                      <p className="text-dark-400">{d.count} معامله</p>
                    </div>
                  );
                }}
              />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {rHistogram.map((d, i) => (
                  <Cell key={i} fill={d.label.includes('-') ? '#ef4444' : '#22c55e'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {tab === 'patterns' && (
        <div className="space-y-4">
          <div className="glass-card p-4 border border-gold-500/15">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="section-title mb-1"><Sparkles className="w-4 h-4 text-gold-400" />موتور کشف Edge شخصی</h2>
                <p className="text-[11px] text-dark-500 leading-5">ترکیب‌های واقعیِ سشن، نماد، جهت، دلیل ورود، روانشناسی و ریسک بررسی می‌شوند. این موتور بدون AI کار می‌کند و هیچ ترکیبی را فقط با چند معامله «استراتژی برنده» اعلام نمی‌کند.</p>
              </div>
              <div className="text-left text-[10px] text-dark-500 whitespace-nowrap"><Info className="w-4 h-4 inline ml-1" />حداقل ۵ معامله برای نمایش</div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard label="ترکیب‌های بررسی‌شده" value={String(patternSummary.patterns)} />
            <StatCard label="Edgeهای مثبت" value={String(patternSummary.edges)} sub={`${patternSummary.strong} ترکیب با نمونه قوی`} />
            <StatCard label="هشدارهای منفی" value={String(patternSummary.warnings)} />
            <StatCard label="معاملات پایه" value={String(closed.length)} sub="داده‌های بسته‌شده" />
          </div>

          {patternSummary.edges === 0 && patternSummary.warnings === 0 ? (
            <div className="glass-card p-10 text-center text-dark-400">
              <Sparkles className="w-10 h-10 mx-auto mb-3 text-gold-500/40" />
              <p className="text-sm">هنوز Edge قابل اتکایی پیدا نشده است.</p>
              <p className="text-[11px] text-dark-600 mt-2">به ثبت منظم Setup، روانشناسی، سشن و نتیجه ادامه بده؛ سیستم با افزایش داده دوباره الگوها را ارزیابی می‌کند.</p>
            </div>
          ) : (
            <>
              <div className="glass-card p-4">
                <h2 className="section-title"><Trophy className="w-4 h-4 text-gold-400" />قوی‌ترین ترکیب‌های مثبت</h2>
                <PatternTable rows={patternSummary.topEdges} positive />
              </div>
              <div className="glass-card p-4">
                <h2 className="section-title"><ShieldAlert className="w-4 h-4 text-gold-400" />ترکیب‌های نیازمند بازبینی</h2>
                <PatternTable rows={patternSummary.topWarnings} positive={false} />
              </div>
            </>
          )}

          <div className="glass-card p-4">
            <h2 className="section-title"><Activity className="w-4 h-4 text-gold-400" />منطق اعتبارسنجی</h2>
            <div className="grid md:grid-cols-3 gap-3 text-[11px] text-dark-400 leading-5">
              <div className="rounded-xl bg-dark-900/60 p-3"><b className="text-white">نمونه:</b> کمتر از ۵ معامله اصلاً Edge محسوب نمی‌شود.</div>
              <div className="rounded-xl bg-dark-900/60 p-3"><b className="text-white">اعتماد:</b> ۵–۹ کم، ۱۰–۲۹ متوسط، ۳۰+ قوی؛ این «اعتماد آماری» رسمی نیست.</div>
              <div className="rounded-xl bg-dark-900/60 p-3"><b className="text-white">تصمیم:</b> Edge فقط برای تحقیق و Review است، نه مجوز افزایش ریسک یا تغییر پلن.</div>
            </div>
          </div>
        </div>
      )}

      {tab === 'heatmap' && (
        <div className="glass-card p-4">
          <h2 className="section-title"><Grid3x3 className="w-4 h-4 text-gold-400" />نقشه حرارتی روز × سشن</h2>
          <p className="text-[11px] text-dark-500 mb-3">رنگ هر خانه بر اساس وین‌ریت آن ترکیب روز/سشن است؛ هرچی پررنگ‌تر، قابل‌اعتمادتر.</p>
          {heatmapMatrix.length === 0 ? (
            <p className="text-sm text-dark-500 text-center py-8">داده‌ی کافی برای نمایش نقشه حرارتی وجود ندارد.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[480px]">
                <thead>
                  <tr>
                    <th className="table-th">روز</th>
                    {HEATMAP_SESSIONS.map(s => <th key={s} className="table-th text-center">{getSessionLabel(s)}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {heatmapMatrix.map(row => (
                    <tr key={row.day}>
                      <td className="table-td font-medium">{row.dayLabel}</td>
                      {row.cells.map(cell => {
                        if (cell.trades === 0) {
                          return <td key={cell.session} className="table-td text-center text-dark-700">—</td>;
                        }
                        const intensity = cell.winRate === null ? 0 : cell.winRate / 100;
                        const bg = cell.pnl >= 0
                          ? `rgba(34,197,94,${0.15 + intensity * 0.45})`
                          : `rgba(239,68,68,${0.15 + (1 - intensity) * 0.45})`;
                        return (
                          <td key={cell.session} className="table-td text-center">
                            <div className="rounded-lg py-1.5 px-1" style={{ backgroundColor: bg }}>
                              <p className="text-xs font-semibold text-white number-ltr">{cell.winRate?.toFixed(0)}%</p>
                              <p className="text-[10px] text-dark-300 number-ltr">{cell.trades} معامله</p>
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}