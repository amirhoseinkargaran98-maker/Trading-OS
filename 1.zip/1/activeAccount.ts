export const ACTIVE_ACCOUNT_STORAGE_KEY = 'trading-os-active-account-id';

export function getActiveAccountId(): string | null {
  try {
    return window.localStorage.getItem(ACTIVE_ACCOUNT_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setActiveAccountId(id: string): void {
  try {
    window.localStorage.setItem(ACTIVE_ACCOUNT_STORAGE_KEY, id);
    window.dispatchEvent(new CustomEvent('trading-os-active-account-changed', { detail: id }));
  } catch {
    // Ignore storage failures; app can continue using the in-memory selection.
  }
}

export function clearActiveAccountId(): void {
  try {
    window.localStorage.removeItem(ACTIVE_ACCOUNT_STORAGE_KEY);
    window.dispatchEvent(new CustomEvent('trading-os-active-account-changed', { detail: null }));
  } catch {
    // Ignore storage failures.
  }
}
