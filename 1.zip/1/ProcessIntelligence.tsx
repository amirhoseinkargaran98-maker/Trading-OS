import { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Brain, CheckCircle2, CircleDollarSign, Gauge, Layers3, RefreshCw, ShieldAlert, Target, TrendingDown, TrendingUp, Trophy, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { toGregorianDateInput, addDateInputDays, formatCurrency, formatPercent, getSessionLabel, getResultLabel, toPersianDate } from '@/lib/utils';

type Trade = any;
type Finding = { severity:'high'|'medium'|'low'; title:string; detail:string; evidence:string; action:string };

const badTags = new Set(['fomo','revenge','overtrading','fear','greed','anger','hesitation']);
const labelTag = (v:string) => ({fomo:'FOMO',revenge:'انتقام',overtrading:'اورترید',fear:'ترس',greed:'طمع',anger:'عصبانیت',hesitation:'تردید'} as any)[v] || v;

function num(v:any){ const n=Number(v); return Number.isFinite(n)?n:0; }
function tags(t:Trade):string[]{ return Array.isArray(t.psychology_tags)?t.psychology_tags:(typeof t.psychology_tags==='string'?t.psychology_tags.split(',').map((x:string)=>x.trim()).filter(Boolean):[]); }

export default function ProcessIntelligence(){
 const {user}=useAuth(); const [trades,setTrades]=useState<Trade[]>([]); const [loading,setLoading]=useState(true); const [error,setError]=useState<string|null>(null); const [period,setPeriod]=useState<'all'|'90'|'30'|'7'>('all');
 const load=useCallback(async()=>{ if(!user)return; setLoading(true); setError(null); const [tr,st,su]=await Promise.all([supabase.from('trades').select('*').eq('user_id',user.id).eq('account_id', getActiveAccountId()).not('result','eq','open').order('trade_date',{ascending:true}).order('entry_time',{ascending:true}),supabase.from('strategies').select('id,name').eq('user_id',user.id),supabase.from('setups').select('id,name').eq('user_id',user.id)]); if(tr.error){setTrades([]);setError('دریافت معاملات برای تحلیل فرآیند ناموفق بود.');setLoading(false);return;} if(st.error||su.error)setError('نام استراتژی/ستاپ کامل بارگذاری نشد؛ تحلیل با داده معاملات ادامه پیدا می‌کند.'); const sm=new Map((st.data||[]).map((x:{id:string;name:string})=>[x.id,x.name])); const um=new Map((su.data||[]).map((x:{id:string;name:string})=>[x.id,x.name])); setTrades((tr.data||[]).map((t:Trade)=>({...t,strategies:t.strategy_id?{name:sm.get(t.strategy_id)||'بدون نام'}:null,setups:t.setup_id?{name:um.get(t.setup_id)||'بدون نام'}:null}))); setLoading(false);},[user]);
 useEffect(()=>{load()},[load]);
 const closed=useMemo(()=>{ if(period==='all')return trades; const today=toGregorianDateInput(new Date()); const cutoff=addDateInputDays(today,-Number(period)); return trades.filter(t=>t.trade_date>=cutoff&&t.trade_date<=today);},[trades,period]);

 const m=useMemo(()=>{
   const total=closed.length, pnl=closed.reduce((a,t)=>a+num(t.pnl_amount),0), violations=closed.filter(t=>num(t.process_score)<70 || t.review_completed===false || badTagsIntersection(t).length).length;
   const scored=closed.filter(t=>Number.isFinite(Number(t.process_score)));
   const disciplineCost=scored.filter(t=>num(t.process_score)<70).reduce((a,t)=>a+num(t.pnl_amount),0);
   const avgProcess=scored.length?scored.reduce((a,t)=>a+num(t.process_score),0)/scored.length:0;
   const reviewed=total?closed.filter(t=>t.review_completed===true || String(t.review_completed)==='true').length/total*100:0;
   const riskCreep=closed.filter(t=>num(t.risk_percent)>1).length;
   const byTag:Record<string,{n:number;pnl:number;r:number}>={};
   closed.forEach(t=>tags(t).forEach(x=>{const k=labelTag(x);byTag[k]??={n:0,pnl:0,r:0};byTag[k].n++;byTag[k].pnl+=num(t.pnl_amount);byTag[k].r+=num(t.r_multiple)}));
   const worstTags=Object.entries(byTag).map(([tag,v])=>({tag,...v,avgR:v.n?v.r/v.n:0})).filter(x=>x.n>=2).sort((a,b)=>a.avgR-b.avgR).slice(0,5);
   const byStrategy:Record<string,{n:number;pnl:number;r:number}>={};
   closed.forEach(t=>{const k=t.strategies?.name||'بدون استراتژی';byStrategy[k]??={n:0,pnl:0,r:0};byStrategy[k].n++;byStrategy[k].pnl+=num(t.pnl_amount);byStrategy[k].r+=num(t.r_multiple)});
   const strategyRows=Object.entries(byStrategy).map(([name,v])=>({name,...v,avgR:v.n?v.r/v.n:0})).sort((a,b)=>a.avgR-b.avgR);
   return {total,pnl,violations,disciplineCost,avgProcess,reviewed,riskCreep,worstTags,strategyRows};
 },[closed]);

 const findings=useMemo<Finding[]>(()=>{const out:Finding[]=[]; if(!m.total)return out;
   if(m.avgProcess<70)out.push({severity:'high',title:'کیفیت اجرای فرآیند پایین است',detail:`میانگین امتیاز فرآیند ${m.avgProcess.toFixed(0)} از 100 است.`,evidence:`${m.total} معامله بررسی شده`,action:'قبل از تمرکز روی سود، اجرای قوانین ورود و خروج را تثبیت کن.'});
   if(m.reviewed<80)out.push({severity:'medium',title:'انضباط ژورنال نیاز به تقویت دارد',detail:`فقط ${m.reviewed.toFixed(0)}٪ معاملات مرور کامل دارند.`,evidence:`${m.total-Math.round(m.total*m.reviewed/100)} معامله بدون Review کامل`,action:'مرور معامله را به مرحله اجباری بعد از خروج تبدیل کن.'});
   if(m.riskCreep)out.push({severity:'high',title:'Risk Creep مشاهده شد',detail:`${m.riskCreep} معامله با ریسک بالاتر از 1٪ ثبت شده.`,evidence:'سقف رسمی ریسک 1٪',action:'قبل از ورود بعدی Risk Guard را بدون Override اجرا کن.'});
   if(m.worstTags.length&&m.worstTags[0].avgR<0)out.push({severity:'high',title:`گران‌ترین الگوی روانی: ${m.worstTags[0].tag}`,detail:`میانگین ${m.worstTags[0].avgR.toFixed(2)}R در ${m.worstTags[0].n} معامله.`,evidence:`P&L مجموع ${formatCurrency(m.worstTags[0].pnl)}`,action:'این تگ را در Pre-Trade Gate به‌عنوان هشدار جدی بررسی کن.'});
   if(m.disciplineCost<0)out.push({severity:'medium',title:'هزینه معاملات با فرآیند ضعیف',detail:`معاملات با Process Score زیر 70 مجموعاً ${formatCurrency(m.disciplineCost)} نتیجه داشته‌اند.`,evidence:'این عدد هزینه ثبت‌شده است، نه سود ازدست‌رفته قطعی.',action:'قبل از افزایش حجم، علت معاملات با فرآیند ضعیف را اصلاح کن.'});
   return out;
 },[m]);

 if(loading)return <div className="page-container flex items-center justify-center py-24"><RefreshCw className="w-7 h-7 animate-spin text-gold-400"/></div>; if(error && !trades.length)return <div className="page-container py-20" dir="rtl"><div className="glass-card p-8 max-w-xl mx-auto text-center"><AlertTriangle className="w-10 h-10 text-warning-400 mx-auto mb-3"/><h1 className="text-xl font-bold text-white">تحلیل فرآیند در دسترس نیست</h1><p className="text-sm text-dark-400 mt-2">{error}</p><button onClick={load} className="btn-primary mt-5 inline-flex items-center gap-2"><RefreshCw className="w-4 h-4"/> تلاش مجدد</button></div></div>; if(error && !trades.length)return <div className="page-container py-20" dir="rtl"><div className="glass-card p-8 max-w-xl mx-auto text-center"><AlertTriangle className="w-10 h-10 text-warning-400 mx-auto mb-3"/><h1 className="text-xl font-bold text-white">تحلیل فرآیند در دسترس نیست</h1><p className="text-sm text-dark-400 mt-2">{error}</p><button onClick={load} className="btn-primary mt-5 inline-flex items-center gap-2"><RefreshCw className="w-4 h-4"/> تلاش مجدد</button></div></div>;
 return <div className="page-container space-y-5" dir="rtl">
   <div className="section-header"><div><p className="text-xs text-gold-400 mb-1">PHASE 10 · ADVANCED JOURNAL INTELLIGENCE · گزارش هفتگی / ۷ روز اخیر</p><h1 className="text-2xl font-bold text-white">مرکز هوشمندی فرآیند</h1><p className="text-sm text-dark-400 mt-1">اندازه‌گیری هزینه‌ی نقض قوانین، کیفیت اجرا و رفتارهای تکرارشونده — بدون AI</p></div>
    <div className="flex gap-1 glass-card p-1">{[['all','همه'],['90','۹۰ روز'],['30','۳۰ روز'],['7','۷ روز اخیر']].map(([v,l])=><button key={v} onClick={()=>setPeriod(v as any)} className={`px-3 py-1.5 rounded-lg text-xs ${period===v?'bg-gold-500/15 text-gold-300':'text-dark-400'}`}>{l}</button>)}</div>
   </div>
   {error&&<div className="rounded-xl border border-warning-500/20 bg-warning-500/5 p-3 text-xs text-warning-300">{error}</div>}
   {error&&<div className="rounded-xl border border-warning-500/20 bg-warning-500/5 p-3 text-xs text-warning-300">{error}</div>}
   {!m.total?<div className="glass-card p-10 text-center text-dark-400">برای ساخت این گزارش هنوز معامله بسته‌شده کافی نداریم.</div>:<>
   <div className="grid grid-cols-2 xl:grid-cols-5 gap-3">
    <K title="معاملات" v={m.total} icon={Target}/><K title="P&L معاملات ضعیف" v={formatCurrency(m.disciplineCost)} icon={CircleDollarSign} danger={m.disciplineCost<0}/><K title="میانگین Process" v={`${m.avgProcess.toFixed(0)}/100`} icon={Gauge}/><K title="Review کامل" v={`${m.reviewed.toFixed(0)}٪`} icon={CheckCircle2}/><K title="Risk Creep" v={m.riskCreep} icon={ShieldAlert} danger={m.riskCreep>0}/>
   </div>
   <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
    <section className="xl:col-span-2 glass-card p-5"><h2 className="font-semibold text-white flex items-center gap-2"><Brain className="w-4 h-4 text-gold-400"/> یافته‌های قابل اقدام</h2><div className="mt-4 space-y-3">{findings.length?findings.map((f,i)=><div key={i} className={`rounded-xl border p-4 ${f.severity==='high'?'border-danger-500/30 bg-danger-500/5':f.severity==='medium'?'border-gold-500/30 bg-gold-500/5':'border-white/10'}`}><div className="flex gap-3"><div>{f.severity==='high'?<XCircle className="w-5 h-5 text-danger-400"/>:<AlertTriangle className="w-5 h-5 text-gold-400"/>}</div><div className="flex-1"><p className="font-medium text-white">{f.title}</p><p className="text-sm text-dark-300 mt-1">{f.detail}</p><p className="text-xs text-dark-500 mt-2">شاهد: {f.evidence}</p><p className="text-sm text-gold-300 mt-2">اقدام پیشنهادی: {f.action}</p></div></div></div>):<div className="text-center py-8 text-success-400">🟢 در داده فعلی نقض مهمی پیدا نشد.</div>}</div></section>
    <section className="glass-card p-5"><h2 className="font-semibold text-white flex items-center gap-2"><ShieldAlert className="w-4 h-4 text-danger-400"/> گران‌ترین رفتارها</h2><div className="mt-4 space-y-2">{m.worstTags.length?m.worstTags.map(x=><div key={x.tag} className="flex items-center justify-between rounded-lg bg-dark-800/60 p-3"><div><p className="text-sm text-white">{x.tag}</p><p className="text-xs text-dark-500">{x.n} معامله · {formatCurrency(x.pnl)}</p></div><span className={x.avgR<0?'text-danger-400':'text-success-400'}>{x.avgR>=0?'+':''}{x.avgR.toFixed(2)}R</span></div>):<p className="text-sm text-dark-500">حداقل ۲ نمونه برای تحلیل لازم است.</p>}</div></section>
   </div>
   <section className="glass-card p-5"><h2 className="font-semibold text-white flex items-center gap-2"><Layers3 className="w-4 h-4 text-gold-400"/> اثر اجرای استراتژی‌ها</h2><div className="overflow-x-auto mt-4"><table className="w-full text-sm"><thead><tr className="text-dark-500 border-b border-white/5"><th className="text-right p-2">استراتژی</th><th>تعداد</th><th>R مجموع</th><th>Avg R</th><th>P&L</th><th>وضعیت</th></tr></thead><tbody>{m.strategyRows.map(x=><tr key={x.name} className="border-b border-white/5"><td className="p-3 text-white">{x.name}</td><td className="text-center text-dark-300">{x.n}</td><td className="text-center">{x.r.toFixed(2)}R</td><td className={x.avgR<0?'text-danger-400':'text-success-400'}>{x.avgR.toFixed(2)}R</td><td className={x.pnl<0?'text-danger-400':'text-success-400'}>{formatCurrency(x.pnl)}</td><td className="text-center">{x.avgR<0?<span className="text-danger-400">نیازمند بررسی</span>:<span className="text-success-400">مثبت</span>}</td></tr>)}</tbody></table></div></section>
   <div className="glass-card p-5"><h2 className="font-semibold text-white flex items-center gap-2"><Trophy className="w-4 h-4 text-gold-400"/> سه قانون برای دوره بعد</h2><div className="grid md:grid-cols-3 gap-3 mt-4">{findings.slice(0,3).map((f,i)=><div key={i} className="p-4 rounded-xl bg-dark-800/60 border border-white/5"><span className="text-gold-400 font-bold">0{i+1}</span><p className="text-sm text-white mt-2">{f.action}</p></div>)}{!findings.length&&<div className="text-sm text-dark-400">داده بیشتری برای ساخت قوانین شخصی لازم است.</div>}</div></div>
   </>}
 </div>
}
function badTagsIntersection(t:Trade){return tags(t).filter(x=>badTags.has(x))}
function K({title,v,icon:Icon,danger}:{title:string;v:any;icon:any;danger?:boolean}){return <div className="kpi-card glass-card-hover"><div className="flex justify-between"><p className="text-xs text-dark-400">{title}</p><Icon className={`w-4 h-4 ${danger?'text-danger-400':'text-gold-400'}`}/></div><p className={`text-xl font-bold mt-2 number-ltr ${danger?'text-danger-400':'text-white'}`}>{v}</p></div>}