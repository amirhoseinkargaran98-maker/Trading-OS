import { ReactNode } from 'react';
import Sidebar from './Sidebar';
import MobileNav from './MobileNav';
import SmartTicker from './SmartTicker';
import { useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId, setActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';

function ActiveAccountBootstrap() {
  const { user } = useAuth();
  useEffect(() => {
    if (!user) return;
    const ensure = async () => {
      const current = getActiveAccountId();
      const { data } = await supabase.from('accounts').select('id').eq('user_id', user.id).eq('is_active', true).order('created_at', { ascending: true });
      if (current && data?.some(a => a.id === current)) return;
      if (data?.[0]?.id) setActiveAccountId(data[0].id);
    };
    ensure();
  }, [user]);
  return null;
}

export default function AppLayout({ children }: { children: ReactNode }) {
  return (
    <>
    <ActiveAccountBootstrap />
    <div className="flex h-screen bg-dark-950 overflow-hidden" dir="rtl">
      {/* Desktop sidebar */}
      <div className="hidden md:flex flex-shrink-0">
        <Sidebar />
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile top bar */}
        <MobileNav />

        {/* Unified smart ticker: account + risk + process + edge + psychology */}
        <SmartTicker />

        {/* Page content */}
        <main className="flex-1 overflow-y-auto pb-20 md:pb-0">
          {children}
        </main>
      </div>
    </div>
    </>
  );
}
