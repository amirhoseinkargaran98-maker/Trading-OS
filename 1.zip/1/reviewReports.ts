export type ReviewTrade = {
  trade_date: string;
  result?: string | null;
  pnl_amount?: number | null;
  r_multiple?: number | null;
  risk_percent?: number | null;
  risk_status?: string | null;
  process_score?: number | null;
  review_completed?: boolean | null;
  session?: string | null;
  symbol?: string | null;
  entry_reason?: string | null;
  exit_reason?: string | null;
  mistakes?: string | null;
  psychology_before?: string | null;
  psychology_state?: string | null;
  strategy?: string | null;
  setup?: string | null;
  direction?: string | null;
  timeframe?: string | null;
  entry_time?: string | null;
  psychology_during?: string | null;
  psychology_after?: string | null;
};

const n = (v: unknown) => Number(v) || 0;
const closed = (t: ReviewTrade) => t.result !== 'open' && t.pnl_amount !== null && t.pnl_amount !== undefined;
const dayMs = 86400000;

export type ReportPeriod = 'day' | 'week' | 'month';

export function periodRange(period: ReportPeriod, anchor = new Date()) {
  const d = new Date(anchor.getFullYear(), anchor.getMonth(), anchor.getDate(), 12);
  if (period === 'day') {
    const key = iso(d);
    return { from: key, to: key };
  }
  if (period === 'week') {
    const start = new Date(d);
    const day = start.getDay();
    start.setDate(start.getDate() - day);
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return { from: iso(start), to: iso(end) };
  }
  return {
    from: iso(new Date(d.getFullYear(), d.getMonth(), 1, 12)),
    to: iso(new Date(d.getFullYear(), d.getMonth() + 1, 0, 12)),
  };
}

export function iso(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

export function shiftPeriod(range: {from:string;to:string}, direction: number) {
  const from = new Date(`${range.from}T12:00:00`);
  const to = new Date(`${range.to}T12:00:00`);
  const span = Math.max(1, Math.round((to.getTime()-from.getTime())/dayMs)+1);
  const nextFrom = new Date(from); nextFrom.setDate(nextFrom.getDate() + span * direction);
  const nextTo = new Date(to); nextTo.setDate(nextTo.getDate() + span * direction);
  return { from: iso(nextFrom), to: iso(nextTo) };
}

export function inRange(date: string, range: {from:string;to:string}) { return date >= range.from && date <= range.to; }

function sum(ts: ReviewTrade[], key: 'pnl_amount'|'r_multiple'|'risk_percent') { return ts.reduce((s,t)=>s+n(t[key]),0); }

function streaks(ts: ReviewTrade[]) {
  let w=0,l=0,bw=0,bl=0;
  for (const t of ts) {
    const p=n(t.pnl_amount);
    if(p>0){w++;l=0;bw=Math.max(bw,w);} else if(p<0){l++;w=0;bl=Math.max(bl,l);} else {w=0;l=0;}
  }
  return {bw,bl};
}

export function buildPeriodReport(allTrades: ReviewTrade[], range: {from:string;to:string}) {
  const trades = allTrades.filter(closed).filter(t=>inRange(t.trade_date,range)).sort((a,b)=>a.trade_date.localeCompare(b.trade_date));
  const wins = trades.filter(t=>n(t.pnl_amount)>0);
  const losses = trades.filter(t=>n(t.pnl_amount)<0);
  const pnl=sum(trades,'pnl_amount');
  const grossWin=sum(wins,'pnl_amount');
  const grossLoss=Math.abs(sum(losses,'pnl_amount'));
  const rs=trades.map(t=>n(t.r_multiple));
  const avgR=trades.length?rs.reduce((a,b)=>a+b,0)/trades.length:0;
  const expectancy=trades.length?pnl/trades.length:0;
  const winRate=trades.length?wins.length/trades.length*100:0;
  const profitFactor=grossLoss?grossWin/grossLoss:(grossWin?Infinity:0);
  const reviewed=trades.filter(t=>t.review_completed === true).length;
  const scored=trades.filter(t=>t.process_score !== null && t.process_score !== undefined && Number.isFinite(Number(t.process_score)));
  const processScore=scored.length?scored.reduce((s,t)=>s+n(t.process_score),0)/scored.length:0;
  const riskSum=sum(trades,'risk_percent');
  const {bw,bl}=streaks(trades);

  let equity=0, peak=0, maxDD=0;
  const equityCurve=trades.map(t=>{ equity+=n(t.pnl_amount); peak=Math.max(peak,equity); maxDD=Math.max(maxDD,peak-equity); return {date:t.trade_date,equity}; });

  const groups = (field: keyof ReviewTrade) => {
    const map: Record<string,{trades:number;pnl:number;wins:number;r:number}>={};
    trades.forEach(t=>{const key=String(t[field] || 'نامشخص'); map[key]??={trades:0,pnl:0,wins:0,r:0}; map[key].trades++; map[key].pnl+=n(t.pnl_amount); map[key].r+=n(t.r_multiple); if(n(t.pnl_amount)>0)map[key].wins++;});
    return Object.entries(map).map(([key,v])=>({key,...v,winRate:v.trades?v.wins/v.trades*100:0,avgR:v.trades?v.r/v.trades:0})).sort((a,b)=>b.pnl-a.pnl);
  };

  const sessions=groups('session');
  const setups=groups('entry_reason');
  const symbols=groups('symbol');
  const psychology=groups('psychology_before');
  const mistakes=groups('mistakes').filter(x=>x.key!=='نامشخص');

  const actions:string[]=[];
  if(!trades.length) actions.push('برای این بازه معامله بسته‌شده‌ای ثبت نشده است.');
  if(trades.length && reviewed/trades.length<0.8) actions.push(`نرخ تکمیل Review فقط ${Math.round(reviewed/trades.length*100)}٪ است؛ مرور معاملات را کامل کن.`);
  if(trades.length && processScore && processScore<70) actions.push('امتیاز فرآیند پایین است؛ قبل از افزایش حجم، اجرای قوانین را تثبیت کن.');
  if(bl>=3) actions.push(`رشته ${bl} باخت متوالی ثبت شده؛ قبل از معامله بعدی علت مشترک این رشته را بررسی کن.`);
  if(riskSum/trades.length>0.8) actions.push('میانگین ریسک ثبت‌شده بالاست؛ قبل از ورود بعدی Risk Guard را دوباره بررسی کن.');
  if(sessions[0]?.pnl>0) actions.push(`بهترین سشن این بازه «${sessions[0].key}» بوده؛ شرایط مشترک معاملات موفق آن را بررسی کن.`);
  if(sessions.length>0 && sessions[sessions.length-1].pnl<0 && sessions.length>1) actions.push(`ضعیف‌ترین سشن «${sessions[sessions.length-1]?.key}» بوده؛ فعلاً آن را بدون بررسی بیشتر افزایش نده.`);
  if(setups[0]?.trades>=3 && setups[0].pnl>0) actions.push(`بهترین ستاپ «${setups[0].key}» بوده؛ نمونه‌های موفق آن را برای تکرار شرایط بررسی کن.`);
  if(psychology.find(x=>x.key.includes('ترس') && x.pnl<0)) actions.push('در معاملات همراه با ترس، عملکرد ضعیف‌تر بوده؛ قبل از ورود وضعیت ذهنی را جدی‌تر کنترل کن.');

  const strategies=groups('strategy');
  const directions=groups('direction');
  const timeframes=groups('timeframe');
  const psychologySignals=psychology.filter(x=>x.key!=='نامشخص');
  const bestEdge=[...strategies,...setups,...sessions].filter(x=>x.trades>=5).sort((a,b)=>b.avgR-a.avgR)[0];
  const worstEdge=[...strategies,...setups,...sessions].filter(x=>x.trades>=5).sort((a,b)=>a.avgR-b.avgR)[0];
  const dailyMap:Record<string,{pnl:number;r:number;trades:number;process:number;scored:number}>={};
  trades.forEach(t=>{const d=t.trade_date;dailyMap[d]??={pnl:0,r:0,trades:0,process:0,scored:0};dailyMap[d].pnl+=n(t.pnl_amount);dailyMap[d].r+=n(t.r_multiple);dailyMap[d].trades++;if(t.process_score!==null&&t.process_score!==undefined&&Number.isFinite(Number(t.process_score))){dailyMap[d].process+=n(t.process_score);dailyMap[d].scored++;}});
  const dailySeries=Object.entries(dailyMap).sort(([a],[b])=>a.localeCompare(b)).map(([date,v])=>({date,...v,avgProcess:v.scored?v.process/v.scored:null}));
  const processCoverage=trades.length?scored.length/trades.length:0;
  const reviewCoverage=trades.length?reviewed/trades.length:0;
  const executionScore=trades.length?Math.max(0,Math.min(100,100-(mistakes.reduce((s,x)=>s+x.trades,0)/trades.length)*35)):0;
  const psychologyScore=trades.length?Math.max(0,Math.min(100,100-(psychologySignals.filter(x=>x.pnl<0).reduce((s,x)=>s+x.trades,0)/trades.length)*30)):0;
  const strategyScore=bestEdge?Math.max(0,Math.min(100,50+bestEdge.avgR*20+Math.min(20,bestEdge.winRate*.2))):50;
  const primaryAxis=[['استراتژی',strategyScore],['اجرا',executionScore],['روانشناسی',psychologyScore]].sort((a,b)=>Number(a[1])-Number(b[1]))[0];
  const nextAction=actions[0] || (bestEdge ? `شرایط مشترک «${bestEdge.key}» را در معاملات بعدی بدون افزایش ریسک تکرار و ثبت کن.` : 'نمونه را افزایش بده و کیفیت ثبت Review را حفظ کن.');

  const highlights = [
    {label:'بهترین ستاپ', value:setups[0]?.key || '—', detail:setups[0] ? `${setups[0].trades} معامله · ${setups[0].avgR.toFixed(2)}R` : ''},
    {label:'بهترین سشن', value:sessions[0]?.key || '—', detail:sessions[0] ? `${sessions[0].pnl.toFixed(2)}$ · ${sessions[0].winRate.toFixed(0)}٪` : ''},
    {label:'بهترین نماد', value:symbols[0]?.key || '—', detail:symbols[0] ? `${symbols[0].pnl.toFixed(2)}$ · ${symbols[0].trades} معامله` : ''},
    {label:'بیشترین چالش', value:mistakes[0]?.key || '—', detail:mistakes[0] ? `${mistakes[0].trades} بار` : ''},
  ];

  return {range,trades,wins: wins.length,losses:losses.length,pnl,grossWin,grossLoss,winRate,profitFactor,avgR,expectancy,reviewed,processScore,riskSum,maxDD,bestWinStreak:bw,bestLossStreak:bl,equityCurve,sessions,setups,symbols,psychology,mistakes,strategies,directions,timeframes,dailySeries,processCoverage,reviewCoverage,executionScore,psychologyScore,strategyScore,primaryAxis: String(primaryAxis?.[0] || '—'),nextAction,bestEdge,worstEdge,actions,highlights};
}
