import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  BookOpen, ChevronRight, ChevronLeft, Plus, Pencil, Trash2, X,
  Smile, Meh, Frown, Brain, TrendingUp, TrendingDown, StickyNote, CalendarDays
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import {
  formatCurrency, toPersianDate, toGregorianDateInput, parseDateOnly, getPsychologyLabel, getDayName,
} from '@/lib/utils';

type DailyReview = {
  id: string;
  review_date: string;
  mood: string | null;
  content: string | null;
  lessons: string | null;
  plan_for_tomorrow: string | null;
  daily_pnl: number | null;
  total_trades: number;
  wins: number;
  losses: number;
};

type Note = {
  id: string;
  note_type: string;
  title: string | null;
  content: string;
  note_date: string | null;
  tags: string[] | null;
};

type DayAgg = { pnl: number; trades: number; wins: number; losses: number };

const MOOD_OPTIONS = [
  { value: 'great', label: 'عالی', icon: Smile, color: 'text-success-400' },
  { value: 'good', label: 'خوب', icon: Smile, color: 'text-success-300' },
  { value: 'neutral', label: 'خنثی', icon: Meh, color: 'text-dark-300' },
  { value: 'bad', label: 'بد', icon: Frown, color: 'text-danger-300' },
  { value: 'terrible', label: 'خیلی بد', icon: Frown, color: 'text-danger-400' },
];

const NOTE_TYPES: Record<string, string> = { daily: 'روزانه', weekly: 'هفتگی', monthly: 'ماهانه', general: 'عمومی' };

const emptyNoteForm = { note_type: 'general', title: '', content: '', note_date: toGregorianDateInput(new Date()), tags: '' };

function getMoodLabel(m: string | null) {
  return MOOD_OPTIONS.find(o => o.value === m)?.label || '—';
}

export default function Journal() {
  const { user } = useAuth();
  const [tab, setTab] = useState<'calendar' | 'notes' | 'psychology'>('calendar');
  const [monthCursor, setMonthCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  const [dayAgg, setDayAgg] = useState<Record<string, DayAgg>>({});
  const [reviews, setReviews] = useState<Record<string, DailyReview>>({});
  const [psychTags, setPsychTags] = useState<{ tag: string; count: number }[]>([]);
  const [moodPnl, setMoodPnl] = useState<{ label: string; avgPnl: number; days: number }[]>([]);
  const [loading, setLoading] = useState(true);

  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [reviewForm, setReviewForm] = useState({ mood: 'neutral', content: '', lessons: '', plan_for_tomorrow: '' });
  const [savingReview, setSavingReview] = useState(false);

  const [notes, setNotes] = useState<Note[]>([]);
  const [notesFilter, setNotesFilter] = useState('all');
  const [showNoteForm, setShowNoteForm] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteForm, setNoteForm] = useState(emptyNoteForm);
  const [deleteNoteId, setDeleteNoteId] = useState<string | null>(null);

  const monthStart = toGregorianDateInput(monthCursor);
  const monthEnd = toGregorianDateInput(new Date(monthCursor.getFullYear(), monthCursor.getMonth() + 1, 0));

  const loadMonthData = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    const [{ data: trades }, { data: reviewsData }] = await Promise.all([
      supabase.from('trades').select('trade_date, pnl_amount, result, psychology_tags').eq('user_id', user.id).eq('account_id', getActiveAccountId()).gte('trade_date', monthStart).lte('trade_date', monthEnd),
      supabase.from('daily_reviews').select('*').eq('user_id', user.id).gte('review_date', monthStart).lte('review_date', monthEnd),
    ]);

    const agg: Record<string, DayAgg> = {};
    const tagCounts: Record<string, number> = {};
    (trades || []).forEach((t: any) => {
      const d = t.trade_date;
      if (!agg[d]) agg[d] = { pnl: 0, trades: 0, wins: 0, losses: 0 };
      agg[d].pnl += Number(t.pnl_amount) || 0;
      agg[d].trades += 1;
      if (t.result === 'win') agg[d].wins += 1;
      if (t.result === 'loss') agg[d].losses += 1;
      (t.psychology_tags || []).forEach((tag: string) => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      });
    });
    setDayAgg(agg);
    setPsychTags(Object.entries(tagCounts).map(([tag, count]) => ({ tag, count })).sort((a, b) => b.count - a.count));

    const reviewMap: Record<string, DailyReview> = {};
    (reviewsData || []).forEach((r: DailyReview) => { reviewMap[r.review_date] = r; });
    setReviews(reviewMap);

    // Mood vs avg daily pnl (across all reviews with mood set, this month)
    const moodMap: Record<string, { total: number; days: number }> = {};
    (reviewsData || []).forEach((r: DailyReview) => {
      if (!r.mood) return;
      if (!moodMap[r.mood]) moodMap[r.mood] = { total: 0, days: 0 };
      moodMap[r.mood].total += Number(r.daily_pnl) || (agg[r.review_date]?.pnl ?? 0);
      moodMap[r.mood].days += 1;
    });
    setMoodPnl(
      MOOD_OPTIONS.filter(o => moodMap[o.value]).map(o => ({
        label: o.label,
        avgPnl: moodMap[o.value].total / moodMap[o.value].days,
        days: moodMap[o.value].days,
      }))
    );

    setLoading(false);
  }, [user, monthStart, monthEnd]);

  useEffect(() => { loadMonthData(); }, [loadMonthData]);

  const loadNotes = useCallback(async () => {
    if (!user) return;
    let query = supabase.from('notes').select('*').eq('user_id', user.id).order('note_date', { ascending: false }).order('created_at', { ascending: false });
    if (notesFilter !== 'all') query = query.eq('note_type', notesFilter);
    const { data } = await query;
    setNotes(data || []);
  }, [user, notesFilter]);

  useEffect(() => { if (tab === 'notes') loadNotes(); }, [tab, loadNotes]);

  const openDay = (dateStr: string) => {
    const r = reviews[dateStr];
    setReviewForm({
      mood: r?.mood || 'neutral',
      content: r?.content || '',
      lessons: r?.lessons || '',
      plan_for_tomorrow: r?.plan_for_tomorrow || '',
    });
    setSelectedDate(dateStr);
  };

  const handleSaveReview = async () => {
    if (!user || !selectedDate) return;
    setSavingReview(true);
    const agg = dayAgg[selectedDate] || { pnl: 0, trades: 0, wins: 0, losses: 0 };
    await supabase.from('daily_reviews').upsert({
      user_id: user.id,
      review_date: selectedDate,
      mood: reviewForm.mood,
      content: reviewForm.content.trim() || null,
      lessons: reviewForm.lessons.trim() || null,
      plan_for_tomorrow: reviewForm.plan_for_tomorrow.trim() || null,
      daily_pnl: agg.pnl,
      total_trades: agg.trades,
      wins: agg.wins,
      losses: agg.losses,
    }, { onConflict: 'user_id,review_date' });
    setSavingReview(false);
    setSelectedDate(null);
    loadMonthData();
  };

  const openCreateNote = () => {
    setEditingNoteId(null);
    setNoteForm(emptyNoteForm);
    setShowNoteForm(true);
  };

  const openEditNote = (n: Note) => {
    setEditingNoteId(n.id);
    setNoteForm({
      note_type: n.note_type, title: n.title || '', content: n.content,
      note_date: n.note_date || toGregorianDateInput(new Date()),
      tags: (n.tags || []).join('، '),
    });
    setShowNoteForm(true);
  };

  const handleSaveNote = async () => {
    if (!user || !noteForm.content.trim()) return;
    const payload = {
      note_type: noteForm.note_type,
      title: noteForm.title.trim() || null,
      content: noteForm.content.trim(),
      note_date: noteForm.note_date || null,
      tags: noteForm.tags.trim() ? noteForm.tags.split(/[،,]/).map(t => t.trim()).filter(Boolean) : null,
    };
    if (editingNoteId) {
      await supabase.from('notes').update(payload).eq('id', editingNoteId).eq('user_id', user.id);
    } else {
      await supabase.from('notes').insert({ ...payload, user_id: user.id });
    }
    setShowNoteForm(false);
    loadNotes();
  };

  const handleDeleteNote = async (id: string) => {
    if (!user) return;
    await supabase.from('notes').delete().eq('id', id).eq('user_id', user.id);
    setDeleteNoteId(null);
    loadNotes();
  };

  const calendarCells = useMemo(() => {
    const year = monthCursor.getFullYear();
    const month = monthCursor.getMonth();
    const firstDay = new Date(year, month, 1);
    const startOffset = firstDay.getDay(); // 0 = Sunday
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: (string | null)[] = Array(startOffset).fill(null);
    for (let d = 1; d <= daysInMonth; d++) {
      cells.push(toGregorianDateInput(new Date(year, month, d)));
    }
    return cells;
  }, [monthCursor]);

  const monthLabel = monthCursor.toLocaleDateString('fa-IR', { month: 'long', year: 'numeric' });
  const todayStr = toGregorianDateInput(new Date());

  return (
    <div className="page-container" dir="rtl">
      <div className="section-header">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-gold-400" />
          <h1 className="text-xl font-bold text-white">ژورنال</h1>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-white/5">
        {[
          { key: 'calendar', label: 'مرور روزانه', icon: CalendarDays },
          { key: 'notes', label: 'یادداشت‌ها', icon: StickyNote },
          { key: 'psychology', label: 'الگوهای روانشناسی', icon: Brain },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key as any)}
            className={`flex items-center gap-1.5 px-3 py-2 text-sm border-b-2 transition-colors ${
              tab === t.key ? 'border-gold-500 text-gold-400' : 'border-transparent text-dark-400 hover:text-white'
            }`}
          >
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'calendar' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <button onClick={() => setMonthCursor(m => new Date(m.getFullYear(), m.getMonth() - 1, 1))} className="p-2 rounded-lg text-dark-400 hover:text-white hover:bg-white/5">
              <ChevronRight className="w-4 h-4" />
            </button>
            <h2 className="text-sm font-semibold text-white">{monthLabel}</h2>
            <button onClick={() => setMonthCursor(m => new Date(m.getFullYear(), m.getMonth() + 1, 1))} className="p-2 rounded-lg text-dark-400 hover:text-white hover:bg-white/5">
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-6 h-6 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="glass-card p-3 md:p-4">
              <div className="grid grid-cols-7 gap-1.5 mb-2">
                {['ی', 'د', 'س', 'چ', 'پ', 'ج', 'ش'].map(d => (
                  <div key={d} className="text-center text-[11px] text-dark-500 font-medium py-1">{d}</div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1.5">
                {calendarCells.map((dateStr, i) => {
                  if (!dateStr) return <div key={i} />;
                  const agg = dayAgg[dateStr];
                  const review = reviews[dateStr];
                  const isToday = dateStr === todayStr;
                  const hasTrades = !!agg && agg.trades > 0;
                  const bg = !hasTrades
                    ? 'bg-dark-900/40 hover:bg-dark-800/60'
                    : agg.pnl > 0
                    ? 'bg-success-500/15 hover:bg-success-500/25 border-success-500/20'
                    : agg.pnl < 0
                    ? 'bg-danger-500/15 hover:bg-danger-500/25 border-danger-500/20'
                    : 'bg-dark-500/15 hover:bg-dark-500/25';
                  return (
                    <button
                      key={dateStr}
                      onClick={() => openDay(dateStr)}
                      className={`aspect-square rounded-lg border border-white/5 p-1 flex flex-col items-center justify-center gap-0.5 transition-colors ${bg} ${isToday ? 'ring-1 ring-gold-500/50' : ''}`}
                    >
                      <span className="text-[11px] text-white number-ltr">{parseDateOnly(dateStr)?.getDate() || 0}</span>
                      {hasTrades && (
                        <span className={`text-[9px] number-ltr ${agg.pnl >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                          {agg.pnl >= 0 ? '+' : ''}{agg.pnl >= 1000 || agg.pnl <= -1000 ? `${(agg.pnl / 1000).toFixed(1)}K` : agg.pnl.toFixed(0)}
                        </span>
                      )}
                      {review?.content && <span className="w-1 h-1 rounded-full bg-gold-400" />}
                    </button>
                  );
                })}
              </div>
              <div className="flex items-center gap-4 mt-3 pt-3 border-t border-white/5 text-[11px] text-dark-500">
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-success-500/30 border border-success-500/40" /> روز سودده</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-danger-500/30 border border-danger-500/40" /> روز ضررده</span>
                <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-gold-400" /> مرور ثبت‌شده</span>
              </div>
            </div>
          )}
        </div>
      )}

      {tab === 'notes' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex gap-1.5 flex-wrap">
              <button onClick={() => setNotesFilter('all')} className={`text-xs px-3 py-1.5 rounded-lg border ${notesFilter === 'all' ? 'bg-gold-500/15 text-gold-400 border-gold-500/30' : 'bg-dark-900/60 text-dark-400 border-white/10'}`}>همه</button>
              {Object.entries(NOTE_TYPES).map(([k, v]) => (
                <button key={k} onClick={() => setNotesFilter(k)} className={`text-xs px-3 py-1.5 rounded-lg border ${notesFilter === k ? 'bg-gold-500/15 text-gold-400 border-gold-500/30' : 'bg-dark-900/60 text-dark-400 border-white/10'}`}>{v}</button>
              ))}
            </div>
            <button onClick={openCreateNote} className="btn-primary flex items-center gap-1.5 text-sm">
              <Plus className="w-4 h-4" /> یادداشت جدید
            </button>
          </div>

          {notes.length === 0 ? (
            <div className="glass-card p-10 text-center">
              <StickyNote className="w-10 h-10 text-dark-500 mx-auto mb-3" />
              <p className="text-dark-400 text-sm">یادداشتی ثبت نشده است.</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {notes.map(n => (
                <div key={n.id} className="glass-card p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        {n.title && <h3 className="text-sm font-semibold text-white">{n.title}</h3>}
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-dark-700 text-dark-400">{NOTE_TYPES[n.note_type] || n.note_type}</span>
                        {n.note_date && <span className="text-[11px] text-dark-500">{toPersianDate(n.note_date)}</span>}
                      </div>
                      <p className="text-sm text-dark-300 leading-6 mt-1.5 whitespace-pre-wrap">{n.content}</p>
                      {n.tags && n.tags.length > 0 && (
                        <div className="flex gap-1.5 flex-wrap mt-2">
                          {n.tags.map(t => <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-gold-500/10 text-gold-400 border border-gold-500/20">{t}</span>)}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button onClick={() => openEditNote(n)} className="p-1.5 rounded-lg text-dark-400 hover:text-gold-400 hover:bg-white/5">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => setDeleteNoteId(n.id)} className="p-1.5 rounded-lg text-dark-400 hover:text-danger-400 hover:bg-white/5">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'psychology' && (
        <div className="space-y-4">
          <p className="text-xs text-dark-500">داده‌های این بخش بر اساس معاملات و مرورهای روزانه‌ی «{monthLabel}» محاسبه شده است.</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="glass-card p-4">
              <h2 className="section-title"><Brain className="w-4 h-4 text-gold-400" /> تکرار الگوهای روانی</h2>
              {psychTags.length === 0 ? (
                <p className="text-sm text-dark-500 py-6 text-center">در این ماه تگ روانشناسی‌ای برای معاملات ثبت نشده است.</p>
              ) : (
                <div className="space-y-2">
                  {psychTags.map(({ tag, count }) => (
                    <div key={tag} className="flex items-center gap-2">
                      <span className="text-xs text-dark-300 w-16 flex-shrink-0">{getPsychologyLabel(tag)}</span>
                      <div className="flex-1 h-2 rounded-full bg-dark-700 overflow-hidden">
                        <div className="h-full bg-gold-500" style={{ width: `${(count / psychTags[0].count) * 100}%` }} />
                      </div>
                      <span className="text-xs text-dark-400 w-6 text-left number-ltr">{count}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="glass-card p-4">
              <h2 className="section-title"><TrendingUp className="w-4 h-4 text-gold-400" /> رابطه‌ی حال‌وهوا و سود/زیان</h2>
              {moodPnl.length === 0 ? (
                <p className="text-sm text-dark-500 py-6 text-center">هنوز مرور روزانه‌ای با حال‌وهوا ثبت نشده است.</p>
              ) : (
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={moodPnl} margin={{ left: 0, right: 10, top: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                    <XAxis dataKey="label" tick={{ fill: '#adb5bd', fontSize: 11 }} tickLine={false} axisLine={false} />
                    <YAxis tick={{ fill: '#6c757d', fontSize: 10 }} tickLine={false} axisLine={false} tickFormatter={v => `$${v}`} />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null;
                        const d = payload[0].payload;
                        return (
                          <div className="glass-card p-2.5 text-xs">
                            <p className="text-white font-semibold mb-1">{d.label}</p>
                            <p className={d.avgPnl >= 0 ? 'text-success-400' : 'text-danger-400'}>میانگین: {formatCurrency(d.avgPnl)}</p>
                            <p className="text-dark-400">تعداد روز: {d.days}</p>
                          </div>
                        );
                      }}
                    />
                    <Bar dataKey="avgPnl" radius={[4, 4, 0, 0]}>
                      {moodPnl.map((d, i) => (
                        <Cell key={i} fill={d.avgPnl >= 0 ? '#22c55e' : '#ef4444'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
              <p className="text-[11px] text-dark-500 mt-2">میانگین سود/زیان روزهایی که با هر حال‌وهوا ثبت شده‌اند.</p>
            </div>
          </div>
        </div>
      )}

      {/* Day review modal */}
      {selectedDate && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-lg space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">مرور روز {toPersianDate(selectedDate)}</h3>
              <button onClick={() => setSelectedDate(null)} className="text-dark-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {dayAgg[selectedDate] && (
              <div className="grid grid-cols-3 gap-2">
                <div className="rounded-lg bg-dark-900/60 p-2.5 text-center">
                  <p className="text-[11px] text-dark-400">معاملات</p>
                  <p className="text-sm font-semibold text-white number-ltr">{dayAgg[selectedDate].trades}</p>
                </div>
                <div className="rounded-lg bg-dark-900/60 p-2.5 text-center">
                  <p className="text-[11px] text-dark-400">برد/باخت</p>
                  <p className="text-sm font-semibold text-white number-ltr">{dayAgg[selectedDate].wins}/{dayAgg[selectedDate].losses}</p>
                </div>
                <div className="rounded-lg bg-dark-900/60 p-2.5 text-center">
                  <p className="text-[11px] text-dark-400">سود/زیان</p>
                  <p className={`text-sm font-semibold number-ltr ${dayAgg[selectedDate].pnl >= 0 ? 'profit-text' : 'loss-text'}`}>{formatCurrency(dayAgg[selectedDate].pnl)}</p>
                </div>
              </div>
            )}

            <div>
              <label className="label-text">حال‌وهوا</label>
              <div className="flex gap-2 flex-wrap">
                {MOOD_OPTIONS.map(o => (
                  <button
                    key={o.value}
                    onClick={() => setReviewForm(f => ({ ...f, mood: o.value }))}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-colors ${
                      reviewForm.mood === o.value ? 'bg-gold-500/15 border-gold-500/40 text-gold-400' : 'bg-dark-900/60 border-white/10 text-dark-400'
                    }`}
                  >
                    <o.icon className="w-3.5 h-3.5" /> {o.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="label-text">مرور روز</label>
              <textarea value={reviewForm.content} onChange={e => setReviewForm(f => ({ ...f, content: e.target.value }))} className="input-field min-h-[80px] resize-y" placeholder="امروز چطور بود؟" />
            </div>
            <div>
              <label className="label-text">درس‌های امروز</label>
              <textarea value={reviewForm.lessons} onChange={e => setReviewForm(f => ({ ...f, lessons: e.target.value }))} className="input-field min-h-[60px] resize-y" />
            </div>
            <div>
              <label className="label-text">برنامه‌ی فردا</label>
              <textarea value={reviewForm.plan_for_tomorrow} onChange={e => setReviewForm(f => ({ ...f, plan_for_tomorrow: e.target.value }))} className="input-field min-h-[60px] resize-y" />
            </div>

            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setSelectedDate(null)} className="btn-secondary">انصراف</button>
              <button onClick={handleSaveReview} disabled={savingReview} className="btn-primary">{savingReview ? 'در حال ذخیره...' : 'ذخیره مرور'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Note form modal */}
      {showNoteForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-lg space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-semibold text-white">{editingNoteId ? 'ویرایش یادداشت' : 'یادداشت جدید'}</h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label-text">نوع</label>
                <select value={noteForm.note_type} onChange={e => setNoteForm(f => ({ ...f, note_type: e.target.value }))} className="select-field">
                  {Object.entries(NOTE_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="label-text">تاریخ</label>
                <input type="date" value={noteForm.note_date} onChange={e => setNoteForm(f => ({ ...f, note_date: e.target.value }))} className="input-field number-ltr" />
              </div>
            </div>
            <div>
              <label className="label-text">عنوان (اختیاری)</label>
              <input type="text" value={noteForm.title} onChange={e => setNoteForm(f => ({ ...f, title: e.target.value }))} className="input-field" />
            </div>
            <div>
              <label className="label-text">متن یادداشت</label>
              <textarea value={noteForm.content} onChange={e => setNoteForm(f => ({ ...f, content: e.target.value }))} className="input-field min-h-[120px] resize-y" autoFocus />
            </div>
            <div>
              <label className="label-text">تگ‌ها (با ، جدا کنید)</label>
              <input type="text" value={noteForm.tags} onChange={e => setNoteForm(f => ({ ...f, tags: e.target.value }))} className="input-field" placeholder="مثلاً: بک‌تست، طلا" />
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowNoteForm(false)} className="btn-secondary">انصراف</button>
              <button onClick={handleSaveNote} disabled={!noteForm.content.trim()} className="btn-primary">ذخیره</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete note confirm */}
      {deleteNoteId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف یادداشت</h3>
            <p className="text-sm text-dark-400 mb-4">آیا مطمئن هستید؟ این عمل قابل بازگشت نیست.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteNoteId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => handleDeleteNote(deleteNoteId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
