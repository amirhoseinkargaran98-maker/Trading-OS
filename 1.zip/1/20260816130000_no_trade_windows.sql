/*
# No-Trade Time Windows

## Overview
Lets a trader define recurring times to avoid trading (e.g. "Friday 15:25-15:45
NFP release", or "every day 21:00-21:15 rollover spread widening"). This is a
static, user-defined substitute for a live economic calendar feed (which this
app cannot fetch without an external API) — the trader encodes their own
"No Trade Rules" once, and every future matching time is caught automatically.

day_of_week: 0=Sunday..6=Saturday, NULL = applies every day.
*/

CREATE TABLE IF NOT EXISTS no_trade_windows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  label text NOT NULL,
  day_of_week smallint CHECK (day_of_week BETWEEN 0 AND 6),
  start_time time NOT NULL,
  end_time time NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE no_trade_windows ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "own_no_trade_windows_select" ON no_trade_windows;
CREATE POLICY "own_no_trade_windows_select" ON no_trade_windows FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_no_trade_windows_insert" ON no_trade_windows;
CREATE POLICY "own_no_trade_windows_insert" ON no_trade_windows FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_no_trade_windows_update" ON no_trade_windows;
CREATE POLICY "own_no_trade_windows_update" ON no_trade_windows FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_no_trade_windows_delete" ON no_trade_windows;
CREATE POLICY "own_no_trade_windows_delete" ON no_trade_windows FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS no_trade_windows_user_idx ON no_trade_windows(user_id);
