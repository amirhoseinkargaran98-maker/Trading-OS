import { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, CalendarDays, RefreshCw, TrendingDown, TrendingUp, ShieldCheck, Database, WifiOff } from 'lucide-react';
import { supabase } from '@/lib/supabase';

type Event = {
  date: string;
  time: string;
  timestamp: number;
  currency: string;
  impact: 'high' | 'medium' | 'low' | 'unknown';
  title: string;
  actual: string | null;
  forecast: string | null;
  previous: string | null;
  bias: 'bullish' | 'bearish' | 'mixed' | 'neutral';
  minutes: number | null;
  source?: string;
};

const CACHE_KEY = 'trading-os-news-cache-v2';
const CACHE_MAX_AGE = 30 * 60 * 1000;
const impactLabel = { high: 'زیاد', medium: 'متوسط', low: 'کم', unknown: 'نامشخص' } as const;

function readCache(): { events: Event[]; savedAt: number; source?: string } | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { events?: Event[]; savedAt?: number; source?: string };
    if (!Array.isArray(parsed.events) || !Number.isFinite(parsed.savedAt)) return null;
    if (Date.now() - parsed.savedAt > CACHE_MAX_AGE) return null;
    return { events: parsed.events, savedAt: parsed.savedAt, source: parsed.source };
  } catch {
    return null;
  }
}

function writeCache(events: Event[], source?: string) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({ events, source, savedAt: Date.now() }));
  } catch {
    // Cache is best-effort only.
  }
}

export default function NewsGuard() {
  const [events, setEvents] = useState<Event[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState('');
  const [cached, setCached] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    setCached(false);

    try {
      const { data, error: invokeError } = await supabase.functions.invoke('economic-calendar', {
        body: { symbols: ['XAUUSD', 'EURUSD', 'DJI'], limit: 30 },
      });

      const freshEvents = Array.isArray(data?.events) ? (data.events as Event[]) : [];
      if (!invokeError && freshEvents.length > 0) {
        setEvents(freshEvents);
        setSource(String(data?.source || 'تقویم اقتصادی'));
        writeCache(freshEvents, String(data?.source || 'تقویم اقتصادی'));
        setLoading(false);
        return;
      }

      const cache = readCache();
      if (cache?.events?.length) {
        setEvents(cache.events);
        setSource(cache.source || 'آخرین داده معتبر');
        setCached(true);
        setError('اتصال زنده موقتاً در دسترس نیست؛ آخرین داده معتبر نمایش داده می‌شود.');
        setLoading(false);
        return;
      }

      const details = Array.isArray(data?.sourceErrors)
        ? data.sourceErrors.map((x: { source?: string; error?: string }) => `${x.source || 'منبع'}: ${x.error || 'ناموفق'}`).join(' · ')
        : '';
      setEvents([]);
      setSource('');
      setError(String(data?.error || details || invokeError?.message || 'منبع خبر زنده در دسترس نبود.'));
    } catch (e) {
      const cache = readCache();
      if (cache?.events?.length) {
        setEvents(cache.events);
        setSource(cache.source || 'آخرین داده معتبر');
        setCached(true);
        setError('اتصال زنده موقتاً در دسترس نیست؛ آخرین داده معتبر نمایش داده می‌شود.');
      } else {
        setEvents([]);
        setSource('');
        setError(e instanceof Error ? e.message : 'منبع خبر زنده در دسترس نبود.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const id = window.setInterval(load, 300000);
    return () => window.clearInterval(id);
  }, [load]);

  return (
    <div className="page-container space-y-5" dir="rtl">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-gold-400" /> نگهبان خبر
          </h1>
          <p className="text-xs text-dark-500 mt-1">تقویم اقتصادی امروز برای XAUUSD، EURUSD و شاخص‌های آمریکا</p>
        </div>
        <button onClick={load} className="btn-secondary p-2" disabled={loading} aria-label="بازخوانی اخبار">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {error && (
        <div className="glass-card p-4 border border-warning-500/20 bg-warning-500/[.04] text-sm text-warning-300 flex items-start gap-3">
          {cached ? <WifiOff className="w-4 h-4 mt-0.5 shrink-0" /> : <Database className="w-4 h-4 mt-0.5 shrink-0" />}
          <span>{error}</span>
        </div>
      )}

      {loading ? (
        <div className="glass-card p-8 text-center text-dark-400">در حال دریافت تقویم اقتصادی...</div>
      ) : events.length ? (
        <div className="space-y-3">
          {events.map((e, i) => (
            <div key={`${e.timestamp}-${e.currency}-${e.title}-${i}`} className={`glass-card p-4 border ${e.impact === 'high' ? 'border-danger-500/20' : e.impact === 'medium' ? 'border-warning-500/15' : 'border-white/5'}`}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] ${e.impact === 'high' ? 'bg-danger-500/10 text-danger-300' : e.impact === 'medium' ? 'bg-warning-500/10 text-warning-300' : 'bg-white/5 text-dark-300'}`}>
                      اهمیت {impactLabel[e.impact]}
                    </span>
                    <span className="text-xs text-dark-500">{e.currency}</span>
                  </div>
                  <h2 className="text-sm font-semibold text-white mt-2">{e.title}</h2>
                  <p className="text-xs text-dark-500 mt-1">
                    <CalendarDays className="w-3.5 h-3.5 inline ml-1" />
                    {e.date} · {e.time}
                  </p>
                </div>
                <div className="text-left">
                  {e.bias === 'bullish' ? <TrendingUp className="w-5 h-5 text-success-400" /> : e.bias === 'bearish' ? <TrendingDown className="w-5 h-5 text-danger-400" /> : <span className="text-xs text-dark-400">خنثی</span>}
                  <p className="text-[10px] text-dark-500 mt-1">{e.minutes !== null ? (e.minutes < 0 ? 'منتشر شده' : `${e.minutes} دقیقه`) : '—'}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 mt-3 text-[11px]">
                <div className="rounded-lg bg-white/[.03] p-2"><span className="text-dark-500">Actual</span><b className="block text-white mt-1">{e.actual || '—'}</b></div>
                <div className="rounded-lg bg-white/[.03] p-2"><span className="text-dark-500">Forecast</span><b className="block text-white mt-1">{e.forecast || '—'}</b></div>
                <div className="rounded-lg bg-white/[.03] p-2"><span className="text-dark-500">Previous</span><b className="block text-white mt-1">{e.previous || '—'}</b></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="glass-card p-10 text-center text-dark-400">
          <ShieldCheck className="w-8 h-8 mx-auto mb-2 text-success-400" />
          امروز در منابع در دسترس، خبر High/Medium معتبر برای USD/EUR پیدا نشد.
        </div>
      )}

      <div className="text-[11px] text-dark-500">منبع فعال: {source || 'در انتظار منبع معتبر'}{cached ? ' · داده کش‌شده' : ''}</div>
    </div>
  );
}
