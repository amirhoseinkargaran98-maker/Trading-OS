import { useState, useRef, useCallback } from 'react';
import { FileDown, X, Loader2, FileText } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { formatCurrency, toGregorianDateInput, getDayName, parseDateOnly } from '@/lib/utils';
import {
  calculateWinRate, calculateAverageWin, calculateAverageLoss,
  calculateProfitFactor, calculateAveragePlannedRR, calculateTotalPnl,
} from '@/lib/tradingEngine';

export default function MonthlyReportButton() {
  const { user, profile } = useAuth();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [monthOffset, setMonthOffset] = useState(0);
  const [report, setReport] = useState<any | null>(null);
  const reportRef = useRef<HTMLDivElement>(null);

  const buildReport = useCallback(async (offset: number) => {
    if (!user) return;
    setLoading(true);
    const now = new Date();
    const base = new Date(now.getFullYear(), now.getMonth() + offset, 1);
    const monthStart = toGregorianDateInput(base);
    const monthEnd = toGregorianDateInput(new Date(base.getFullYear(), base.getMonth() + 1, 0));

    const { data: trades } = await supabase
      .from('trades').select('*').eq('user_id', user.id)
      .gte('trade_date', monthStart).lte('trade_date', monthEnd)
      .not('result', 'eq', 'open');

    const list = trades || [];
    const wins = list.filter(t => t.result === 'win');
    const losses = list.filter(t => t.result === 'loss');
    const winRate = calculateWinRate(list);
    const totalPnl = calculateTotalPnl(list);
    const avgWin = calculateAverageWin(list);
    const avgLoss = calculateAverageLoss(list);
    const profitFactor = calculateProfitFactor(list);
    const avgRR = calculateAveragePlannedRR(list);

    const dayMap: Record<string, number> = {};
    list.forEach(t => { dayMap[t.trade_date] = (dayMap[t.trade_date] || 0) + (Number(t.pnl_amount) || 0); });
    const bestDay = Object.entries(dayMap).sort((a, b) => b[1] - a[1])[0];
    const worstDay = Object.entries(dayMap).sort((a, b) => a[1] - b[1])[0];

    const dayOfWeekMap: Record<number, number> = {};
    list.forEach(t => {
      const d = parseDateOnly(t.trade_date)?.getDay() ?? 0;
      dayOfWeekMap[d] = (dayOfWeekMap[d] || 0) + (Number(t.pnl_amount) || 0);
    });
    const dayOfWeekData = [0, 1, 2, 3, 4, 5, 6].map(d => ({ label: getDayName(d), pnl: dayOfWeekMap[d] || 0 }));
    const maxAbsDayPnl = Math.max(1, ...dayOfWeekData.map(d => Math.abs(d.pnl)));

    const bestTrades = [...list].sort((a, b) => (b.pnl_amount || 0) - (a.pnl_amount || 0)).slice(0, 5);
    const worstTrades = [...list].sort((a, b) => (a.pnl_amount || 0) - (b.pnl_amount || 0)).slice(0, 5);

    setReport({
      monthLabel: base.toLocaleDateString('fa-IR', { month: 'long', year: 'numeric' }),
      totalTrades: list.length, wins: wins.length, losses: losses.length, winRate,
      totalPnl, avgWin, avgLoss, profitFactor, avgRR,
      bestDay, worstDay, dayOfWeekData, maxAbsDayPnl, bestTrades, worstTrades,
    });
    setLoading(false);
  }, [user]);

  const openModal = () => {
    setOpen(true);
    setMonthOffset(0);
    buildReport(0);
  };

  const changeMonth = (delta: number) => {
    const next = monthOffset + delta;
    setMonthOffset(next);
    buildReport(next);
  };

  const handleDownload = async () => {
    if (!reportRef.current || !report) return;
    setGenerating(true);
    try {
      const [{ default: html2canvas }, { jsPDF }] = await Promise.all([
        import('html2canvas'),
        import('jspdf'),
      ]);
      const canvas = await html2canvas(reportRef.current, { scale: 2, backgroundColor: '#0d1117' });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [canvas.width, canvas.height] });
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`گزارش-ماهانه-${report.monthLabel.replace(/\s/g, '-')}.pdf`);
    } catch (e) {
      console.error(e);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <>
      <button onClick={openModal} className="btn-secondary flex items-center gap-1.5 text-sm">
        <FileText className="w-4 h-4" /> گزارش ماهانه PDF
      </button>

      {open && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-2 sm:p-4">
          <div className="w-full max-w-2xl max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between mb-2 px-1">
              <div className="flex items-center gap-2">
                <button onClick={() => changeMonth(-1)} className="btn-secondary p-1.5 !px-2 text-xs">قبل</button>
                <button onClick={() => changeMonth(1)} disabled={monthOffset >= 0} className="btn-secondary p-1.5 !px-2 text-xs disabled:opacity-40">بعد</button>
              </div>
              <button onClick={() => setOpen(false)} className="text-dark-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto rounded-xl border border-white/10">
              {loading || !report ? (
                <div className="flex items-center justify-center py-24 bg-dark-900">
                  <div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <div ref={reportRef} dir="rtl" className="bg-dark-900 p-6 space-y-5" style={{ fontFamily: 'inherit' }}>
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div>
                      <h1 className="text-xl font-bold text-gold-400">گزارش عملکرد ماهانه</h1>
                      <p className="text-sm text-dark-400 mt-1">{report.monthLabel} — {profile?.display_name || 'تریدر'}</p>
                    </div>
                    <div className="text-left">
                      <p className={`text-2xl font-bold number-ltr ${report.totalPnl >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                        {formatCurrency(report.totalPnl)}
                      </p>
                      <p className="text-xs text-dark-500">سود/زیان کل ماه</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { label: 'وین‌ریت', value: `${report.winRate.toFixed(1)}%` },
                      { label: 'تعداد معاملات', value: String(report.totalTrades) },
                      { label: 'Profit Factor', value: report.profitFactor >= 999 ? '∞' : report.profitFactor.toFixed(2) },
                      { label: 'میانگین R:R', value: `${report.avgRR.toFixed(2)}R` },
                      { label: 'میانگین سود', value: formatCurrency(report.avgWin) },
                      { label: 'میانگین ضرر', value: formatCurrency(-report.avgLoss) },
                    ].map(s => (
                      <div key={s.label} className="rounded-xl bg-dark-800/70 border border-white/5 p-3 text-center">
                        <p className="text-[11px] text-dark-400">{s.label}</p>
                        <p className="text-base font-bold text-white number-ltr mt-0.5">{s.value}</p>
                      </div>
                    ))}
                  </div>

                  <div>
                    <h2 className="text-sm font-semibold text-white mb-2">عملکرد روزهای هفته</h2>
                    <div className="space-y-1.5">
                      {report.dayOfWeekData.map((d: any) => (
                        <div key={d.label} className="flex items-center gap-2">
                          <span className="text-xs text-dark-400 w-16 flex-shrink-0">{d.label}</span>
                          <div className="flex-1 h-3 rounded-full bg-dark-800 overflow-hidden">
                            <div
                              className={`h-full ${d.pnl >= 0 ? 'bg-success-500' : 'bg-danger-500'}`}
                              style={{ width: `${(Math.abs(d.pnl) / report.maxAbsDayPnl) * 100}%` }}
                            />
                          </div>
                          <span className={`text-xs w-16 text-left number-ltr flex-shrink-0 ${d.pnl >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                            {formatCurrency(d.pnl)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <h2 className="text-sm font-semibold text-success-400 mb-2">بهترین معاملات</h2>
                      <div className="space-y-1.5">
                        {report.bestTrades.map((t: any) => (
                          <div key={t.id} className="flex items-center justify-between text-xs bg-dark-800/60 rounded-lg px-2.5 py-1.5">
                            <span className="text-dark-300 font-mono">{t.symbol}</span>
                            <span className="text-success-400 number-ltr">{formatCurrency(t.pnl_amount)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h2 className="text-sm font-semibold text-danger-400 mb-2">بدترین معاملات</h2>
                      <div className="space-y-1.5">
                        {report.worstTrades.map((t: any) => (
                          <div key={t.id} className="flex items-center justify-between text-xs bg-dark-800/60 rounded-lg px-2.5 py-1.5">
                            <span className="text-dark-300 font-mono">{t.symbol}</span>
                            <span className="text-danger-400 number-ltr">{formatCurrency(t.pnl_amount)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <p className="text-[10px] text-dark-600 text-center border-t border-white/5 pt-3">
                    تولید شده توسط Trading OS — این گزارش صرفاً برای مرور شخصی است.
                  </p>
                </div>
              )}
            </div>

            <button
              onClick={handleDownload}
              disabled={generating || loading || !report}
              className="btn-primary w-full mt-3 flex items-center justify-center gap-2"
            >
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />}
              {generating ? 'در حال ساخت PDF...' : 'دانلود PDF'}
            </button>
          </div>
        </div>
      )}
    </>
  );
}