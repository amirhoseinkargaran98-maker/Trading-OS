import { useState, useRef } from 'react';
import { Share2, X, Loader2, Download, TrendingUp, TrendingDown } from 'lucide-react';
import { formatCurrency, toPersianDate } from '@/lib/utils';

type Trade = {
  symbol: string; direction: string; result: string | null;
  pnl_amount: number | null; pnl_percent: number | null; rr_ratio: number | null; r_multiple: number | null;
  entry_price: number | null; exit_price: number | null; trade_date: string; strategy_id?: string | null;
};

const RESULT_LABEL: Record<string, string> = { win: 'برنده', loss: 'بازنده', breakeven: 'سربه‌سر', open: 'باز' };

export default function TradeShareCard({ trade }: { trade: Trade }) {
  const [open, setOpen] = useState(false);
  const [generating, setGenerating] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const isWin = (trade.pnl_amount || 0) >= 0;

  const handleDownload = async () => {
    if (!cardRef.current) return;
    setGenerating(true);
    try {
      const { default: html2canvas } = await import('html2canvas');
      const canvas = await html2canvas(cardRef.current, { scale: 3, backgroundColor: null });
      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `trade-${trade.symbol}-${trade.trade_date}.png`;
      link.click();
    } catch (e) {
      console.error(e);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <>
      <button onClick={() => setOpen(true)} className="btn-secondary flex items-center gap-1.5 text-sm">
        <Share2 className="w-4 h-4" /> اشتراک‌گذاری
      </button>

      {open && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-sm space-y-4">
            <div className="flex justify-end">
              <button onClick={() => setOpen(false)} className="text-dark-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Card */}
            <div
              ref={cardRef}
              dir="rtl"
              className="rounded-2xl p-6 relative overflow-hidden"
              style={{
                background: isWin
                  ? 'linear-gradient(145deg, #0d1117 0%, #0f1f16 60%, #0d1117 100%)'
                  : 'linear-gradient(145deg, #0d1117 0%, #1f0f0f 60%, #0d1117 100%)',
                border: `1px solid ${isWin ? 'rgba(34,197,94,0.25)' : 'rgba(239,68,68,0.25)'}`,
              }}
            >
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs text-gold-400 font-semibold tracking-wide">TRADING OS</span>
                <span className="text-[10px] text-dark-500">{toPersianDate(trade.trade_date)}</span>
              </div>

              <div className="text-center mb-6">
                <p className="text-2xl font-bold text-white font-mono mb-1">{trade.symbol}</p>
                <div className="flex items-center justify-center gap-1.5">
                  {trade.direction === 'buy' ? (
                    <TrendingUp className="w-3.5 h-3.5 text-success-400" />
                  ) : (
                    <TrendingDown className="w-3.5 h-3.5 text-danger-400" />
                  )}
                  <span className="text-xs text-dark-400">{trade.direction === 'buy' ? 'خرید' : 'فروش'}</span>
                  <span className="text-dark-600">•</span>
                  <span className={`text-xs ${isWin ? 'text-success-400' : 'text-danger-400'}`}>
                    {RESULT_LABEL[trade.result || ''] || '—'}
                  </span>
                </div>
              </div>

              <div className="text-center mb-6">
                <p className={`text-4xl font-black number-ltr ${isWin ? 'text-success-400' : 'text-danger-400'}`}>
                  {isWin ? '+' : ''}{formatCurrency(trade.pnl_amount)}
                </p>
                {trade.pnl_percent !== null && (
                  <p className={`text-sm number-ltr mt-1 ${isWin ? 'text-success-400/80' : 'text-danger-400/80'}`}>
                    {isWin ? '+' : ''}{trade.pnl_percent.toFixed(2)}%
                  </p>
                )}
              </div>

              <div className="grid grid-cols-3 gap-2 pt-4 border-t border-white/10">
                <div className="text-center">
                  <p className="text-[10px] text-dark-500">ورود</p>
                  <p className="text-xs text-white number-ltr mt-0.5">{trade.entry_price}</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-dark-500">خروج</p>
                  <p className="text-xs text-white number-ltr mt-0.5">{trade.exit_price ?? '—'}</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-dark-500">R Multiple</p>
                  <p className={`text-xs number-ltr mt-0.5 ${(trade.r_multiple || 0) >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                    {trade.r_multiple !== null ? `${trade.r_multiple.toFixed(2)}R` : '—'}
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={handleDownload}
              disabled={generating}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              {generating ? 'در حال ساخت تصویر...' : 'دانلود کارت'}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
