import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Filter, Download, Edit, Trash2, Eye, ChevronLeft, ChevronRight, LockKeyhole } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import JalaliDatePicker from '@/components/JalaliDatePicker';
import {
  formatCurrency, toPersianDate, getSessionLabel, getDirectionLabel,
  getResultLabel, getResultBadgeClass, formatRR
} from '@/lib/utils';

const PAGE_SIZE = 20;

type Filters = {
  search: string;
  symbol: string;
  direction: string;
  session: string;
  result: string;
  dateFrom: string;
  dateTo: string;
};

export default function TradeHistory() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [trades, setTrades] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [filters, setFilters] = useState<Filters>({
    search: '', symbol: '', direction: '', session: '', result: '', dateFrom: '', dateTo: ''
  });

  const loadTrades = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    let query = supabase
      .from('trades')
      .select('*, strategies(name), setups(name)', { count: 'exact' })
      .eq('user_id', user.id)
      .eq('account_id', getActiveAccountId())
      .order('trade_date', { ascending: false })
      .order('created_at', { ascending: false })
      .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

    if (filters.symbol) query = query.eq('symbol', filters.symbol);
    if (filters.direction) query = query.eq('direction', filters.direction);
    if (filters.session) query = query.eq('session', filters.session);
    if (filters.result) query = query.eq('result', filters.result);
    if (filters.dateFrom) query = query.gte('trade_date', filters.dateFrom);
    if (filters.dateTo) query = query.lte('trade_date', filters.dateTo);
    if (filters.search) query = query.ilike('symbol', `%${filters.search}%`);

    const { data, count } = await query;
    setTrades(data || []);
    setTotal(count || 0);
    setLoading(false);
  }, [user, page, filters]);

  useEffect(() => {
    loadTrades();
    const onAccountChanged = () => loadTrades();
    window.addEventListener('trading-os-active-account-changed', onAccountChanged);
    return () => window.removeEventListener('trading-os-active-account-changed', onAccountChanged);
  }, [loadTrades]);

  const handleDelete = async (id: string) => {
    await supabase.from('trades').delete().eq('id', id).eq('user_id', user!.id);
    setDeleteId(null);
    loadTrades();
  };

  const totalPages = Math.ceil(total / PAGE_SIZE);

  const getDirectionClass = (d: string) => d === 'buy' ? 'text-success-400' : 'text-danger-400';

  return (
    <div className="page-container" dir="rtl">
      {/* Header */}
      <div className="section-header">
        <h1 className="text-xl font-bold text-white">تاریخچه معاملات</h1>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowFilters(f => !f)}
            className={`btn-secondary flex items-center gap-1.5 text-sm ${showFilters ? 'border-gold-500/40 text-gold-400' : ''}`}
          >
            <Filter className="w-4 h-4" />
            فیلتر
          </button>
          <button onClick={() => navigate('/trade/new')} className="btn-primary flex items-center gap-1.5 text-sm">
            + معامله جدید
          </button>
        </div>
      </div>

      {/* Search bar */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
        <input
          type="text"
          placeholder="جستجو بر اساس نماد..."
          value={filters.search}
          onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
          className="input-field pr-9"
        />
      </div>

      {/* Filters panel */}
      {showFilters && (
        <div className="glass-card p-4 grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <div>
            <label className="label-text">نماد</label>
            <input type="text" value={filters.symbol} onChange={e => setFilters(f => ({ ...f, symbol: e.target.value }))} className="input-field" placeholder="XAUUSD" />
          </div>
          <div>
            <label className="label-text">جهت</label>
            <select value={filters.direction} onChange={e => setFilters(f => ({ ...f, direction: e.target.value }))} className="select-field">
              <option value="">همه</option>
              <option value="buy">خرید</option>
              <option value="sell">فروش</option>
            </select>
          </div>
          <div>
            <label className="label-text">سشن</label>
            <select value={filters.session} onChange={e => setFilters(f => ({ ...f, session: e.target.value }))} className="select-field">
              <option value="">همه</option>
              <option value="london">لندن</option>
              <option value="new_york">نیویورک</option>
              <option value="asian">آسیا</option>
              <option value="sydney">سیدنی</option>
            </select>
          </div>
          <div>
            <label className="label-text">نتیجه</label>
            <select value={filters.result} onChange={e => setFilters(f => ({ ...f, result: e.target.value }))} className="select-field">
              <option value="">همه</option>
              <option value="win">برنده</option>
              <option value="loss">بازنده</option>
              <option value="breakeven">سربه‌سر</option>
            </select>
          </div>
          <div>
            <label className="label-text">از تاریخ</label>
            <JalaliDatePicker value={filters.dateFrom} onChange={value => setFilters(f => ({ ...f, dateFrom: value }))} />
          </div>
          <div>
            <label className="label-text">تا تاریخ</label>
            <JalaliDatePicker value={filters.dateTo} onChange={value => setFilters(f => ({ ...f, dateTo: value }))} />
          </div>
          <div className="col-span-2 md:col-span-3 xl:col-span-6 flex justify-end">
            <button
              onClick={() => { setFilters({ search: '', symbol: '', direction: '', session: '', result: '', dateFrom: '', dateTo: '' }); setPage(0); }}
              className="btn-secondary text-sm"
            >
              پاک کردن فیلترها
            </button>
          </div>
        </div>
      )}

      {/* Stats summary */}
      {trades.length > 0 && (
        <div className="flex flex-wrap gap-3 text-sm">
          <span className="bg-dark-800/60 border border-white/5 rounded-lg px-3 py-1.5 text-dark-300">
            کل: <span className="text-white font-semibold">{total}</span> معامله
          </span>
          <span className="bg-dark-800/60 border border-white/5 rounded-lg px-3 py-1.5 text-dark-300">
            برنده: <span className="text-success-400 font-semibold">{trades.filter(t => t.result === 'win').length}</span>
          </span>
          <span className="bg-dark-800/60 border border-white/5 rounded-lg px-3 py-1.5 text-dark-300">
            بازنده: <span className="text-danger-400 font-semibold">{trades.filter(t => t.result === 'loss').length}</span>
          </span>
          <span className="bg-dark-800/60 border border-white/5 rounded-lg px-3 py-1.5 text-dark-300">
            مجموع P&L:{' '}
            <span className={`font-semibold number-ltr ${
              trades.reduce((s, t) => s + (t.pnl_amount || 0), 0) >= 0 ? 'text-success-400' : 'text-danger-400'
            }`}>
              {formatCurrency(trades.reduce((s, t) => s + (t.pnl_amount || 0), 0))}
            </span>
          </span>
        </div>
      )}

      {/* Table */}
      <div className="glass-card overflow-hidden">
        {loading ? (
          <div className="p-8 text-center">
            <div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : trades.length === 0 ? (
          <div className="p-12 text-center text-dark-400">
            <Search className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>معامله‌ای یافت نشد</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <div className="min-w-[1162px]" dir="rtl">
              <div className="grid grid-cols-[44px_92px_88px_82px_86px_130px_105px_105px_110px_78px_92px_150px] bg-dark-900/50 border-b border-white/5">
                {['#','تاریخ','نماد','جهت','سشن','استراتژی','ورود','خروج','P&L','R:R','نتیجه','عملیات'].map((h,i)=>(
                  <div key={h} className={`table-th text-center whitespace-nowrap ${i===5?'text-right':''}`}>{h}</div>
                ))}
              </div>
              {trades.map((trade, idx) => (
                <div key={trade.id} className="grid grid-cols-[44px_92px_88px_82px_86px_130px_105px_105px_110px_78px_92px_150px] border-b border-white/5 hover:bg-white/[.03] transition-colors" dir="rtl">
                  <div className="table-td text-dark-500 text-xs text-center">{page * PAGE_SIZE + idx + 1}</div>
                  <div className="table-td text-dark-300 text-xs whitespace-nowrap text-center">{toPersianDate(trade.trade_date)}</div>
                  <div className="table-td text-center"><span className="font-mono text-gold-400 text-xs bg-gold-500/10 px-1.5 py-0.5 rounded">{trade.symbol}</span></div>
                  <div className={`table-td font-semibold text-xs text-center ${getDirectionClass(trade.direction)}`}>{trade.direction === 'buy' ? '▲' : '▼'} {getDirectionLabel(trade.direction)}</div>
                  <div className="table-td text-dark-300 text-xs text-center whitespace-nowrap">{getSessionLabel(trade.session)}</div>
                  <div className="table-td text-dark-300 text-xs text-right truncate" title={trade.strategies?.name || '—'}>{trade.strategies?.name || '—'}</div>
                  <div className="table-td text-white text-xs number-ltr text-center">{trade.entry_price != null ? Number(trade.entry_price).toFixed(4) : '—'}</div>
                  <div className="table-td text-white text-xs number-ltr text-center">{trade.exit_price != null ? Number(trade.exit_price).toFixed(4) : '—'}</div>
                  <div className={`table-td font-semibold text-xs number-ltr text-center ${trade.pnl_amount == null ? 'text-dark-400' : trade.pnl_amount > 0 ? 'text-success-400' : trade.pnl_amount < 0 ? 'text-danger-400' : 'text-dark-300'}`}>
                    {trade.pnl_amount == null ? '—' : formatCurrency(trade.pnl_amount)}
                  </div>
                  <div className="table-td text-dark-300 text-xs number-ltr text-center">{trade.rr_ratio != null ? `${Number(trade.rr_ratio).toFixed(2)}R` : '—'}</div>
                  <div className="table-td text-center"><span className={getResultBadgeClass(trade.result)}>{getResultLabel(trade.result)}</span></div>
                  <div className="table-td text-center">
                    <div className="flex items-center justify-center gap-1 flex-wrap">
                      <button onClick={() => navigate(`/trade/${trade.id}`)} className="p-1.5 text-dark-400 hover:text-white hover:bg-white/5 rounded" title="مشاهده"><Eye className="w-3.5 h-3.5" /></button>
                      {trade.is_open && <button onClick={() => navigate(`/trade/${trade.id}/edit?focus=exit`)} className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold text-success-300 bg-success-500/10 border border-success-500/20 hover:bg-success-500/20 whitespace-nowrap" title="بستن معامله و ورود مستقیم به اطلاعات خروج"><LockKeyhole className="w-3 h-3" />بستن</button>}
                      <button onClick={() => navigate(`/trade/${trade.id}/edit`)} className="p-1.5 text-dark-400 hover:text-gold-400 hover:bg-gold-500/10 rounded" title="ویرایش"><Edit className="w-3.5 h-3.5" /></button>
                      <button onClick={() => setDeleteId(trade.id)} className="p-1.5 text-dark-400 hover:text-danger-400 hover:bg-danger-500/10 rounded" title="حذف"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-dark-400">
            نمایش {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, total)} از {total}
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(p => p - 1)}
              disabled={page === 0}
              className="btn-secondary p-1.5 !px-1.5 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <span className="text-sm text-white">صفحه {page + 1} از {totalPages}</span>
            <button
              onClick={() => setPage(p => p + 1)}
              disabled={page >= totalPages - 1}
              className="btn-secondary p-1.5 !px-1.5 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Delete confirm modal */}
      {deleteId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-white mb-2">حذف معامله</h3>
            <p className="text-sm text-dark-400 mb-4">آیا مطمئن هستید؟ این عمل قابل بازگشت نیست.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="btn-secondary">انصراف</button>
              <button onClick={() => handleDelete(deleteId)} className="btn-danger">حذف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}