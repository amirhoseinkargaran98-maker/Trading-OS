-- Phase 20: Saved trade filters
CREATE TABLE IF NOT EXISTS saved_trade_filters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  filters jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE saved_trade_filters ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_saved_trade_filters" ON saved_trade_filters;
CREATE POLICY "select_own_saved_trade_filters" ON saved_trade_filters FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_saved_trade_filters" ON saved_trade_filters;
CREATE POLICY "insert_own_saved_trade_filters" ON saved_trade_filters FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_saved_trade_filters" ON saved_trade_filters;
CREATE POLICY "update_own_saved_trade_filters" ON saved_trade_filters FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_saved_trade_filters" ON saved_trade_filters;
CREATE POLICY "delete_own_saved_trade_filters" ON saved_trade_filters FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS saved_trade_filters_user_idx ON saved_trade_filters(user_id, created_at DESC);
