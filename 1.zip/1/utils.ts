// Persian date utilities using built-in Intl API

// Persian (Jalali) date utilities backed by the JS engine's built-in ICU Persian
// calendar (Intl), which is far more reliable than a hand-rolled conversion algorithm.

export function toGregorianDateInput(date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

/** Parse a DATE-only value as a local calendar date. Never use new Date('YYYY-MM-DD'). */
export function parseDateOnly(value: string | null | undefined): Date | null {
  if (!value) return null;
  const m = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 12, 0, 0, 0);
  if (d.getFullYear() !== Number(m[1]) || d.getMonth() !== Number(m[2]) - 1 || d.getDate() !== Number(m[3])) return null;
  return d;
}

/** Convert a DATE-only value to a local calendar date without UTC shifting. */
export function dateInputToLocalDate(value: string): Date | null {
  return parseDateOnly(value);
}

/** Add/subtract whole calendar days without crossing a UTC boundary. */
export function addCalendarDays(date: Date, amount: number): Date {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12);
  d.setDate(d.getDate() + amount);
  return d;
}

export function addDateInputDays(value: string, amount: number): string {
  const d = parseDateOnly(value);
  return d ? toGregorianDateInput(addCalendarDays(d, amount)) : '';
}

export function diffDateInputsInDays(from: string, to: string): number {
  const a = parseDateOnly(from); const b = parseDateOnly(to);
  if (!a || !b) return 0;
  return Math.round((Date.UTC(b.getFullYear(), b.getMonth(), b.getDate()) - Date.UTC(a.getFullYear(), a.getMonth(), a.getDate())) / 86400000);
}

const jalaliFormatterLocal = new Intl.DateTimeFormat('en-US-u-ca-persian', {
  year: 'numeric', month: 'numeric', day: 'numeric',
});
const jalaliFormatterUTC = new Intl.DateTimeFormat('en-US-u-ca-persian', {
  year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'UTC',
});

function extractJalaliParts(formatter: Intl.DateTimeFormat, date: Date) {
  const parts = formatter.formatToParts(date);
  const get = (t: string) => parseInt(parts.find(p => p.type === t)?.value || '0', 10);
  return { year: get('year'), month: get('month'), day: get('day') };
}

/** Converts a real JS Date (interpreted in the local timezone) to its Jalali y/m/d. */
export function toJalaliDate(date = new Date()): { year: number; month: number; day: number } {
  return extractJalaliParts(jalaliFormatterLocal, date);
}

function jalaliSortKey(j: { year: number; month: number; day: number }) {
  return j.year * 372 + j.month * 31 + j.day;
}

/** Convert Jalali YYYY/MM/DD (or YYYY-MM-DD) to Gregorian DATE-only YYYY-MM-DD. */
export function jalaliToGregorian(value: string): string {
  const match = value.match(/^(\d{1,4})[/-](\d{1,2})[/-](\d{1,2})$/);
  if (!match) return '';
  const jy = Number(match[1]); const jm = Number(match[2]); const jd = Number(match[3]);
  if (jm < 1 || jm > 12 || jd < 1 || jd > 31) return '';

  const target = jalaliSortKey({ year: jy, month: jm, day: jd });
  const dayMs = 86400000;
  let lo = Math.floor(Date.UTC(jy + 620, 0, 1) / dayMs);
  let hi = Math.floor(Date.UTC(jy + 623, 0, 1) / dayMs);
  while (lo < hi) {
    const mid = Math.floor((lo + hi) / 2);
    const j = extractJalaliParts(jalaliFormatterUTC, new Date(mid * dayMs));
    if (jalaliSortKey(j) < target) lo = mid + 1; else hi = mid;
  }
  const result = new Date(lo * dayMs);
  const actual = extractJalaliParts(jalaliFormatterUTC, result);
  if (actual.year !== jy || actual.month !== jm || actual.day !== jd) return '';
  return `${result.getUTCFullYear()}-${String(result.getUTCMonth() + 1).padStart(2, '0')}-${String(result.getUTCDate()).padStart(2, '0')}`;
}

export function daysInJalaliMonth(year: number, month: number): number {
  if (month < 1 || month > 12) return 0;
  if (month <= 6) return 31;
  if (month <= 11) return 30;
  const first = jalaliToGregorian(`${year}/12/01`);
  const next = jalaliToGregorian(`${year + 1}/01/01`);
  if (!first || !next) return 29;
  return diffDateInputsInDays(first, next);
}

export function toPersianDate(date: Date | string | null | undefined): string {
  if (!date) return '—';
  const d = typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date) ? parseDateOnly(date) : (typeof date === 'string' ? new Date(date) : date);
  if (!d || isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit' });
}

export function toPersianDateTime(date: Date | string | null | undefined): string {
  if (!date) return '—';
  const d = typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date) ? parseDateOnly(date) : (typeof date === 'string' ? new Date(date) : date);
  if (!d || isNaN(d.getTime())) return '—';
  return d.toLocaleString('fa-IR-u-ca-persian', {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false,
    timeZone: 'Asia/Tehran',
  });
}

export function toPersianDigits(value: string | number): string {
  return String(value).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

export function toPersianNumber(num: number | null | undefined): string {
  if (num === null || num === undefined) return '—';
  return num.toLocaleString('fa-IR');
}

export function toPersianMonth(date: Date): string {
  return date.toLocaleDateString('fa-IR', { month: 'long', year: 'numeric' });
}

export function getPersianDayName(date: Date | string): string {
  const d = typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date) ? parseDateOnly(date) : (typeof date === 'string' ? new Date(date) : date);
  if (!d) return '—';
  const day = d.getDay();
  const days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
  return days[day];
}

export function formatCurrency(amount: number | null | undefined, currency = 'USD'): string {
  if (amount === null || amount === undefined) return '—';
  const abs = Math.abs(amount);
  let formatted: string;
  if (abs >= 1000000) {
    formatted = (abs / 1000000).toFixed(2) + 'M';
  } else if (abs >= 1000) {
    formatted = (abs / 1000).toFixed(2) + 'K';
  } else {
    formatted = abs.toFixed(2);
  }
  const sign = amount < 0 ? '-' : amount > 0 ? '+' : '';
  return `${sign}$${formatted}`;
}

export function formatPercent(value: number | null | undefined): string {
  if (value === null || value === undefined) return '—';
  const sign = value > 0 ? '+' : '';
  return `${sign}${value.toFixed(2)}%`;
}

export function formatRR(value: number | null | undefined): string {
  if (value === null || value === undefined) return '—';
  return `${value.toFixed(2)}R`;
}

export function getPnlClass(value: number | null | undefined): string {
  if (!value) return 'text-dark-400';
  return value > 0 ? 'profit-text' : value < 0 ? 'loss-text' : 'text-dark-400';
}

export function getResultBadgeClass(result: string | null): string {
  if (result === 'win') return 'badge-win';
  if (result === 'loss') return 'badge-loss';
  return 'badge-be';
}

export function getResultLabel(result: string | null): string {
  if (result === 'win') return 'برنده';
  if (result === 'loss') return 'بازنده';
  if (result === 'breakeven') return 'سربه‌سر';
  if (result === 'open') return 'باز';
  return '—';
}

export function getSessionLabel(session: string | null): string {
  const map: Record<string, string> = {
    london: 'لندن',
    new_york: 'نیویورک',
    asian: 'آسیا',
    sydney: 'سیدنی',
  };
  return session ? (map[session] || session) : '—';
}

export function getDirectionLabel(direction: string | null): string {
  if (direction === 'buy') return 'خرید';
  if (direction === 'sell') return 'فروش';
  return '—';
}

export function getTimeframeLabel(tf: string | null): string {
  const map: Record<string, string> = {
    m1: 'M1', m5: 'M5', m15: 'M15', m30: 'M30',
    h1: 'H1', h4: 'H4', d1: 'D1', w1: 'W1', mn1: 'MN',
  };
  return tf ? (map[tf] || tf) : '—';
}

export function getConditionLabel(c: string | null): string {
  const map: Record<string, string> = {
    trend: 'روند', range: 'رنج', breakout: 'شکست',
    pullback: 'پولبک', reversal: 'بازگشت',
  };
  return c ? (map[c] || c) : '—';
}

export function getPsychologyLabel(tag: string): string {
  const map: Record<string, string> = {
    fomo: '🏃 FOMO', revenge: '😡 انتقام', overtrading: '🔄 اورترید',
    fear: '😨 ترس', greed: '🤑 طمع', hesitation: '🤔 تردید',
    confidence: '💪 اطمینان', discipline: '🧘 انضباط',
    satisfaction: '😊 رضایت', anger: '🔥 عصبانیت',
  };
  return map[tag] || tag;
}

export function getFeelingLabel(f: string | null): string {
  const map: Record<string, string> = {
    calm: '😌 آرام', anxious: '😟 نگران', confident: '💪 مطمئن',
    fearful: '😨 ترسیده', greedy: '🤑 طمعکار', neutral: '😐 خنثی',
    satisfied: '😊 راضی', angry: '😡 عصبانی',
    excited: '🤩 هیجان‌زده', frustrated: '😤 ناامید',
  };
  return f ? (map[f] || f) : '—';
}

export function combineDateAndTimeLocal(dateInput: string, timeInput: string): Date | null {
  const m = timeInput.match(/^(\d{1,2}):(\d{2})$/);
  const d = parseDateOnly(dateInput);
  if (!d || !m) return null;
  const h = Number(m[1]), min = Number(m[2]);
  if (h < 0 || h > 23 || min < 0 || min > 59) return null;
  d.setHours(h, min, 0, 0);
  return d;
}


/** Return the weekday (0=Sunday..6=Saturday) for a DATE-only value without UTC shifting. */
export function getDayOfWeekFromDateInput(value: string | null | undefined): number | null {
  const d = parseDateOnly(value);
  return d ? d.getDay() : null;
}

/** Extract a clock hour from a trade timestamp in the configured trading timezone. */

/** Combine a DATE-only value and HH:mm into a timezone-explicit ISO timestamp.
 * Default trading timezone is Asia/Tehran. This prevents the browser/server timezone
 * from silently shifting the stored trade time.
 */
export function combineTradeDateTime(dateInput: string, hm: string, timeZone = 'Asia/Tehran'): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateInput) || !/^\d{2}:\d{2}$/.test(hm)) return null;
  const [y, mo, d] = dateInput.split('-').map(Number);
  const [h, m] = hm.split(':').map(Number);
  if (h > 23 || m > 59) return null;
  // The app currently defaults to Tehran. Keep the API extensible for a later
  // user-configurable timezone setting.
  if (timeZone === 'Asia/Tehran') return `${dateInput}T${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:00+03:30`;
  // For other IANA zones, resolve the offset from Intl by iterating around the
  // UTC candidate. This avoids relying on locale-specific parsing.
  const candidate = Date.UTC(y, mo - 1, d, h, m, 0);
  const getParts = (ts: number) => {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone, hour12: false, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit' }).formatToParts(new Date(ts));
    const pick = (type:string) => Number(parts.find(x=>x.type===type)?.value);
    return { year:pick('year'), month:pick('month'), day:pick('day'), hour:pick('hour'), minute:pick('minute'), second:pick('second') };
  };
  let ts = candidate;
  for (let i=0; i<3; i++) {
    const parts=getParts(ts);
    const observed=Date.UTC(parts.year, parts.month-1, parts.day, parts.hour, parts.minute, parts.second);
    ts += candidate-observed;
  }
  return new Date(ts).toISOString();
}

/** Convert a stored ISO timestamp to HH:mm in the Trading OS timezone. */
export function getTradeTimeInput(value: string | null | undefined, timeZone = 'Asia/Tehran'): string {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone, hour12: false, hour: '2-digit', minute: '2-digit',
  }).formatToParts(d);
  const hour = parts.find(p => p.type === 'hour')?.value ?? '';
  const minute = parts.find(p => p.type === 'minute')?.value ?? '';
  if (!/^\d{2}$/.test(hour) || !/^\d{2}$/.test(minute)) return '';
  return `${hour}:${minute}`;
}

export function getHourFromTradeTimestamp(value: string | null | undefined, timeZone = 'Asia/Tehran'): number | null {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  const parts = new Intl.DateTimeFormat('en-US', { hour: '2-digit', hour12: false, timeZone }).formatToParts(d);
  const hour = Number(parts.find(p => p.type === 'hour')?.value);
  return Number.isFinite(hour) ? hour : null;
}


export function getDayName(dayIndex: number): string {
  const days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
  return days[dayIndex] || '—';
}

export function getHourLabel(hour: number): string {
  return `${hour.toString().padStart(2, '0')}:00`;
}

// Contract sizes for common symbols
export const CONTRACT_SIZES: Record<string, number> = {
  XAUUSD: 100,
  EURUSD: 100000,
  GBPUSD: 100000,
  USDJPY: 100000,
  US30: 1,
  NAS100: 1,
  SPX500: 1,
  BTCUSD: 1,
  ETHUSD: 1,
  DEFAULT: 100000,
};

export function getContractSize(symbol: string): number {
  const upper = symbol.toUpperCase();
  for (const [key, size] of Object.entries(CONTRACT_SIZES)) {
    if (upper.includes(key) || key === upper) return size;
  }
  return CONTRACT_SIZES.DEFAULT;
}

/** Round a monetary value to the app's canonical 2-decimal precision. */
export function roundMoney(value: number | null | undefined): number | null {
  if (value === null || value === undefined || !Number.isFinite(value)) return null;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/** Broker-valid lot size: 0.01 minimum, 0.01 increments. */
export function normalizeLotSize(value: number | null | undefined, mode: 'nearest' | 'floor' = 'nearest'): number | null {
  if (value === null || value === undefined || !Number.isFinite(value)) return null;
  const safe = Math.max(0.01, value);
  const units = mode === 'floor' ? Math.floor((safe + 1e-10) * 100) : Math.round(safe * 100);
  return Math.max(0.01, units / 100);
}

/** Display lots exactly as traders write them: 0.01..0.09, then 0.1, 0.11 ... */
export function formatLotSize(value: number | null | undefined): string {
  const normalized = normalizeLotSize(value);
  if (normalized === null) return '—';
  return normalized.toFixed(2).replace(/\.?0+$/, '');
}

// Calculate trade metrics
export function calculateTradeMetrics(params: {
  symbol: string;
  direction: 'buy' | 'sell';
  entryPrice: number;
  exitPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  lotSize: number;
  contractSize?: number;
  capitalBefore?: number;
  entryTime?: Date;
  exitTime?: Date;
  commission?: number;
  swap?: number;
}) {
  const {
    symbol, direction, entryPrice, exitPrice, stopLoss, takeProfit,
    lotSize, contractSize, capitalBefore, entryTime, exitTime,
    commission = 0, swap = 0,
  } = params;

  const cs = contractSize || getContractSize(symbol);
  const result: Record<string, number | null> = {};
  const totalCost = roundMoney((Number(commission) || 0) + (Number(swap) || 0)) ?? 0;
  const validLot = normalizeLotSize(lotSize, 'nearest') ?? 0.01;

  // P&L calculation — pnl_amount is NET (after commission + swap), since that's
  // what actually happened to the account. gross_pnl_amount is kept alongside
  // for transparency in the trade detail breakdown. Every other page (Dashboard,
  // Analytics, equity curve, reports) already reads pnl_amount, so making it
  // NET here is the single place real trading costs flow through everywhere
  // without touching any of those files.
  if (exitPrice) {
    const priceDiff = direction === 'buy'
      ? exitPrice - entryPrice
      : entryPrice - exitPrice;
    const grossPnl = priceDiff * validLot * cs;
    result.gross_pnl_amount = roundMoney(grossPnl);
    result.pnl_amount = roundMoney(grossPnl - totalCost);
    if (capitalBefore) {
      result.pnl_percent = roundMoney((Number(result.pnl_amount) / capitalBefore) * 100);
      result.capital_after = roundMoney(capitalBefore + Number(result.pnl_amount));
    }
  }

  // Risk calculation
  if (stopLoss) {
    const riskPips = direction === 'buy'
      ? entryPrice - stopLoss
      : stopLoss - entryPrice;
    result.risk_amount = roundMoney(Math.abs(riskPips * validLot * cs));
    if (capitalBefore) {
      result.risk_percent = roundMoney((Number(result.risk_amount) / capitalBefore) * 100);
    }
  }

  // Potential profit
  if (takeProfit) {
    const profitPips = direction === 'buy'
      ? takeProfit - entryPrice
      : entryPrice - takeProfit;
    result.potential_profit = roundMoney(Math.abs(profitPips * validLot * cs));
  }

  // R:R ratio
  if (result.risk_amount && result.potential_profit) {
    result.rr_ratio = result.potential_profit / result.risk_amount;
  }

  // R multiple (actual result vs risk)
  if (result.pnl_amount && result.risk_amount && result.risk_amount > 0) {
    result.r_multiple = result.pnl_amount / result.risk_amount;
  }

  // Duration
  if (entryTime && exitTime) {
    result.duration_minutes = Math.round((exitTime.getTime() - entryTime.getTime()) / 60000);
  }

  return result;
}

export function determineResult(pnl: number | null | undefined): 'win' | 'loss' | 'breakeven' {
  if (!pnl || pnl === 0) return 'breakeven';
  return pnl > 0 ? 'win' : 'loss';
}
