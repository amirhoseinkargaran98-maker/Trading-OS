/**
 * BEHAVIOR ENGINE — rule-based detection of destructive trading behavior.
 *
 * This is intentionally independent of any AI provider: if the AI Coach is
 * disabled, misconfigured, or the API is down, these checks must still work,
 * because they are what keeps a trader from blowing up an account on a bad day.
 *
 * Pure functions only — no React, no Supabase calls. The UI layer
 * (`src/components/BehaviorAlerts.tsx`) fetches the data and hands it to
 * `detectBehaviorSignals`, then only handles rendering (icon, dismiss state).
 */

export type BehaviorSignalType =
  | 'consecutive_losses'
  | 'overtrading'
  | 'psychology_pattern'
  | 'missed_journal'
  | 'goal_deadline';

import { addCalendarDays, diffDateInputsInDays, toGregorianDateInput, parseDateOnly } from '@/lib/utils';

export type BehaviorSignal = {
  id: string;
  type: BehaviorSignalType;
  severity: 'danger' | 'warning' | 'info';
  title: string;
  description: string;
  /** Raw machine value for UI-layer formatting (e.g. psychology tag key before label lookup). */
  meta?: string;
};

type MinimalTrade = {
  trade_date: string;
  result: string | null;
  psychology_tags?: string[] | null;
  entry_time?: string | null;
  created_at?: string | null;
};

export function detectBehaviorSignals(input: {
  trades: MinimalTrade[];
  maxConsecutiveLosses?: number;
  maxTradesPerDay?: number;
  lastReviewDate?: string | null;
  upcomingGoals?: { title: string; end_date: string }[];
  now?: Date;
}): BehaviorSignal[] {
  const now = input.now || new Date();
  const today = toGregorianDateInput(now);
  const weekStart = toGregorianDateInput(addCalendarDays(now, -6));
  const signals: BehaviorSignal[] = [];
  const trades = input.trades;
  // Sort newest-first ourselves — trade_date alone is unstable for same-day
  // trades, so we can't trust the caller's DB query order for this.
  const chronoKey = (t: MinimalTrade) => `${t.trade_date}T${t.entry_time || ''}T${t.created_at || ''}`;
  const newestFirst = [...trades].sort((a, b) => chronoKey(b).localeCompare(chronoKey(a)));

  // 1. Consecutive losses
  let consecutiveLosses = 0;
  for (const t of newestFirst) {
    if (t.result === 'loss') consecutiveLosses += 1;
    else break;
  }
  const maxLossThreshold = input.maxConsecutiveLosses || 3;
  if (consecutiveLosses >= maxLossThreshold) {
    signals.push({
      id: 'consecutive-losses',
      type: 'consecutive_losses',
      severity: 'danger',
      title: `${consecutiveLosses} باخت متوالی`,
      description: 'شاید بهتره امروز رو استراحت کنی و فردا با ذهن بازتر برگردی.',
    });
  }

  // 2. Overtrading today
  const todayTrades = trades.filter(t => t.trade_date === today);
  const maxTradesThreshold = input.maxTradesPerDay || 6;
  if (todayTrades.length >= maxTradesThreshold) {
    signals.push({
      id: 'overtrading',
      type: 'overtrading',
      severity: 'warning',
      title: 'احتمال اورترید امروز',
      description: `امروز ${todayTrades.length} معامله ثبت کردی — بیشتر از حد معمول. مطمئن شو هر معامله طبق برنامه‌ات بوده.`,
    });
  }

  // 3. Recurring psychology pattern this week
  const weekTrades = trades.filter(t => t.trade_date >= weekStart);
  const tagCounts: Record<string, number> = {};
  weekTrades.forEach(t => (t.psychology_tags || []).forEach(tag => {
    tagCounts[tag] = (tagCounts[tag] || 0) + 1;
  }));
  const topTag = Object.entries(tagCounts).sort((a, b) => b[1] - a[1])[0];
  if (topTag && topTag[1] >= 3) {
    signals.push({
      id: 'psychology-pattern',
      type: 'psychology_pattern',
      severity: 'warning',
      title: 'الگوی تکرارشونده',
      description: `این هفته ${topTag[1]} بار این حالت رو تو معاملاتت تگ زدی. شاید وقتشه بیشتر بهش توجه کنی.`,
      meta: topTag[0],
    });
  }

  // 4. Missed journal
  const daysSinceReview = input.lastReviewDate
    ? diffDateInputsInDays(input.lastReviewDate, today)
    : null;
  if (daysSinceReview === null || daysSinceReview >= 3) {
    signals.push({
      id: 'missed-journal',
      type: 'missed_journal',
      severity: 'info',
      title: 'مدتیه ژورنال ننوشتی',
      description: daysSinceReview === null
        ? 'هنوز هیچ مرور روزانه‌ای ثبت نکردی.'
        : `${daysSinceReview} روزه مرور روزانه‌ات رو به‌روزرسانی نکردی.`,
    });
  }

  // 5. Goal deadline approaching
  (input.upcomingGoals || []).forEach(g => {
    const daysLeft = diffDateInputsInDays(today, g.end_date);
    if (daysLeft >= 0 && daysLeft <= 3) {
      signals.push({
        id: `goal-${g.title}`,
        type: 'goal_deadline',
        severity: 'warning',
        title: `هدف «${g.title}» نزدیک به مهلته`,
        description: daysLeft === 0 ? 'امروز آخرین روز این هدفه.' : `${daysLeft} روز تا پایان مهلت این هدف باقی مونده.`,
      });
    }
  });

  return signals;
}
