/*
# Trade Templates

## Overview
Lets a user save a reusable "template" of common trade-entry field defaults
(symbol, direction, timeframe, session, market condition, strategy/setup,
contract size, and preferred risk sizing) so new trades with a familiar
setup can be filled in one tap instead of retyping everything.

## Security
RLS enabled; each user can only see and manage their own templates.
*/

CREATE TABLE IF NOT EXISTS trade_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  symbol text,
  direction text,
  timeframe text,
  session text,
  market_condition text,
  strategy_id uuid REFERENCES strategies(id) ON DELETE SET NULL,
  setup_id uuid REFERENCES setups(id) ON DELETE SET NULL,
  contract_size numeric,
  risk_mode text DEFAULT 'percent',
  risk_input_value numeric,
  entry_reason text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trade_templates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "own_trade_templates_select" ON trade_templates;
CREATE POLICY "own_trade_templates_select"
  ON trade_templates FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_trade_templates_insert" ON trade_templates;
CREATE POLICY "own_trade_templates_insert"
  ON trade_templates FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_trade_templates_update" ON trade_templates;
CREATE POLICY "own_trade_templates_update"
  ON trade_templates FOR UPDATE TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own_trade_templates_delete" ON trade_templates;
CREATE POLICY "own_trade_templates_delete"
  ON trade_templates FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS trade_templates_user_idx ON trade_templates(user_id);
