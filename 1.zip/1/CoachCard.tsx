import { useEffect, useState } from 'react';
import { BrainCircuit, ChevronLeft, ShieldAlert, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { getActiveAccountId } from '@/lib/activeAccount';
import { useAuth } from '@/contexts/AuthContext';
import { buildLocalCoachSignals, askTradingCoach } from '@/lib/aiCoach';
import { getPsychologyLabel } from '@/lib/utils';

export default function CoachCard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [text, setText] = useState('');
  const [signals, setSignals] = useState({ disciplineScore: 100, winRate: 0, pnl: 0, topPsychologyTag: null as string | null, sampleSize: 0 });

  useEffect(() => {
    if (!user) return;
    supabase.from('trades').select('*').eq('user_id', user.id).eq('account_id', getActiveAccountId()).order('trade_date', { ascending: false }).limit(50).then(({ data }) => {
      if (data) setSignals(buildLocalCoachSignals(data));
    });
  }, [user]);

  async function generateBriefing() {
    if (!user) return;
    setLoading(true);
    try {
      const { data: trades } = await supabase.from('trades').select('*').eq('user_id', user.id).eq('account_id', getActiveAccountId()).order('trade_date', { ascending: false }).limit(50);
      const result = await askTradingCoach({ trades: trades || [], mode: 'performance', question: 'یک خلاصه بسیار کوتاه از وضعیت امروز معامله‌گر و مهم‌ترین هشدار یا تمرکز او بده.' });
      setText(result.text || 'برای امروز روی اجرای پلن و کنترل ریسک تمرکز کن.');
    } catch {
      setText('AI فعلاً در دسترس نیست. قوانین ریسک و چک‌لیست ورودت را دوباره مرور کن.');
    } finally {
      setLoading(false);
    }
  }

  const status = signals.disciplineScore >= 80 ? 'سبز' : signals.disciplineScore >= 60 ? 'احتیاط' : 'ریسک رفتاری';
  const statusClass = signals.disciplineScore >= 80 ? 'text-success-400' : signals.disciplineScore >= 60 ? 'text-gold-400' : 'text-danger-400';

  return (
    <div className="glass-card overflow-hidden border-gold-500/15 bg-gradient-to-br from-gold-500/[0.06] via-dark-800/70 to-dark-900/80">
      <div className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-2xl bg-gold-500/10 border border-gold-500/20 flex items-center justify-center">
              <BrainCircuit className="h-5 w-5 text-gold-400" />
            </div>
            <div>
              <div className="flex items-center gap-2"><span className="text-xs text-gold-400 font-semibold">AI TRADING COACH</span><Sparkles className="w-3 h-3 text-gold-400" /></div>
              <h3 className="text-lg font-bold text-white mt-1">وضعیت معامله‌گر</h3>
            </div>
          </div>
          <span className={`text-xs font-semibold ${statusClass}`}>{status}</span>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-5">
          <div className="rounded-xl bg-black/20 p-3"><p className="text-[11px] text-dark-400">انضباط</p><p className="text-lg font-bold text-white mt-1">{signals.disciplineScore}<span className="text-xs text-dark-500">/100</span></p></div>
          <div className="rounded-xl bg-black/20 p-3"><p className="text-[11px] text-dark-400">نرخ برد</p><p className="text-lg font-bold text-white mt-1">{signals.winRate}%</p></div>
          <div className="rounded-xl bg-black/20 p-3"><p className="text-[11px] text-dark-400">نمونه</p><p className="text-lg font-bold text-white mt-1">{signals.sampleSize}</p></div>
        </div>

        <div className="mt-4 rounded-xl border border-white/5 bg-black/20 p-4 min-h-16">
          {loading ? <div className="text-sm text-dark-400">در حال تحلیل الگوی معاملات...</div> : text ? <p className="text-sm text-dark-200 leading-7">{text}</p> : <p className="text-sm text-dark-400">با یک کلیک، مربی وضعیت معاملات اخیرت را جمع‌بندی می‌کند.</p>}
        </div>

        {signals.topPsychologyTag && <div className="mt-3 flex items-center gap-2 text-xs text-dark-400"><ShieldAlert className="w-3.5 h-3.5 text-gold-400" /> تگ پرتکرار: <span className="text-white">{getPsychologyLabel(signals.topPsychologyTag)}</span></div>}

        <div className="mt-4 flex gap-2">
          <button onClick={generateBriefing} disabled={loading} className="btn-primary flex-1 inline-flex items-center justify-center gap-2">{loading ? 'تحلیل...' : 'تحلیل با AI'}</button>
          <Link to="/ai-coach" className="btn-secondary inline-flex items-center gap-1">مربی <ChevronLeft className="w-4 h-4" /></Link>
        </div>
      </div>
    </div>
  );
}