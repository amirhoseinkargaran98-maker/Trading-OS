import { useState } from 'react';
import { TrendingUp, Eye, EyeOff, Mail, Lock, User, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

type AuthMode = 'login' | 'register' | 'forgot';

export default function AuthPage() {
  const { signIn, signUp, resetPassword } = useAuth();
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        const { error } = await signIn(email, password);
        if (error) setError(translateError(error));
      } else if (mode === 'register') {
        if (password !== confirmPassword) {
          setError('رمز عبور و تکرار آن مطابقت ندارند');
          return;
        }
        if (password.length < 6) {
          setError('رمز عبور باید حداقل ۶ کاراکتر باشد');
          return;
        }
        const { error } = await signUp(email, password, displayName);
        if (error) setError(translateError(error));
        else setSuccess('حساب کاربری ایجاد شد. اکنون وارد شوید.');
      } else {
        const { error } = await resetPassword(email);
        if (error) setError(translateError(error));
        else setSuccess('ایمیل بازیابی رمز عبور ارسال شد.');
      }
    } finally {
      setLoading(false);
    }
  };

  const translateError = (err: string): string => {
    if (err.includes('Invalid login credentials')) return 'ایمیل یا رمز عبور اشتباه است';
    if (err.includes('User already registered')) return 'این ایمیل قبلاً ثبت شده است';
    if (err.includes('Email not confirmed')) return 'ایمیل تأیید نشده است';
    if (err.includes('Network')) return 'خطا در اتصال به شبکه';
    return err;
  };

  return (
    <div className="min-h-screen bg-dark-950 flex items-center justify-center p-4" dir="rtl">
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gold-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-gold-600/3 rounded-full blur-3xl" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(245,158,11,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(245,158,11,0.03)_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-gradient-to-br from-gold-400 to-gold-600 rounded-xl flex items-center justify-center shadow-gold">
              <TrendingUp className="w-7 h-7 text-dark-950" strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Trading OS</h1>
              <p className="text-xs text-gold-500 font-medium">سیستم مدیریت معاملات</p>
            </div>
          </div>
        </div>

        {/* Auth Card */}
        <div className="glass-card p-6 md:p-8">
          {/* Tab switcher */}
          {mode !== 'forgot' && (
            <div className="flex gap-1 p-1 bg-dark-900 rounded-lg mb-6">
              <button
                onClick={() => { setMode('login'); setError(null); setSuccess(null); }}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  mode === 'login'
                    ? 'bg-gold-500 text-dark-950'
                    : 'text-dark-300 hover:text-white'
                }`}
              >
                ورود
              </button>
              <button
                onClick={() => { setMode('register'); setError(null); setSuccess(null); }}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  mode === 'register'
                    ? 'bg-gold-500 text-dark-950'
                    : 'text-dark-300 hover:text-white'
                }`}
              >
                ثبت‌نام
              </button>
            </div>
          )}

          {mode === 'forgot' && (
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-white">بازیابی رمز عبور</h2>
              <p className="text-sm text-dark-400 mt-1">ایمیل خود را وارد کنید تا لینک بازیابی ارسال شود.</p>
            </div>
          )}

          {/* Messages */}
          {error && (
            <div className="flex items-center gap-2 p-3 bg-danger-500/10 border border-danger-500/20 rounded-lg mb-4 text-danger-400 text-sm">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
          {success && (
            <div className="flex items-center gap-2 p-3 bg-success-500/10 border border-success-500/20 rounded-lg mb-4 text-success-400 text-sm">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              <span>{success}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="label-text">نام و نام خانوادگی</label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={e => setDisplayName(e.target.value)}
                    className="input-field pr-9"
                    placeholder="علی محمدی"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="label-text">ایمیل</label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="input-field pr-9"
                  placeholder="example@email.com"
                  required
                  dir="ltr"
                />
              </div>
            </div>

            {mode !== 'forgot' && (
              <div>
                <label className="label-text">رمز عبور</label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="input-field pr-9 pl-9"
                    placeholder="••••••••"
                    required
                    dir="ltr"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-400 hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {mode === 'register' && (
              <div>
                <label className="label-text">تکرار رمز عبور</label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    className="input-field pr-9"
                    placeholder="••••••••"
                    required
                    dir="ltr"
                  />
                </div>
              </div>
            )}

            {mode === 'login' && (
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => { setMode('forgot'); setError(null); setSuccess(null); }}
                  className="text-xs text-gold-500 hover:text-gold-400 transition-colors"
                >
                  فراموشی رمز عبور؟
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full py-2.5 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-dark-950/30 border-t-dark-950 rounded-full animate-spin" />
              ) : (
                <>
                  {mode === 'login' && 'ورود به سیستم'}
                  {mode === 'register' && 'ایجاد حساب کاربری'}
                  {mode === 'forgot' && 'ارسال لینک بازیابی'}
                </>
              )}
            </button>

            {mode === 'forgot' && (
              <button
                type="button"
                onClick={() => { setMode('login'); setError(null); setSuccess(null); }}
                className="btn-secondary w-full py-2.5"
              >
                بازگشت به ورود
              </button>
            )}
          </form>
        </div>

        <p className="text-center text-xs text-dark-500 mt-4">
          Trading OS v1.0 — سیستم حرفه‌ای مدیریت معاملات
        </p>
      </div>
    </div>
  );
}
